#include "multimine.h"
#include "Digits.h"

Point Digits::digitSize = Point(13,23);
Color Digits::digitBright = Color.White;
Color Digits::digitDark = Color.Gray;
int Digits::dash = 10;
int Digits::nothing = 11;

Digits::Digits(GUI* _gui){
	gui = _gui;

	memset(numbers, 0, sizeof(Bitmap*)*12);

	numbers[0] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_ZERO));
	numbers[1] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_ONE));
	numbers[2] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_TWO));
	numbers[3] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_THREE));
	numbers[4] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_FOUR));
	numbers[5] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_FIVE));
	numbers[6] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_SIX));
	numbers[7] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_SEVEN));
	numbers[8] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_EIGHT));
	numbers[9] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_NINE));
	numbers[dash] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_DASH));
	numbers[nothing] = Bitmap::FromResource(GetModuleHandle(NULL), (WCHAR*)MAKEINTRESOURCE(IDB_DIGIT_NOTHING));
	

}

Digits::~Digits(){

	Bitmap* temp;
	// i cant delete numbers[0]!
	for(int i=0;i<12;i++){
		temp = (Bitmap*)numbers[i];
		delete temp;
	}

}

int Digits::drawDigit(int* digit, Color* player, Point* p){
	int temp;
	Bitmap* b = numbers[*digit]->Clone(0,0, digitSize.X, digitSize.Y, PixelFormat32bppARGB);
	temp = player->GetR();
	temp = player->GetG();
	temp = player->GetB();
	Color* dark = new Color(player->GetRed()/2, player->GetGreen()/2, player->GetBlue()/2);
	temp = dark->GetB();
	temp = dark->GetR();
	temp = dark->GetG();


	Color* currentColour = new Color();
	for(int i=0;i<digitSize.X;i++){
		for(int j=0;j<digitSize.Y;j++){
			b->GetPixel(i,j,currentColour);
			
			temp = currentColour->GetR();
			temp = currentColour->GetG();
			temp = currentColour->GetB();
			if(temp != 255 && temp != 0)
				temp = temp;
			
			temp = digitDark.GetR();
			temp = digitDark.GetG();
			temp = digitDark.GetB();

			if(currentColour->GetValue() != digitBright.GetValue() && currentColour->GetR() != 0){
				b->SetPixel(i,j, *dark);
			}
			if(currentColour->GetValue() == digitBright.GetValue()){
				b->SetPixel(i,j, *player);
			}
		}
	}

	gui->g->DrawImage(b, *p);
	
	delete b;
	delete dark;
	delete currentColour;
	
	return 1;
}



