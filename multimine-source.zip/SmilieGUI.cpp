#include "multimine.h"
#include "SmilieGUI.h"

Point SmilieGUI::size = Point(24, 24);
Point SmilieGUI::spot = Point(4,4);
Point SmilieGUI::depressedSpot = Point(5,5);	
Color SmilieGUI::cDef = Color.White;
Point SmilieGUI::faceSize = Point(17,17);

int SmilieGUI::outer_border = 1;
int SmilieGUI::border = 2;

SmilieGUI::SmilieGUI(GUI* _gui, Point* topLeft, Color* cTop, Color* cBottom, Color* _cBackground, Smilie* _smilie):
DBlockGUI(_gui, topLeft, &size, cTop, cBottom, border, outer_border, _smilie){
	
	gui = _gui;
	outer_topLeft = new Point(*topLeft-Point(outer_border,outer_border));
	outer_size = new Point(size+Point(outer_border*2,outer_border*2));
	outer = new BlockGUI(gui, outer_topLeft, outer_size, cBottom, cBottom, outer_border);
	cBackground = _cBackground;
	HBITMAP temp;

	smilie = _smilie;
	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_SMILIE_SMILE));
	smilies[Smilie::Smile] = new Bitmap(temp, NULL);
	DeleteObject(temp);
	
	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_SMILIE_SHADES));
	smilies[Smilie::Shades] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_SMILIE_DEAD));
	smilies[Smilie::Dead] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_SMILIE_SCARED));
	smilies[Smilie::Scared] = new Bitmap(temp, NULL);
	DeleteObject(temp);
	
	Color * currentColour = new Color();
	for(int k=0;k<4;k++){

	}
	delete currentColour;
}

SmilieGUI::~SmilieGUI(){
	for(int i=0;i<4;i++){
		delete smilies[i];
	}
	delete outer;
	delete outer_topLeft;
	delete outer_size;
}

int SmilieGUI::drawSmilie(){
	Point* p;
	drawBorder();
	outer->drawBorder();
	if(smilie->depressed){
		p = &depressedSpot;
		gui->g->FillRectangle(gui->brush, topLeft->X+dBorder, topLeft->Y+dBorder, size.X-dBorder, size.Y-dBorder);
	}
	else{
		gui->g->FillRectangle(gui->brush, topLeft->X+border, topLeft->Y+border, size.X-border*2, size.Y-border*2);
		p = &spot;
	}


	Smilie::STATE tState = smilie->state;
	if(smilie->state == Smilie::Scared_left || smilie->state == Smilie::Scared_double)
		tState = Smilie::Scared;
	Color* currentColour = new Color();
	Bitmap* b = smilies[tState]->Clone(0,0, smilies[tState]->GetWidth(), smilies[tState]->GetHeight(), PixelFormat32bppARGB);
	
	for(int i=0;i<faceSize.X;i++){
		for(int j=0;j<faceSize.Y;j++){
			b->GetPixel(i,j,currentColour);
			if(currentColour->GetValue() == cDef.GetValue()){
				b->SetPixel(i,j, Color(0,0,0,0));
			}
		}
	}


	gui->g->DrawImage(b, (*topLeft)+(*p));

	delete currentColour;
	delete b;
	return 0;
}
	
	/** Handles the mouse event for the Smilie.
	*	@param p The point where the mouse is located.
	*	@param mouse_action What mouse action has taken place, 
	*	left/middle/right button down/up or mouse movement
	*/

bool SmilieGUI::pointInSmilie(POINTS* p){
	if(	topLeft->X <= p->x && p->x <= bottomRight->X && topLeft->Y <= p->y  && p->y <= bottomRight->Y)
		return true;
	return false;
}

void SmilieGUI::setTopLeft(int x, int y){
	topLeft->X = x;
	topLeft->Y = y;
	outer->topLeft->X = x-outer_border;
	outer->topLeft->Y = y-outer_border;
}

