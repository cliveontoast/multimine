#include "multimine.h"
#include "Network.h"

bool c;

Network::Network(GameController* _gc, bool _client, char* ip, int port){
	
/* Taken from ms-help://MS.PSDK.1033/winsock/winsock/wsastartup_2.htm
	*/
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
	
	wVersionRequested = MAKEWORD( 2, 2 );
	
	err = WSAStartup( wVersionRequested, &wsaData );
	if ( err != 0 ) {
		/* Tell the user that we could not find a usable */
		/* WinSock DLL.                                  */
		return;
	}
	
	/* Confirm that the WinSock DLL supports 2.2.*/
	/* Note that if the DLL supports versions greater    */
	/* than 2.2 in addition to 2.2, it will still return */
	/* 2.2 in wVersion since that is the version we      */
	/* requested.                                        */
	
	if ( LOBYTE( wsaData.wVersion ) != LOBYTE(wVersionRequested) ||
		HIBYTE( wsaData.wVersion ) != HIBYTE(wVersionRequested) ) {
		/* Tell the user that we could not find a usable */
		/* WinSock DLL.                                  */
		WSACleanup( );
		return; 
	}
	
	/* The WinSock DLL is acceptable. Proceed. */
	
	isClient = _client;
	c = isClient;
	gc = _gc;
	if(isClient){
		gcc = (GameControllerClient*)gc;
		myConnections = new MMPSocket*[1];
		myConnections[0] = new MMPSocket(this, ip, port);
	}
	
	else{// is server
		myConnections = new MMPSocket*[gc->maxPlayers];
		newConnections = new MMPSocket*[gc->maxPlayers];
		for(int i=0;i<gc->maxPlayers;i++){
			myConnections[i] = new MMPSocket();
			newConnections[i] = new MMPSocket();	
		}
		listener = new ListeningSocket(this, port);

//		myEvents = new WSAEVENT[gc->maxPlayers*2+1];

		

		client_count = 0;
		gcs = (GameControllerServer*)gc;


		// send into sleep mode :)
//		reRegisterSockets();
//		waitOnEvent();


	}
	
}

Network::~Network(){
	
	if(isClient){
		delete myConnections[0];
		delete[] myConnections;
	}
	else{
		listener->Destruct_ListeningSocket();
		delete listener;
		for(int i=0;i<gc->maxPlayers;i++){
			delete myConnections[i];
			myConnections[i] = NULL;
			delete newConnections[i];
			newConnections[i] = NULL;
		}
		delete[] myConnections;
		delete[] newConnections;
		//}
	}
	WSACleanup();
}
/*
Network::reRegisterSockets(){
	myEvents[0] = listener->socket_event;

	for(int i=0;i<gc->maxPlayers;i++){
		myEvents[1+i] = myConnections[i].socket_event;
		myEvents[1+gc->maxPlayers+i] = newConnections[i].socket_event;
	}
}

Network::waitOnEvent(){
int nReturnCode = WSAWaitForMultipleEvents(gc->maxPlayers*2+1, myEvents, 
    FALSE, INFINITE, FALSE);
}
*/

MMPSocket* Network::checkSocket(SOCKET s, UINT NETWORK_MSG){
	MMPSocket* mmps = myConnections[0];
	if(isClient){
		if(mmps->sock == s){
			return mmps;
		}
		MMPSocket::constructErrorMessage(MMPSocket::se_socket_not_found, NULL, __FILE__, __LINE__, NULL, NULL);
	}
	else {
		int i;
		switch(NETWORK_MSG){
		case SERVER_MMPSOCKET_EVENT:
			for(i=0;i<gc->maxPlayers;i++){
				mmps = myConnections[i];
				if(mmps->sock == s)
					return mmps;
			}
			break;
		
		case SERVER_TEMPSOCK_EVENT:
			for(i=0;i<gc->maxPlayers;i++){
				mmps = newConnections[i];
				if(mmps->sock == s)
					return mmps;
			}
			
			break;

		case SERVER_LISTENING_SOCKET_EVENT:
			if(s == listener->sock)
				return myConnections[0];
			
		}
	}
	return NULL;
}



Network::incomingError(short error, short event, SOCKET s, UINT NETWORK_MSG){
	MMPSocket* mmps;
	if( (mmps = checkSocket(s, NETWORK_MSG)) == NULL){
		MMPSocket::constructErrorMessage(MMPSocket::se_socket_not_found, NULL, __FILE__, __LINE__, 
			inet_ntoa(mmps->address.sin_addr), ntohs(mmps->address.sin_port));
	}
	if(mmps != NULL){
		switch(NETWORK_MSG){
		case CLIENT_MMPSOCKET_EVENT:
		case SERVER_MMPSOCKET_EVENT:
			switch(event){
			case FD_CONNECT:
				MMPSocket::constructErrorMessage(MMPSocket::se_connection_refused, error, __FILE__, __LINE__, 
					inet_ntoa(mmps->address.sin_addr), ntohs(mmps->address.sin_port));
				
				break;
			
			case FD_READ:
			case FD_WRITE:
			case FD_OOB:
			case FD_ACCEPT:
			case FD_CLOSE:
			{
				int i = mmps->playerNo;
				mmps->OnClose();
					
				if(!isClient){
					gc->PlayerHasLeft(i);
				}
				else {
					//PostMessage(gc->hWndChat, WM_CLOSE, 0, 0);
					gcc->leaveServer();
					MessageBox(NULL, "Server closed connection", "Server stopped", MB_OK);
				}
				break;
			}
			case FD_QOS:
			case FD_GROUP_QOS:
			case FD_ROUTING_INTERFACE_CHANGE:
			case FD_ADDRESS_LIST_CHANGE:
			default:
				MMPSocket::constructErrorMessage(MMPSocket::se_unknown_error, error, __FILE__, __LINE__, 
					inet_ntoa(mmps->address.sin_addr), ntohs(mmps->address.sin_port));
			}
			break;
		case SERVER_LISTENING_SOCKET_EVENT:
			MMPSocket::constructErrorMessage(MMPSocket::se_listening_socket_error, error, __FILE__, __LINE__, NULL, NULL);
			break;


		case SERVER_TEMPSOCK_EVENT:
		default:
			MMPSocket::constructErrorMessage(MMPSocket::se_reached_unallowed_default_case, NULL, __FILE__, __LINE__, NULL, NULL);
			break;
		}
	}

}

Network::incomingEvent(short event, SOCKET s, UINT NETWORK_MSG){
	MMPSocket* mmps;
	if((mmps = checkSocket(s, NETWORK_MSG)) == NULL){
		MMPSocket::constructErrorMessage(MMPSocket::se_socket_not_found, NULL, __FILE__, __LINE__, NULL, s);
	}
	else {
		switch(NETWORK_MSG){
		case CLIENT_MMPSOCKET_EVENT:
		case SERVER_MMPSOCKET_EVENT:
		case SERVER_TEMPSOCK_EVENT:
			switch(event){
			case FD_READ:
				mmps->OnReceive();
				break;
				
			case FD_WRITE:
				mmps->OnSend();
				break;
				
			case FD_OOB:
				mmps->OnOutOfBandData();
				break;
				
			case FD_ACCEPT:
				mmps->OnAccept();
				break;
				
			case FD_CONNECT:
				mmps->OnConnect();
				break;
				
			case FD_CLOSE:
			{
				int i = mmps->playerNo;
				mmps->OnClose();
				if(isClient){
					gcc->leaveServer();
					//PostMessage(gc->hWndChat, WM_CLOSE, 0, 0);
					MessageBox(NULL, "Server closed", "server closed", MB_OK);
				}
				else {
					gc->PlayerHasLeft(i);
				}
				break;
			}
			default:
				MMPSocket::constructErrorMessage(MMPSocket::se_reached_unallowed_default_case, NULL, __FILE__, __LINE__, 
					inet_ntoa(mmps->address.sin_addr), ntohs(mmps->address.sin_port));
			}
			break;

		case SERVER_LISTENING_SOCKET_EVENT:

			switch(event){
			case FD_ACCEPT:
				listener->OnAccept();	
				break;
			case FD_CLOSE:
				listener->OnClose();
				break;
		
			default:
				MMPSocket::constructErrorMessage(MMPSocket::se_reached_unallowed_default_case, NULL, __FILE__, __LINE__, 
					inet_ntoa(mmps->address.sin_addr), ntohs(mmps->address.sin_port));
			}
			break;

		default:
			MMPSocket::constructErrorMessage(MMPSocket::se_reached_unallowed_default_case, NULL, __FILE__, __LINE__, 
				inet_ntoa(mmps->address.sin_addr), ntohs(mmps->address.sin_port));
			break;
		}
	}
}



Network::addMMPSocket(SOCKET s, sockaddr_in sockAddr, int adLen){
	if(!isClient){
		
		if(client_count < gc->maxPlayers){
			for(int i=0;i<gc->maxPlayers;i++){
				if( newConnections[i]->n == NULL){
					newConnections[i]->Attach(s, sockAddr, adLen);
					newConnections[i]->Construct(this, -(i+1));
					newConnections[i]->registerSocket(SERVER_TEMPSOCK_EVENT, NULL);
					break;
				}
			}
			if(i == gc->maxPlayers){
				denyClient(s, sockAddr, adLen);
				return NULL;
			}

			mmpMSG_server_request_client_data msg;
			msg.server_hash = gc->server_hash;
			msg.maxPlayers = gc->maxPlayers;
			
			newConnections[i]->queueMessage(mmp_server_request_client_data, &msg);

		}
		else {
			denyClient(s, sockAddr, adLen);
			return NULL;
		}	
	}
	return NULL;
}

Network::denyClient(SOCKET s, sockaddr_in sockAddr, int adLen){
	MMPSocket* temp = new MMPSocket();
	temp->Attach(s, sockAddr, adLen);
	temp->Construct(this, 0);
	temp->queueMessage(mmp_server_deny_new_client, NULL);
	temp->Detach(SD_RECEIVE);
	delete temp;
}

Network::closeSocket(int player){
	if(isClient){
		// i'm sure this will be 100% 0  :)
		if(player = 0){
			// send the gc saying your connection is lost.. which is very bad!	
//			myConnections->Close();
		}
	}
	else {
//		myConnections[player]->close;
//		myConnections[player]->n = NULL;
	}
}
					
				
Network::processPendingMessage(mmpMSG head, int player){
	

	if(isClient){
		switch(head.mmpHead){
			case mmp_server_request_client_data:
			{
				mmpMSG_server_request_client_data* msg = (mmpMSG_server_request_client_data*)head.data;
				gcc->ServerAcceptedConnection(msg->server_hash, msg->maxPlayers);
				break;
			}
			case mmp_server_accept_new_client:
			{
				mmpMSG_client_details* msg = (mmpMSG_client_details*)head.data;
				gcc->ServerAcceptedClient(msg->colour, msg->name, msg->playerNo);
				break;
			}

			case mmp_server_deny_new_client:
			{
				mmpMSG_server_deny_new_client* msg = (mmpMSG_server_deny_new_client*)head.data;
				stringstream ss;
				string s;
				switch(msg->deny_reason){
					case dr_server_full:
					{
						s.append("The server now has ");
						ss << msg->extra_information;
						s.append(ss.str());
						s.append(" and is full. Please try again later");
						char* e = new char[s.length()+1];
						strcpy(e, s.c_str());
						e[s.length()] = '\0';
						MessageBox(gc->hWnd, e, "Server full", MB_OK | MB_ICONINFORMATION);
						delete[] e;
						break;
					}
					case dr_invalid_hash:
					{
						s.append("The server has a different hash to ");
						ss << msg->extra_information;
						s.append(ss.str());
						s.append(". The most likely cause is bad transmittion. If you are paranoid, perhaps someone is packet sniffing or something.");
						char* e = new char[s.length()+1];
						strcpy(e, s.c_str());
						e[s.length()] = '\0';
						MessageBox(gc->hWnd, e, "Server rejects hash", MB_OK | MB_ICONINFORMATION);
						delete[] e;
						break;
					}
					case dr_version_mismatch:
					{
						s.append("The server is multimine version ");
						ss << msg->extra_information;
						s.append(ss.str());
						s.append(". You are using version ");
						stringstream ss1;
						ss1 << MULTI_MINE_VERSION;
						s.append(ss1.str());
						if(msg->extra_information > MULTI_MINE_VERSION)
							s.append(" Please get the newer version or find another server.");
						else
							s.append(" Please get the older version or find another server.");
						char* e = new char[s.length()+1];
						strcpy(e, s.c_str());
						e[s.length()] = '\0';
						MessageBox(gc->hWnd, e, "Server uses different version", MB_OK | MB_ICONINFORMATION);
						delete[] e;
						break;
					}
					case dr_game_in_progress:
					{
						MessageBox(gc->hWnd, "Try again soon", "Server is currently playing a game.. give it a few minutes", MB_OK | MB_ICONINFORMATION);
						break;
					}
				}

				myConnections[0]->Detach(SD_BOTH);

				break;
			}
			case mmp_server_full:
				
				break;

			case mmp_server_variable_change:
			{
				mmpMSG_server_variable_change* msg = (mmpMSG_server_variable_change*)head.data;
				gcc->variableChange(msg->variable, msg->value);
				break;
			}
			case mmp_server_send_another_client: // fall through.
			case mmp_server_broadcast_new_client:
			{	
				mmpMSG_client_details* msg = (mmpMSG_client_details*)head.data;
				if(msg->playerNo != gcc->players[0].playerNo)
					gcc->addPlayer(msg->colour, msg->name, msg->playerNo);
				break;
			}
			case mmp_server_details:
			{
				mmpMSG_server_details* msg = (mmpMSG_server_details*)head.data;
				gcc->ServerSendingDetails(msg->serverTitle, msg->port, msg->combo_size, 
					msg->combo_game_type, msg->height, msg->width, msg->mines, msg->endGame);
				break;
			}
			case mmp_server_broadcast_client_name:
			{
				mmpMSG_server_broadcast_client_name* msg = (mmpMSG_server_broadcast_client_name*)head.data;
				gcc->changePlayerName(msg->player, msg->name);
				break;
			}
			case mmp_server_broadcast_client_colour:
			{
				mmpMSG_server_broadcast_client_colour* msg = (mmpMSG_server_broadcast_client_colour*)head.data;
				gcc->changePlayerColour(msg->player, msg->colour);
				break;
			}
			case mmp_server_broadcast_client_leaving:
			{
				mmpMSG_server_broadcast_client_leaving* msg = (mmpMSG_server_broadcast_client_leaving*)head.data;
				gcc->PlayerHasLeft(msg->player);
				break;		
			}
			case mmp_server_broadcast_begin_game:
			{
				mmpMSG_server_broadcast_begin_game* msg = (mmpMSG_server_broadcast_begin_game*)head.data;
				gcc->beginNewGame(msg->width, msg->height, msg->mines, msg->seed, msg->game_type);
				break;
			}
			case mmp_server_hash_reply:
			{
				mmpMSG_server_hash_reply* msg = (mmpMSG_server_hash_reply*)head.data;
				gcc->ServerHashTest(msg->accepted);
				break;
			}
			case mmp_server_broadcast_accepting_clicks:
				gcc->GameOn();
				break;
			case mmp_server_broadcast_minefield_click:
			{
				mmpMSG_server_broadcast_minefield_click* msg = (mmpMSG_server_broadcast_minefield_click*)head.data;
				gcc->mouseEventMinefield(msg->score.current_player, &(msg->click.p), msg->click.ma, 0);
				gcc->updatePlayerScore(msg->score);
				break;
			}
			case mmp_server_broadcast_end_game:
				gcc->CARGameOff();
				break;
			case mmp_server_broadcast_player_change_score:
			{
				mmpMSG_server_broadcast_player_change_score* msg = (mmpMSG_server_broadcast_player_change_score*)head.data;
				gcc->updatePlayerScore(msg->score);
				break;
			}
			case mmp_server_broadcast_chat_message:
			{
				mmpMSG_chat_message* msg = (mmpMSG_chat_message*)head.data;
				gcc->incommingChatMessage(msg->player, msg->length_of_text, msg->text);
				break;
			}

		}
	}
	else {
		if(player < 0){

			MMPSocket* mmps;
			if(isClient){
				mmps = myConnections[0];	
			}
			else {
				if(player > 0){
					mmps = myConnections[player];
				}
				else if (player < 0){
					mmps = newConnections[-(player+1)];
				}
			}

			switch(head.mmpHead){
				case mmp_client_reply_client_data:
				{
					mmpMSG_client_reply_client_data* msg = (mmpMSG_client_reply_client_data*)head.data;
					mmpMSG_server_deny_new_client reply;
					
					if(msg->server_hash != gc->server_hash){
						reply.deny_reason = dr_invalid_hash;
						reply.extra_information = msg->server_hash;
						SendAndRemove(mmps, &reply);

					}
					else if(msg->version < MULTI_MINE_VERSION_MINIMUM_COMPATIBILITY){
						reply.deny_reason = dr_version_mismatch;
						reply.extra_information = MULTI_MINE_VERSION;
						SendAndRemove(mmps, &reply);
					}
					// game is now full
					else if(client_count == gc->maxPlayers){
						reply.deny_reason = dr_server_full;
						reply.extra_information = 0;
						SendAndRemove(mmps, &reply);
					}
					else {
						int i;
						for(i=0;i<gc->maxPlayers;i++){
							if(myConnections[i]->n == NULL){

								// transfer connection to players
								newConnections[-(player+1)]->Transfer(myConnections[i]);
								newConnections[-(player+1)]->Destruct();
								myConnections[i]->Construct(this, i+1);
								myConnections[i]->registerSocket(SERVER_MMPSOCKET_EVENT, NULL);
					
								mmpMSG_client_details reply;
								reply.colour = msg->colour;
								memcpy(&reply.name, &msg->name, NAME_MAX);
								reply.playerNo = i+1;
								myConnections[i]->queueMessage(mmp_server_accept_new_client, &reply);
								// write to own data
								gc->addPlayer(reply.colour, reply.name, reply.playerNo);
								
								break;
							}					
						}
						if(i == gcs->maxPlayers){
							mmps->queueMessage(mmp_server_full, NULL);
							mmps->Detach(SD_RECEIVE);
						}
					}
					
					break;
				}
			}
		}
		if(player > 0){
			switch(head.mmpHead){
				case mmp_client_request_server_details:
					gcs->sendServerDetails(player);
				break;

				case mmp_client_change_name:
				{
					mmpMSG_client_change_name* msg = (mmpMSG_client_change_name*)head.data;
					gcs->changePlayerName(player, msg->name);
					break;
				}
				case mmp_client_change_colour:
				{	mmpMSG_client_change_colour* msg = (mmpMSG_client_change_colour*)head.data;
					gcs->changePlayerColour(player, msg->colour);
					break;
				}
				case mmp_client_returns_minefield_hash:
				{
					mmpMSG_client_returns_minefield_hash* msg = (mmpMSG_client_returns_minefield_hash*)head.data;
					gcs->checkClientHash(player, msg->hash);
					break;
				}
				case mmp_client_minefield_click:
				{
					mmpMSG_client_minefield_click* msg = (mmpMSG_client_minefield_click*)head.data;
					gcs->mouseEventMinefield(player, &(msg->p), msg->ma, 0);
					break;
				}
				case mmp_client_chat_message:
				{
					mmpMSG_chat_message* msg = (mmpMSG_chat_message*)head.data;
					gcs->incommingChatMessage(player, msg);
					break;
				}
	
			
			}
		
		//	switch(head.mmpHead){
		//	case
		//	}
		
		}

	}
}

Network::SendAndRemove(MMPSocket* mmps, void* data){
	mmps->queueMessage(mmp_server_deny_new_client, data);
	mmps->Detach(SD_RECEIVE);
	//mmps->Destruct();
	//mmps->OnClose();
}


// if its zero, send to all connections
/*
Network::sendMessage(MMP* head, char* data, short player){
	myConnections[i].appendMessage(data, sizeof(MMP));
}
*/

void Network::broadcastMessageBarSelfClient(MMP head, void* data){
	for(int i=1;i<gc->maxPlayers;i++){
		sendMessage(myConnections[i], head, data);	
	}
}

void Network::broadcastMessage(MMP head, void* data){
	int upperBound;
	if(isClient)
		upperBound = 1;
	else
		upperBound = gc->maxPlayers;

	/*
	v(myConnections, myConnections+gc->maxPlayers);
	random_shuffle(v.begin(), v.end());
	*/

	
	for(int i=0;i<upperBound;i++){
		sendMessage(myConnections[i], head, data);
	}
}

void Network::sendMessage(int player, MMP head, void* data){
	sendMessage(myConnections[player-1], head, data);
}

void Network::sendMessage(MMP head, void* data){
	sendMessage(myConnections[0], head, data);
}

void Network::sendMessage(MMPSocket* mmps, MMP head, void* data){
	if(mmps->n != NULL)
		mmps->queueMessage(head, data);
}

int Network::messageSizes(MMP head){
	switch(head){
	case mmp_server_deny_new_client:						return sizeof(mmpMSG_server_deny_new_client);
	case mmp_server_request_client_data:				return sizeof(mmpMSG_server_request_client_data);
	case mmp_client_reply_client_data:						return sizeof(mmpMSG_client_reply_client_data);
	case mmp_server_full:							return 0;
	case mmp_server_accept_new_client:					return sizeof(mmpMSG_client_details);
	
	case mmp_server_send_another_client: // fall through
	case mmp_server_broadcast_new_client:					return sizeof(mmpMSG_client_details);

	case mmp_server_variable_change:				return sizeof(mmpMSG_server_variable_change);
	case mmp_server_details:					return sizeof(mmpMSG_server_details);
	case mmp_client_request_server_details:			return 0;
	case mmp_client_change_name:					return sizeof(mmpMSG_client_change_name);
	case mmp_client_change_colour:					return sizeof(mmpMSG_client_change_colour);
	case mmp_server_broadcast_client_name:			return sizeof(mmpMSG_server_broadcast_client_name);
	case mmp_server_broadcast_client_colour:		return sizeof(mmpMSG_server_broadcast_client_colour);
	case mmp_server_broadcast_client_leaving:			return sizeof(mmpMSG_server_broadcast_client_leaving);
	case mmp_server_broadcast_begin_game:			return sizeof(mmpMSG_server_broadcast_begin_game);
	case mmp_server_broadcast_accepting_clicks:		return 0;
	case mmp_client_returns_minefield_hash:			return sizeof(mmpMSG_client_returns_minefield_hash);
	case mmp_server_hash_reply:						return sizeof(mmpMSG_server_hash_reply);
	case mmp_client_minefield_click:				return sizeof(mmpMSG_client_minefield_click);
	case mmp_server_broadcast_minefield_click:		return sizeof(mmpMSG_server_broadcast_minefield_click);
	case mmp_server_broadcast_player_change_score:	return sizeof(mmpMSG_server_broadcast_player_change_score);
	case mmp_server_broadcast_end_game:				return 0;
	
	// these two stay together
	case mmp_server_broadcast_chat_message:			//fall through
	case mmp_client_chat_message:					return sizeof(mmpMSG_chat_message);
	
	default:
		MMPSocket::constructErrorMessage(MMPSocket::se_reached_unallowed_default_case, NULL, __FILE__, __LINE__, 
			NULL, NULL);
	}
	return 0;
}
					
