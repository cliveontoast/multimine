#ifndef _HAVE_MULTIMINE_H
#define _HAVE_MULTIMINE_H 1

#define NETWORK_ERROR			29971
#define SERVER_MMPSOCKET_EVENT	29972
#define CLIENT_MMPSOCKET_EVENT	29973
#define SERVER_LISTENING_SOCKET_EVENT	29974
#define SERVER_TEMPSOCK_EVENT	29975
#define SERVER_ACCEPTED_CLIENT_CONNECTION 29976
#define ID_GAME_START_TIMER 29977
#define CREATE_GAME_BEGINNING_DIALOG 29978
#define ID_GAME_SECONDS_SINCE_START 29979

#define DEATHMATCH 0
#define CAPTURE_THE_FLAG 1

#define BEGINNER 0
#define INTERMEDIATE 1
#define EXPERT 2
#define HUGE 3

#define CHAT_MAX 100
#define NAME_MAX 32

#define CLIENT_TIMEOUT 5000
#define ONE_SECOND_IN_MILLISECONDS 1000

#define MAX_RETRY_LIMIT_ERROR 1
#define ARRAY_POPULATED 0

// hopefully this version number doesnt go over.. 5 characters wide.
// the about box proc has this limit on the text

#define MULTI_MINE_VERSION 20
#define MULTI_MINE_VERSION_MINIMUM_COMPATIBILITY 19

#define DEFAULT_PORT 4987
// must be before windows.h
#include <winsock2.h>
#include <windows.h>

#include "resource.h"

#include <stdarg.h>

#include <gdiplus.h>
#pragma comment(lib, "gdiplus") 

using namespace Gdiplus;



#define WIN32_LEAN_AND_MEAN
#include <iostream.h>

//using namespace std;

	//defined in GUI.h but needed in includes before it

#include <string>
using namespace std;
#include <sstream>
#include <vector>

#include "Exception.h"

class BlockGUI;
class Minefield;

class GameController;


class Player;
class Digits;
class CellGUI;
//

class DigitalDisplayGUI;
class DigitalDisplay;
class GameControllerClient;
class GameControllerServer;
class DBlock;
class DBlockGUI;
class Smilie;
class SmilieGUI;
class Cell;

class MinefieldGUI;
class SLList;
class Topbar;

class Network;
class MMPSocket;
class ListeningSocket;

#define MAX(x,y) ( (x) > (y) ? (x) : (y) )
#define MIN(x,y) ( (x) < (y) ? (x) : (y) )

#include "Score.h"

#include "SLList.h"
#include "Player.h"
#include "GUI.h"


#include "CellGUI.h"

#include "BlockGUI.h"

#include "Digits.h"
#include "DigitalDisplay.h"
#include "DigitalDisplayGUI.h"

#include "DBlock.h"
#include "DBlockGUI.h"


#include "Smilie.h"
#include "SmilieGUI.h"

#include "Topbar.h"

#include "Cell.h"

// must be before Networks section.
#include <Ws2tcpip.h>

#include "Network.h"
#include "MMPSocket.h"
#include "ListeningSocket.h"

#include "GameController.h"
#include "GameControllerClient.h"
#include "GameControllerServer.h"

#include "Minefield.h"
#include "MinefieldGUI.h"






#endif /* _HAVE_MULTIMINE_H */