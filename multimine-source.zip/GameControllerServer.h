#ifndef _HAVE_GAMECONTROLLERSERVER_H
#define _HAVE_GAMECONTROLLERSERVER_H 1


#include "multimine.h"
/*
#include "GUI.h"
#include "GameController"
*/

/** A game controller that adds the requirements of a sever. such as.. i dunno yet.
*
*/
class GameControllerServer : public GameController {
public:

	bool* clientHashReplies;

	GameControllerServer(HWND hWnd, int maxPlayers, int port);
	~GameControllerServer();

	void mouseEventMinefield(int player, Point* cell, GUI::Mouse_Action mouse_action, int button_state);
	void mouseEventSmilie(bool inSmilie, GUI::Mouse_Action mouse_action, int button_state);
	void redrawSmilie();
	void redrawMinefieldCell(Point *cell);

	bool getEndGame();	/*i dont know why the fuck i need this, i should be able to have direct
						access to the end game attribute, because i inherited it!!!
						endGame' : cannot access public member declared in class 'GameController
						*/

	void processErrorMessage(Exception e);

	/** does client side stuff when adding the player
	*	
	*/
	void addPlayer(COLORREF colour, char* name, short playerNo); 

	static initChatDialog(HWND hWndChat);

	static bool preloadChecks(HWND hWnd, int* port, int* maxPlayers);
	postloadSettings(HWND hWndMain);
	void variableChange(int variable, int value);
	void GameControllerServer::sendServerDetails(int playerNo);

	void changePlayerName(int player, char* name);
	void changePlayerColour(int player, COLORREF colour);
	void PlayerHasLeft(int player);


	closeServer();
	beginNewGame();

	void GameOn();

	void setMaxPlayers(int maxPlayers);
	checkClientHash(int player, int hash);

	void CARGameOff();

	void oneSecondHasPassed();

	void incommingChatMessage(int player, Network::mmpMSG_chat_message* msg);

};

#endif