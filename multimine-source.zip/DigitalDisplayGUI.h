#ifndef _HAVE_DIGITALDISPLAYGUI_H
#define _HAVE_DIGITALDISPLAYGUI_H 1

#include "multimine.h"
/*
#include "GUI.h"
#include "BlockGUI.h"
#include "DigitalDisplay.h"
#include "Digits.h"
*/

/** Displays a integer on the screen. This uses a Digits object to get the pictures of the
*	numbers it wants to draw.
*/

class DigitalDisplayGUI : public BlockGUI {

public:
	
	DigitalDisplay* dd;	/**<	The display that this DDGUI draws to it's gui. */
						
	Digits* digits;	/**<	Pointer to the Digits object that draws numbers.
					*
	*****************
	*
	*	This should point to a Digits object created previousy and used globally
	*	for the calling object.
	*
	*************************************************************************/

	Point* block_size;	/**<	The DigitalDisplayGUI's size. 
						*
	*********************
	*
	*	Because the block size is determined from dd, the size of the block is unknown
	*	before it is created. Thus the pointer for the BlockGUI size needs to be stored
	*	somewhere. In this case that somewhere is within the DigitalDisplayGUI.
	*
	*/

	Color*	digitsColour;	/**<	Colour of the digits being displayed
							*
	*************************
	*
	*	This should point to a colour object created by the calling object.
	*	This would usually be the colour of the player that it's drawing.
	*
	*************************************************************************/

	/** Creates the Digital display object from the set of inputs
	*	@param dd The digitalDisplay this sets its dd to. :)
	*	@param digitsColour The pointer that the DigitalDisplayGUI sets its digitsColour to.
	*	@param digits The pointer that the DigitalDisplayGUI sets its digits to.
	*	
	**/
	DigitalDisplayGUI(GUI* gui, Point* topLeft, Color* cTop, Color* cBottom, int border,
		Color* digitsColour, Digits* digits, DigitalDisplay* dd);

	/** Destroys the digital display object.
	*
	*	Deletes the displayPosition, and block size from memory. Well that's the plan at least.
	*/
	~DigitalDisplayGUI();
	
	/**	Draws integer to the screen
	*
	*	If integer lies outside the range between 10^-digits_displayed +1 exclusive and 
	*	10^digits_displayed -1 inclusive, it is drawn as follows:
	*
	*	If the number is below 10^-digits_displayed +1 then it will draw
	*	integer modulus 10^-digits_displayed.
	*
	*	If the number is above 10^digits_displayed -1 then it will draw
	*	integer modulus 10^digits_displayed.
	**/
	int drawDigitalDisplayGUI();

	/** Unimplemented
	*
	*	Feel free to implement it for me. This would change the number of digits displayed.
	*	I dont want to do it because it may just screw up the entire screen if it overlaps stuff.
	**/
	setDigitsDisplayed(int i);

private:
	
	int tInteger;	/**<	Temporary integer used for display purposes. Clive is not sure
					*	if it's better to store the int and access it when required, or if
	*****************	it's quicker to just declare a new int each time you need it i mean, 
	*	it's only 2 bytes.... but i would like to know in C what is a better way of doing things.
	**/

	int tDisplayInteger;	/**< Temporary integer to be displayed, ranges from 0-9
							*	same reasons as the tInteger. **/
	
	Point*	displayPosition;	/**<	Position of the current digit to be displayed
								*
	*****************************
	*
	*	This point is used to describe the point where each digit is drawn.
	*	It changes as each digit is drawn. But reset each time the DigitalDisplayGUI it's drawn.
	*
	*************************************************************************/
};

#endif /* _HAVE_DIGITALDISPLAYGUI_H */