#include "multimine.h"
#include "MinefieldGUI.h"

Point* temp;
MinefieldGUI::MinefieldGUI(GUI* _gui, Minefield* _mf, Point* _topLeft, Color* _cTop, Color* _cBottom, int _border,
			Point* cbg_size, Color* cbg_cTop, Color* cbg_cBottom, int cbg_border, int cbg_dBorder):
BlockGUI(_gui, _topLeft, fieldSize_plusBorder = new Point(_border*2 + _mf->getSizeX() * (cbg_size->X), _border*2 + _mf->getSizeY() * cbg_size->Y),
		 _cTop, _cBottom, _border){
	mf = _mf;
	cellsBorderGUI = new DBlockGUI(_gui, cbg_pTop = new Point(), cbg_size, cbg_cTop, cbg_cBottom, cbg_border, cbg_dBorder, NULL);

	cgui = new CellGUI(gui);
}

MinefieldGUI::~MinefieldGUI(){
	delete cbg_pTop;
	delete cellsBorderGUI;
	delete fieldSize_plusBorder;
	delete cgui;

}

MinefieldGUI::mfChange(){
	fieldSize_plusBorder->X = border*2+mf->getSizeX() * (cellsBorderGUI->size->X);
	fieldSize_plusBorder->Y = border*2+mf->getSizeY() * (cellsBorderGUI->size->Y);
}

MinefieldGUI::drawCells(){
	drawBorder();
	for(int i=0;i<mf->getSizeX();i++){
		for(int j=0;j<mf->getSizeY();j++){
			drawCell(&Point(i,j));
		}
	}
}

MinefieldGUI::drawCells(SLList* cells){
	Point* current;
	cells->CurrentPtr = cells->Head;
	while(cells->Advance()){
		current = (Point*)cells->CurrentPtr->Data;
		redrawCell(current);
	}
	
}

MinefieldGUI::drawCell(Point* cell){
	*cbg_pTop = *topLeft+Point(border +cell->X * cellsBorderGUI->size->X, border + cell->Y * cellsBorderGUI->size->Y);
	cellsBorderGUI->dblock = mf->cells(cell);
	Cell* c = mf->cells(cell);
	cellsBorderGUI->drawBorder();
	switch(c->cState){
		case Cell::untouched:
			
			break;
		case Cell::flagged:
		{
			Color colour;
			if(c->player != -1)
				colour.SetValue(gui->gcc->players[c->player].colour->GetValue());
			else
				colour.SetValue(Color.Gray);
			cgui->drawPicture(cgui->flag, &colour, cellsBorderGUI->topLeft);
			break;
		}
		case Cell::pressed:
			
			break;
		case Cell::revealed:
			drawRevealed(cellsBorderGUI, c);
			break;

	}
}

MinefieldGUI::redrawCell(Point* cell){

	*cbg_pTop = *topLeft+Point(border +cell->X * cellsBorderGUI->size->X, border + cell->Y * cellsBorderGUI->size->Y);
	cellsBorderGUI->dblock = mf->cells(cell);
	Cell* c = mf->cells(cell);
	
	switch(c->cState){
		case Cell::untouched:
		{
			if(c->pState == Cell::flagged){
				cgui->wipePicture(cgui->flag, cellsBorderGUI->topLeft);
			}
			if(c->pState == Cell::pressed){
				cellsBorderGUI->wipeShadow();
				cellsBorderGUI->drawBorder();
			}
			break;
		}
		case Cell::flagged:
		{
			if(c->pState == Cell::untouched){
				
			}
			if(c->pState == Cell::pressed){
				cellsBorderGUI->wipeShadow();
				cellsBorderGUI->drawBorder();	
			}
			cgui->drawPicture(cgui->flag, gui->gcc->players[c->player].colour, cellsBorderGUI->topLeft);
			break;
		}
		case Cell::pressed:
		{
			if(c->pState == Cell::flagged){
				cgui->wipePicture(cgui->flag, cellsBorderGUI->topLeft);
			}
			if(c->pState == Cell::untouched){
				
			}
			cellsBorderGUI->wipeBorder();
			cellsBorderGUI->drawBorder();
			break;
		}
		case Cell::revealed:
		{
			if(c->pState == Cell::flagged){
				cgui->wipePicture(cgui->flag, cellsBorderGUI->topLeft);
				cellsBorderGUI->wipeBorder();
				cellsBorderGUI->drawBorder();
			}
			if(c->pState == Cell::pressed){
				
			}
			if(c->pState == Cell::untouched){
				cellsBorderGUI->wipeBorder();
				cellsBorderGUI->drawBorder();
			}
			drawRevealed(cellsBorderGUI, c);
			break;
		}
	}
}

int MinefieldGUI::drawRevealed(DBlockGUI* cellgui, Cell* c){
	SolidBrush* sbrush = new SolidBrush(Color.Transparent);
	if(c->player != -1){
		Color* cPlayer = gui->gcc->players[c->player].colour;
		Color together = Color(	gui->cBg->GetR() + (cPlayer->GetR() - gui->cBg->GetR()) / 6,
								gui->cBg->GetG() + (cPlayer->GetG() - gui->cBg->GetG()) / 6,
								gui->cBg->GetB() + (cPlayer->GetB() - gui->cBg->GetB()) / 6);
		sbrush->SetColor(together);
	}

	Brush* brush = sbrush->Clone();
	gui->g->FillRectangle(brush, 
		cellsBorderGUI->topLeft->X+cellsBorderGUI->dBorder,
		cellsBorderGUI->topLeft->Y+cellsBorderGUI->dBorder,
		cellsBorderGUI->size->X-cellsBorderGUI->dBorder,
		cellsBorderGUI->size->Y-cellsBorderGUI->dBorder);

	if(c->isBomb){
		cgui->drawPicture(cgui->bomb, gui->cPlayer, cellsBorderGUI->topLeft);
	}
	else{
		if(gui->gcc->getEndGame()){
			/*
			if(c->cState == Cell::flagged && c->isBomb){
				cgui->drawPicture(cgui->falseBomb, gui->cPlayer, cellgui->topLeft);
			}
			else{
				if(c->isBomb){
					cgui->drawPicture(cgui->bomb, Color(0,0,0,0), cellgui->topLeft);
				}

			}
			*/
		}
		if(c->neighbourBombs != 0){
			cgui->drawPicture(c->neighbourBombs, gui->cPlayer, cellsBorderGUI->topLeft);
		}
	}
	return 0;
}

Point* MinefieldGUI::getCellFromPoint(Point* ml){
	return new Point(	(ml->X - (topLeft->X + border) )/cellsBorderGUI->size->X,
						(ml->Y - (topLeft->Y + border) )/cellsBorderGUI->size->Y);
}