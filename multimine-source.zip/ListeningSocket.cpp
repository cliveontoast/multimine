#include "multimine.h"
#include "ListeningSocket.h"

int ListeningSocket::normalFlags = FD_READ | FD_WRITE | FD_ACCEPT;

ListeningSocket::ListeningSocket(Network* _n, int _port){
	n = _n;
	int port = _port;

	sock = socket(PF_INET, SOCK_STREAM, 0);
	if( sock == INVALID_SOCKET){
		MMPSocket::constructErrorMessage(MMPSocket::se_socket_not_created, WSAGetLastError(), __FILE__, __LINE__, NULL, port );
	}

	registerSocket(SERVER_LISTENING_SOCKET_EVENT, normalFlags);

/*	socket_event = WSACreateEvent();
	if(WSAEventSelect(sock, socket_event, eventFlags) == SOCKET_ERROR){
		constructErrorMessage(se_eventselect, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
	}
*/

	Bind(port);
	Listen();

}

ListeningSocket::Destruct_ListeningSocket(){
	if(closesocket(sock) == SOCKET_ERROR){
		MMPSocket::constructErrorMessage(MMPSocket::se_listen, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
	}
}

ListeningSocket::registerSocket(int wMsg, int flags){
	if(	WSAAsyncSelect(sock, n->gc->hWnd, 
		wMsg, flags) == SOCKET_ERROR){
		MMPSocket::constructErrorMessage(MMPSocket::se_asyncselect, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
	}
}

ListeningSocket::Listen(){
	if(listen(sock, 0) == SOCKET_ERROR){
		MMPSocket::constructErrorMessage(MMPSocket::se_listen, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
	}
}	

ListeningSocket::Bind(short port){
	address.sin_family = AF_INET;
	address.sin_port =  htons(port);
	address.sin_addr.s_addr = INADDR_ANY;

	if(bind(sock, (sockaddr*)&address, sizeof(address)) == SOCKET_ERROR){
		MMPSocket::constructErrorMessage(MMPSocket::se_bind_failure, WSAGetLastError(), __FILE__, __LINE__, NULL, port );
	}
}

void ListeningSocket::OnClose(){
	if(closesocket(sock) == SOCKET_ERROR){
		MMPSocket::constructErrorMessage(MMPSocket::se_close_socket, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
	}
	n = NULL;
}

void ListeningSocket::OnAccept(){
	sockaddr_in new_address;
	int address_length = sizeof(new_address);

	registerSocket(0, 0);

	SOCKET new_sock = accept(sock, (sockaddr*)&new_address, &address_length);
	if(new_sock == INVALID_SOCKET){
		MMPSocket::constructErrorMessage(MMPSocket::se_new_client_socket_creation, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
	}

	registerSocket(SERVER_LISTENING_SOCKET_EVENT, normalFlags);
	// while loop to see if there are any more.
	n->addMMPSocket(new_sock, new_address, address_length);
}

ListeningSocket::incomingError(short error,short event){
	switch(event){
	case FD_CONNECT:
	case FD_READ:
	case FD_WRITE:
	case FD_OOB:
	case FD_ACCEPT:
	case FD_CLOSE:
	case FD_QOS:
	case FD_GROUP_QOS:
	case FD_ROUTING_INTERFACE_CHANGE:
	case FD_ADDRESS_LIST_CHANGE:
	default:
		MMPSocket::constructErrorMessage(MMPSocket::se_reached_unallowed_default_case, error, __FILE__, __LINE__, 
			inet_ntoa(address.sin_addr), ntohs(address.sin_port));
	}
}


ListeningSocket::incomingEvent(short event){
	switch(event){
	case FD_ACCEPT:
		OnAccept();	
		break;
	case FD_READ:
	case FD_WRITE:
	case FD_OOB:
	case FD_CONNECT:
	case FD_CLOSE:
	case FD_QOS:
	case FD_GROUP_QOS:
	case FD_ROUTING_INTERFACE_CHANGE:
	case FD_ADDRESS_LIST_CHANGE:
	default:
		MMPSocket::constructErrorMessage(MMPSocket::se_reached_unallowed_default_case, NULL, __FILE__, __LINE__, 
			inet_ntoa(address.sin_addr), ntohs(address.sin_port));
	}
}