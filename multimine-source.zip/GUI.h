#ifndef _HAVE_GUI_H
#define _HAVE_GUI_H 1

#include "multimine.h"
/*
#include "Digits.h"
#include "CellGUI.h"
#include "DigitalDisplay.h"
#include "DigitalDisplayGUI.h"
#include "Minefield.h"
#include "GameController.h"
*/

//#include "SmilieGUI.h"

//#include "Topbar.h"

//#include "GameControllerClient.h"
//#include "MinefieldGUI.h"
//#include "Smilie.h"


/** Puts all the graphical requirements into one nice class.
*	This handles all the drawing objects, and grahics objects.
*/
class GUI {

public:

	/** All the mouse actions that a GUI accepts and passes along, they should be pretty self
	*	explanatory.
	*/
	enum Mouse_Action {
		ma_mouse_move,
		ma_left_down,
		ma_left_up,
		ma_middle_down,
		ma_middle_up,
		ma_right_down,
		ma_right_up,
	};

	Pen*	pen;	/**<	The Pen object that this BlockGUI uses to draw itself.
					*
	*****************
	*
	*	The pen object is usually created by the object that created this BlockGUI and any
	*	items that it would use to draw to the screen.
	*
	*************************************************************************/

	Graphics* g_memory;	/**<	A pointer to a graphics pointer
					*
	*****************
	*
	*	This pointer holds the address of the pointer to a graphics object.
	*	The BlockGUI will use the graphics object to draw itself.
	*
	*************************************************************************/

	Graphics* g;

	Graphics* g_screen;

//	SolidBrush* solidBrush;
	Brush* brush;
	HDC		hdc;
	HDC		hdcMem;


	HWND		hWnd;
	PAINTSTRUCT  ps;

	int thickShadow;// = 3;
	int thinShadow;// = 1;
	int normShadow;// = 2;

	Color* cBg;//= new Color(Color.LightGray);
	Color* cDark;// = new Color(Color.DarkGray);
	Color* cLight;// = new Color(Color.White);

	Color* cPlayer; /**< this will be moved later on i hope!!! meanwhile its the colour of the player */

//	Point* start;//(9,9);
	Point* brick;//(16,16);
	Point* bricks;//(30, 16);
	Point* board;//(thickShadow*2+bricks.X*brick.X, thickShadow*2+bricks.Y*brick.Y);

	Point* pSmilie; /**< The point where the smilie display is located. */ // = new Point(start.X+normShadow+board.X/2, start.Y+6);

	Point* pBombCounter; /**< The point where the bomb counter display is located. */

	Point* pTimer; /**< The point where the timer displaye is located. */

	Point* pTopbar; /**<	The point where the top bar begins. */

	Point* clientArea;	/**< The total client area of the GUI, this means everything in the GUI!*/

	Point* spacing;	/**< The spacing between the edge of the window on the right, and the space between 
					*	the top bar and minefield height. */

	Digits* d;
	SmilieGUI* sgui;
	CellGUI* cellgui;


	Topbar* tb;	/**< The top bar for the gui. */

	DigitalDisplayGUI* tgui; /**< timer counter gui */

	DigitalDisplayGUI* bgui; /**< bomb counter gui */

	Point* mf_tl;	/**< the top left of the minefield */
	Point* blockSize;	/**< the size of the cells in the minefield */

	GameControllerClient* gcc; /**< The pointer to the game controller associated with this GUI */

	MinefieldGUI* mfgui;

	HBRUSH g_hbrBackground;

	bool adjusted;


	/** Creates a GUI... dunno what else.. i'm sure there's more to it... but at the moment
	*	i'm the only one working on this project so documentation doesnt matter right?
	*	@param dwStyle Sets the GUI's dwStyle to this value.
	*	@param bMenu Sets the GUI's bMenu to this value.
	*	@param dwExStyle Sets the GUI's dwExStyle to this value.
	*/
	GUI(HWND hWnd, GameControllerClient* gcc, BOOL bMenu, DWORD dwStyle, DWORD dwExStyle);
	~GUI();

	int paint();

	int draw();

	bool mouseEvent(POINTS p, Mouse_Action mouse_action, int button_state);

	bool addSmilie(Smilie* s);

	bool addTopbar();

	bool addBombCounter(DigitalDisplay* t);

	void redrawSmilie();

	bool addMinefield(Minefield* mf);

	void redrawMinefieldCell(Point* cell);

	bool addTimer(DigitalDisplay* t);

	void redrawDigitalDisplayGUI(DigitalDisplayGUI* ddgui);
	
	/** Adjusts the window Size by using the dwStyle, bMenu, dwExStyle, minefield, and 
	*	the desired client area.
	*	@return True if the window changes size, false otherwise.
	*/
	bool adjustWindowSize();

	bool adjustClientArea();

	void drawCells(SLList* list);

	void changeMyColour(COLORREF colour);

private:

	DWORD dwStyle; /**<	Specifies the window style of the window whose required size is to 
				   *	be calculated.
	****************
	*
	*	Note that you cannot specify the WS_OVERLAPPED style. 
	*	 
	*/
	
	BOOL bMenu;	/**< Specifies whether the window has a menu.*/

	HBITMAP hbmMem;	/**< The bitmap of the GUI window held in memory. */
	HBITMAP	hbmOld;	/**< The HDC's old bitmap... this needs to be saved so it can be 
						written back when the HDC is destroyed. */	
	HBRUSH hbrBkGnd;

	DWORD dwExStyle;	/**< Specifies the extended window style of the window whose required 
						*	size is to be calculated, For more information, see CreateWindowEx. */

};

#endif /* _HAVE_GUI_H */