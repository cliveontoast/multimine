#ifndef _HAVE_SMILIE_H
#define _HAVE_SMILIE_H 1

#include "multimine.h"
/*
#include "DBlock.h"
#include "GameControllerClient.h"
#include "GUI.h"
*/
/* are these necessary? */
#define SMILE	0
#define SHADES	1
#define DEAD	2
#define SCARED	3
#define SCARED_DOUBLE	4
#define SCARED_LEFT		5


/** A Smilie is a Block with a picture of a smilie face that changes depending
*	on the actions of the user.
*
*/
class Smilie : public DBlock{

public:

	/** Defines all the states of a Smilie.
	*	<br><b>Smile</b>, The smilie is smiling.
	*	<br><b>Shades</b>, The smilie has some shades on.
	*	<br><b>Dead</b>, The smilie is dead
	*	<br><b>Scared</b>, The smilie is scared
	*	<br><b>Scared_double</b>, The smilie was scared and then gets left mouse button clicked on
	*	<br><b>Scared_left</b>, The smilie was in the scared_double, and now it's moved out of the smilie.
	**/
	enum STATE {
		Smile,
		Shades,
		Dead,
		Scared,
		Scared_double,
		Scared_left,
	};

	/** Creates a new Smilie. Reads in all the bitmaps to memory.
	*
	*/
	Smilie(GameControllerClient* gcc);

	/** Destroyes anything Smilie created, then nullifies itself.
	*	So far i dont know what that is going to be.. lets wait and see
	*/
	~Smilie();

	/** Handles the mouse event for the Smilie.
	*	@param mouseInSmilie True if the mouse is within the Smilie, false otherwise.
	*	@param mouse_action What mouse action has taken place,
	*	left/middle/right button down/up or mouse movement
	*	@param buttons_state A records the state of the buttons only left and middle matter
	*	@returns boolean if the smilie needs to be redrawn
	*/
	bool mouseEvent(bool mouseInSmilie, GUI::Mouse_Action mouse_action, int button_state);

	GameControllerClient*	gcc;	/**< The game controller that is associated with this smilie */

	STATE state;	/** Holds the state of the Smilie.
				*
	*************
	*
	*	This can be one of five states, smiling, depressed smiling, scared, dead, or shades
	*
	*************************************************************************/
private:
};

#endif /* _HAVE_SMILIE_H */