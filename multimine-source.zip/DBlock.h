#ifndef _HAVE_DBLOCK_H
#define _HAVE_DBLOCK_H 1

#include "multimine.h"



/** Depressable Block, just like block, but can be drawn as if depressed.
*	When a block is drawn depressed, only its top and left sides are drawn in 
*	the block's cBottom colour.
*/ 
class DBlock {

public:

	bool depressed;	/**<	True if the block is depressed, false otherwise
					*
	*****************
	*
	*	Holds the state of the blocks depression.
	*
	*************************************************************************/

	/** Creates the DBlock object.
	*	@param depressed sets DBlock::depressed to true if the block is depressed,
	*	false otherwise.
	*/
	DBlock(bool depressed);
	
	/**	Creates the DBlock object. Sets DBlock::depressed to false
	*	This function is useful if you are creating an array of DBlocks.
	*/
	DBlock();

	/** Destroys the DBlock object.
	*/
	~DBlock();

};

#endif /* _HAVE_DBLOCK_ */