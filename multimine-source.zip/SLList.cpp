#include "multimine.h"
#include "SLList.h"

SLList:: SLList()
{ 
	Head = new List;
	Tail=Head;
	CurrentPtr = Head;
	count = 0;
} 

SLList:: ~SLList()
{ ListPtr temp = Head;
  CurrentPtr = Head;
  while(CurrentPtr != NULL)
  {CurrentPtr = CurrentPtr->Next;
   delete temp;
   temp=CurrentPtr;
  }
}

void SLList::AddANode(){
	Tail->Next = new List;
	Tail=Tail->Next;
	count++;
}

ListPtr SLList::Previous(ListPtr index)
{ListPtr temp=Head;
 if(index==Head) //special case, index IS the head :)
  { return Head;
  }

 while(temp->Next != index)
 { temp=temp->Next;
 }
 return temp;
}

ListPtr SLList::Previous(long index)
{ ListPtr temp=Head;
  for(long count=0;count<index-1;count++)
  {temp=temp->Next;
  }
  return temp;
}
void SLList::PrintList()
{ListPtr temp = Head;

 cout<<"\n(Head) ";

 while(temp != NULL)
 {cout<<temp->Data<<" -> ";
  temp=temp->Next;
 }
 cout<<"NULL (Tail)"<<endl;
}

bool SLList::Advance(){ 
	if(CurrentPtr->Next != NULL){
		CurrentPtr=CurrentPtr->Next;
		return true;
	}
	else {
		return false;
	}
}

void SLList::Rewind()
{ if(CurrentPtr != Head)
  { CurrentPtr=Previous(CurrentPtr);
  }
}
void SLList::DeleteANode(ListPtr corpse) //<-- i thought it  was funny :)
{ ListPtr temp;

  if(corpse == Head) //case 1 corpse = Head
   {temp=Head;
    Head=Head->Next;
    delete temp;
   }
  else if(corpse == Tail) //case 2 corpse is at the end
  { temp=Previous(corpse);
    temp->Next=NULL;
    delete corpse;
    Tail=temp;
  }
  else //case 3 corpse is in middle somewhere
  {temp=Previous(corpse);
   temp->Next=corpse->Next;
   delete corpse;
  }
	count--;
  CurrentPtr=Head; //Reset the class tempptr
}


