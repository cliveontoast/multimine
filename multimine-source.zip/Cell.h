#ifndef _HAVE_CELL_H
#define _HAVE_CELL_H

#include "multimine.h"
//#include "DBlock.h"


/** A cell is a single block in the minefield.
*	It inherits the depressed attribute from the DBlock
*/
class Cell : public DBlock {
public:
	/** Describes the current state of the cell. This can be one of four values,
	   <br><b>pressed</b>, the cell has been pressed down
	   <br><b>flagged</b>, the cell has been flagged by a player
	   <br><b>revealed</b>, the cell has been revealed (and is therefore depressed too)
	   <br><b>untouched</b>, none of the othe values, it's undepressed, not flagged, and not revealed. */
	enum STATE {
		untouched, 
		pressed, 
		flagged, 
		revealed,
	};

	clear();

	bool isBomb;	/**<	If this cell holds a bomb, then this is set to true, it is false otherwise.*/

	int  neighbourBombs;	/**< the number of neighbours surrounding this cell contain bombs. */

	char player;	/**<	The player's number who revealed the cell */

	STATE cState;	/**< The current state of the cell. */

	STATE pState; /**< The previous state of the cell. */


	/**	Creates a new empty Cell.
	*
	*	When the cell is created, it sets the following variables to the following values:
	*
	*	isBomb set to false.
	*	neighbourBombs set to zero.
	*	player set to zero.
	*	set cState to untouched.
	*	set pState to untouched.
	*/
	Cell();

	/** Destroys the cell
	*
	*	No variables are deleted as none are created.
	*/
	~Cell();

	/** Sets the cell's cState to flagged or unflagged depending on the current state.
	*	@param player the player who is flagging or unflagging the cell. 
	*	This is set  to the game controller's current player
	*	@param player_zero_No the clients player number that isnt 0
	*	@return True if the cell is now flagged, false otherwise
	*/
	bool flag(int player, int player_zero_No, bool* flagged_now);

	/**	Reveals the cell and assigns the player to that cell
	*	@param player the player who is revealing the cell
	*	@param neighbourBombs A pointer that will be overwritten with the number of 
	*	neigbouring bombs the cell has.
	*	@return true if the cell is set to revealed, false otherwise
	*/
	bool reveal(int _player, int* _neighbourBombs, bool revealing_Surroundings, int player_at_zero, Score::scoreSheet* score);

	/**	Depresses a cell
	*	@return true if it sucessfully undepresses the cell, false if it was already depressed.
	*/
	bool depress();

	/**	Undepresses a cell
	*	@return	true if it sucessfully undepresses the cell, false if it was already depressed.
	*/
	bool undepress();

};

#endif /* _HAVE_CELL_H */