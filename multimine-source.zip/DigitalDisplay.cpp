#include "multimine.h"
#include "DigitalDisplay.h"

DigitalDisplay::DigitalDisplay(int _digits_displayed, int _integer){
	digits_displayed = _digits_displayed;
	pinteger = new int;
	pint_created = true;
	*pinteger = _integer;
}

DigitalDisplay::DigitalDisplay(int _digits_displayed, int* integer){
	digits_displayed = _digits_displayed;
	pinteger = integer;
	pint_created = false;
}

int DigitalDisplay::getInt(){
	return *pinteger;
}

int* DigitalDisplay::getPInt(){
	return pinteger;
}

void DigitalDisplay::setInt(int i){
	*pinteger = i;
}

void DigitalDisplay::plusplus(){
	*pinteger = *pinteger + 1;
}

void DigitalDisplay::minusminus(){
	*pinteger = *pinteger - 1;
}

DigitalDisplay::~DigitalDisplay(){
	if(pint_created)
		delete pinteger;
	
}