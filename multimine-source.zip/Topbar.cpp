#include "multimine.h"
#include "Topbar.h"

Topbar::Topbar(GUI* gui, DigitalDisplayGUI* _timer, DigitalDisplayGUI* _bomb_counter, SmilieGUI* _smilie,
			   Point* topLeft, Color* cTop, Color* cBottom, int border):
BlockGUI(gui, topLeft, size = new Point(0,0), cTop, cBottom, border){
	timer = _timer;
	bombCounter = _bomb_counter;
	smilie = _smilie;
	spacing = new Point(6, 6);
	players = new SLList;
}

Topbar::~Topbar(){
	delete size;
	delete spacing;
	delete players;
}

/** Adds a player to the top bar, finds where to put it, and changes its size if required.
*	@param player The player number of the new player. 
*/
Topbar::addPlayer(Player* player){
	players->AddANode();
	players->Tail->Data = (long)player;
	player->dd = new DigitalDisplay(4, &(player->score));
	player->ddgui = new DigitalDisplayGUI(gui, player->tl, gui->cDark, gui->cLight, 
					1, player->colour, gui->d, player->dd);
	
	requestRedraw();
}

Topbar::deleteAllPlayers(){
	players->CurrentPtr = players->Head;
	Player* cplayer;
	while(players->Advance()){
		cplayer = (Player*)players->CurrentPtr->Data;
		delete cplayer->dd;
		delete cplayer->ddgui;
		cplayer->dd = NULL;
		cplayer->ddgui = NULL;

		players->DeleteANode(players->CurrentPtr);
	}
	requestRedraw();
}

/** Deletes a player from the top bar.
*	@param player The player number of the player to delete.
*	@return True if it finds and deletes the player, false otherwise.
*/
bool Topbar::delPlayer(Player* player){
	players->CurrentPtr = players->Head;
	Player* cplayer;
	while(players->Advance()){
		cplayer = (Player*)players->CurrentPtr->Data;
		if(cplayer == player){
			players->DeleteANode(players->CurrentPtr);
			delete cplayer->dd;
			cplayer->dd = NULL;
			delete cplayer->ddgui;
			cplayer->ddgui =NULL;
			break;
		}
	}
	requestRedraw();
	return true;
}
Topbar::requestRedraw(){
	gui->adjusted = false;
	PostMessage(gui->gcc->hWnd, WM_PAINT, 0, 0);
}

/** finds the minimum width that this top bar requires
*	@return the minimum width required to display the bar.
*/
int Topbar::getMinWidth(){
	return timer->size->X + 
		bombCounter->size->X + 
		smilie->size.X + 
		spacing->X*5 + 
		((Player*)(players->Head->Next->Data))->ddgui->size->X + 
		border*2;
}

/** finds the minimum height that is required for this bar
*	@param width The width the bar wants to be.
*	@return the minimum height required to display the bar.
*/
int Topbar::getMinHeight(int width){
	int heightcount = 1;
	players->CurrentPtr = players->Head;
	players->Advance();
	width -= border*2;
	bool new_line = true;
	Player* cplayer = (Player*)players->CurrentPtr->Data;
	cplayer->row = heightcount;
	int old_width = 0;
	heightcount++;
	bool other_players = false;
	int cwidth=0;
	while(players->Advance()){
		cplayer = (Player*)players->CurrentPtr->Data;
		other_players = true;
		if(new_line){
			cwidth = spacing->X;
			cwidth += old_width;
			new_line = false;
		}
		cwidth += cplayer->ddgui->size->X + spacing->X;
		cplayer->row = heightcount;
		
		if(cwidth > width){
			old_width = cplayer->ddgui->size->X;
			new_line = true;
			heightcount++;
			cplayer->row = heightcount;
		}
	}
	if(!other_players)
		heightcount--;

	return (heightcount*(cplayer->ddgui->size->Y + spacing->Y) + spacing->Y + border*2);
}

Topbar::drawBorder(){
	BlockGUI::drawBorder();
}

/** Once the size has been agreed apon, this is called to set the locations
*	of all the top bar's children, the timer, smilie etc...
*	assumes the topLeft spot has been set!
*/
Topbar::setDisplayCoordinates(){
	players->CurrentPtr = players->Head;
	players->Advance();
	Player* cplayer = (Player*)players->CurrentPtr->Data;
	cplayer->tl->X = topLeft->X + border + spacing->X;
	cplayer->tl->Y = topLeft->Y + border + spacing->Y;

	int beginning = cplayer->tl->X;

	timer->topLeft->X = topLeft->X + size->X - border - spacing->X - timer->size->X;
	timer->topLeft->Y = cplayer->tl->Y;

	bombCounter->topLeft->X = timer->topLeft->X - spacing->X - bombCounter->size->X;
	bombCounter->topLeft->Y = timer->topLeft->Y;

	smilie->setTopLeft(MIN(bombCounter->topLeft->X-spacing->X-smilie->size.X,topLeft->X+size->X/2-smilie->size.X), timer->topLeft->Y);

	bool new_line = true;
	int cX, cY = topLeft->X + border + spacing->Y, cLine=1;
	while(players->Advance()){
		cplayer = (Player*)players->CurrentPtr->Data;
		
		if(cplayer->row != cLine){
			new_line = true;
			cLine = cplayer->row;
		}
		if(new_line){
			cX = beginning;
			cY += cplayer->ddgui->size->Y + spacing->Y;
			new_line = false;
		}
		
		cplayer->tl->X = cX;
		cplayer->tl->Y = cY;

		cX += cplayer->ddgui->size->X + spacing->X;

	}
}
