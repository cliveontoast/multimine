#include "multimine.h"
#include "BlockGUI.h"

Point	BlockGUI::one_one = Point(1,1);

BlockGUI::BlockGUI(GUI* _gui, Point* _topLeft, Point* _size, Color* _cTop, Color* _cBottom, char _border){
	topLeft = _topLeft;
	size = _size;
	bottomRight = new Point();
	
	cTop = _cTop;
	cBottom = _cBottom;
	
	gui = _gui;
	border = _border;
}

BlockGUI::~BlockGUI(){
	delete bottomRight;
}

int BlockGUI::drawBorder(){
	*bottomRight = *topLeft+*size-one_one;
	for(int i=0; i<border; i++){
		gui->pen->SetColor(*cTop);
		gui->g->DrawLine(gui->pen, topLeft->X+i, topLeft->Y+i, topLeft->X+i, bottomRight->Y-i-1);
		gui->g->DrawLine(gui->pen, topLeft->X+i, topLeft->Y+i, bottomRight->X-i-1, topLeft->Y+i);
		gui->pen->SetColor(*cBottom);
		gui->g->DrawLine(gui->pen, bottomRight->X-i, bottomRight->Y-i, bottomRight->X-i, topLeft->Y+i+1);
		gui->g->DrawLine(gui->pen, bottomRight->X-i, bottomRight->Y-i, topLeft->X+i+1, bottomRight->Y-i);
	}
	return 0;
}

int BlockGUI::wipeBorder(){
	Color cBottom_real = *cBottom;
	*cBottom = *(gui->cBg);
	Color cTop_real = *cTop;
	*cTop = *(gui->cBg);
	drawBorder();
	*cBottom = cBottom_real;
	*cTop = cTop_real;
	return 0;
}
