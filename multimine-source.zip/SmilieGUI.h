#ifndef _HAVE_SMILIEGUI_H
#define _HAVE_SMILIEGUI_H 1

#include "multimine.h"
/*
#include "DBlockGUI.h"
#include "GUI.h"
#include "Smilie.h"
#include "BlockGUI.h"
*/


/** A SmilieGUI is a DBlockGUI with a smilie face in the middle that changes depending
*	on the actions of the user.
*
*/
class SmilieGUI : public DBlockGUI{

public:
	
	

	static Point size;	/**<	The size of a Smilie block. */
	static Point spot;	/**<	The spot in the Smilie where pictures are drawn. */
	static Point depressedSpot;	/**<	The spot in the depressed Smilie where pictures are drawn. */
	static int outer_border; /**< The border of the outer block */
	static int border;	/**< The border of the smilie block */
	static Color cDef;	/**< The colour of the bitmaps background */	
	static Point faceSize;	/**< The size of the face bitmaps. */

	/** Creates a new Smilie.
	*	See Block to see what topLeft, pen, cTop, cBottom, g, border are
	*	@param cBackground is the background colour of the entire window.
	*/	
	SmilieGUI(GUI* gui, Point* topLeft, Color* cTop, Color* cBottom, Color* cBackground, Smilie* smilie);
		
	/** Destroyes anything Smilie created, then nullifies itself.
	*	So far i dont know what that is going to be.. lets wait and see
	*/	
	~SmilieGUI();

	/** Draws the state of the smilie.
	*
	*/
	int drawSmilie();
	
	/** Tests whether or not the point p is found within the smilie object
	*	@param p The point where the mouse has just clicked
	*/
	bool pointInSmilie(POINTS* p);

	void setTopLeft(int x, int y);

private:
	Bitmap*		smilies[4];		/**< The array where the smilies bitmaps are stored. 
								*
	*****************************
	*
	*	position 0 to 9 holds the bitmaps for their respective number.
	*	Position Digits::dash holds... you guessed it, the dash. Position Digits::nothing holds...
	*	yup, the nothing bitmap.
	*
	**/

	BlockGUI* outer;	/**<	A smilie requires outer block.. it's just the way it is. */
	
	Point* outer_topLeft;	/**< The position of the outer top left spot */
	Point* outer_size;		/**< the position of the outer block's size */

	Color*	cBackground;	/**< The colour of the background of minesweeper. */

	Smilie* smilie;	/**< Pointer to the Smilie to be drawn. */
};

#endif /* _HAVE_SMILIEGUI_H */