#include "multimine.h"
#include "Minefield.h"



SLList* revealedCells;
bool revealingCells = false;

Minefield::Minefield(Point* size, GameController* gc){
	Minefield(size->X, size->Y, gc);
}

Minefield::Minefield(int x, int y, GameController* _gc){
	field = NULL;
	size = new Point(0, 0);
	resize(x, y);
	bombs = 0;
	gc = _gc;

	previousCell = new Point(-3,-3);	/**< The previous cell the mouse was over */
}

Minefield::~Minefield(){
	delete [] field;
	delete size;
}

bool Minefield::resize(Point* size){
	resize(size->X, size->Y);
	return true;
}

bool Minefield::resize(int x, int y){
	if(size->X == x && size->Y == y){
		for(int i=0;i<(x+2)*(y+2);i++){
			field[i].clear();
		}
	}
	else {
		delete [] field;
		size->X = x;
		size->Y = y;
		field = new Cell[(size->X+2)*(size->Y+2)];
	}

	Score::scoreSheet score;
	int tmp;

	for(int i=-1;i<size->X+1;i++){
		cells(i, -1)->reveal(0, &tmp, false, 0, &score);
		cells(i, size->Y)->reveal(0, &tmp, false, 0, &score);
	}
	for(int j=-1;j<size->Y+1;j++){
		cells(-1, j)->reveal(0, &tmp, false, 0, &score);
		cells(size->X, j)->reveal(0, &tmp, false, 0, &score);
	}

	return true;
}

void Minefield::randomizeBomb(Point* b){
	b->X = rand() % (size->X);
	b->Y = rand() % (size->Y);
}

int Minefield::populate(int _srand, int _bombs){
	bombs = _bombs;
	randSeed = _srand;
	srand(randSeed);

	Point bomb_position = Point(); //this is the point to place the next bomb
	int max_retries = 10; //a counter for the maximum retries before failure

	randomizeBomb(&bomb_position);

	int bombs_created = 0;
	int attempts;
	while (bombs_created < bombs){

		attempts = 0;

		while (true){
			if (attempts > max_retries){
				return MAX_RETRY_LIMIT_ERROR;
			}
			if (cells(&bomb_position)->isBomb){
				attempts++;
				randomizeBomb(&bomb_position);
			}
			else{
				cells(&bomb_position)->isBomb = true;

				for(int i=-1;i<2;i++)
					for(int j=-1;j<2;j++){ //this does ++ the actual bomb position, but who cares
						cells(bomb_position.X+i,bomb_position.Y+j)->neighbourBombs++;
					}
				bombs_created++;
				randomizeBomb(&bomb_position);
				break;
			}


		}
	}
	hash=0;
	for(int i=1;i<=size->X;i++){
		for(int j=1;j<=size->Y;j++){
			if(cells(i,j)->isBomb)
				hash += i*j;
		}
	}

	return ARRAY_POPULATED;
}

bool Minefield::depress(Point* cell){
	return cells(cell)->depress();
}

bool Minefield::undepress(Point* cell){
	return cells(cell)->undepress();
}

bool Minefield::reveal(Point* cell, int player, bool revealing_surroundings, Score::scoreSheet* score, bool first_revealer){
	int n=-1;
	bool r = cells(cell)->reveal(player, &n, revealing_surroundings, gc->players[0].playerNo, score);
	if(n == 0){
		revealSurroundings(cell, player, score);
	}
	if(r){
		Score::getPointsFromRevealing(this, gc->gameType, cell, revealing_surroundings, first_revealer, score);
	}
	return r;
}

bool Minefield::flag(Point* cell, int player, Score::scoreSheet* score){
	bool flagged ;
	bool ret = cells(cell)->flag(player, gc->players[0].playerNo, &flagged);
	if(ret)
		Score::getPointsFromFlaging(this, gc->gameType, cell, flagged, score);
	return ret;
}

bool Minefield::isEndOfGame(){
	for(int i=0;i<(size->X+2)*(size->Y+2);i++){
		if(field[i].cState == Cell::untouched){
			return false;
		}
	}
	return true;
}

void Minefield::getEndScoreForPlayer(Score::scoreSheet* score){
	for(int i=0;i<(size->X+2)*(size->Y+2);i++){
		if(!field[i].isBomb && field[i].cState == Cell::flagged && field[i].player == score->current_player){
			Score::getPointsFromBadFlagging(gc->gameType, score);
		}
	}
}

void Minefield::getSize(Point* _size){
	_size->X = size->X;
	_size->Y = size->Y;
}

int Minefield::getSizeX(){
	return size->X;
}

int Minefield::getSizeY(){
	return size->Y;
}

int Minefield::getRandSeed(){
	return randSeed;
}

Cell* Minefield::cells(Point* position){
	return cells(position->X, position->Y);
}

Cell* Minefield::cells(int i, int j){
	Cell* r = field;
	return &r[(i+1)*(size->Y+2)+(j+1)];
}

Minefield::removePlayer(int player){
//	if(this != NULL){
		for(int i=0;i<(size->X+2)*(size->Y+2);i++){
			if(field[i].player == player)
				field[i].player = -1;
		}
//	}
}

Minefield::mfReturnMessage Minefield::mouseEvent(int player, Point* p, GUI::Mouse_Action mouse_action, int button_state, Score::scoreSheet* score){
	//do stuff, redraw necessary (through redrawMinefieldCell(Point* cell);
	mfReturnMessage r = mfrm_nothing;
	//cout << "polly wally crappy " << p << " " << mouse_action << endl;
	switch(mouse_action){
		case GUI::ma_left_down:{
			if(depress(p)){
				gc->redrawMinefieldCell(p);
			}
			break;
		}
		case GUI::ma_left_up:{
			if(reveal(p, player, false, score, false)){
				gc->redrawMinefieldCell(p);
				r = mfrm_reveal_point;
			}
			break;
		}
		case GUI::ma_middle_down:{
			deUnpressSet(p, true);
			break;
		}
		case GUI::ma_middle_up:{
			int flag_count=0, x=p->X, y=p->Y;
			if(cells(p)->cState == Cell::revealed && !cells(p)->isBomb){
				for(int i=x-1;i<=x+1;i++){
					p->X = i;
					for(int j=y-1;j<=y+1;j++){
						p->Y = j;
						if(cells(i,j)->cState == Cell::flagged ||
							cells(i,j)->cState == Cell::revealed && cells(i,j)->isBomb == true)
							flag_count++;
					}
				}
				p->X=x;
				p->Y=y;
				if(flag_count == cells(p)->neighbourBombs){
					revealSurroundings(p, player, score);
					r = mfrm_reveal_surroundings_of_point;
				}
				else{
					deUnpressSet(p, false);
				}
			}
			else{
				deUnpressSet(p, false);
			}
			break;
		 }
		case GUI::ma_right_down:{
			if(flag(p, player, score)){
				gc->redrawMinefieldCell(p);
				r = mfrm_flag_point;
			}
			break;
		}
		case GUI::ma_right_up:{

		}
		case GUI::ma_mouse_move:{
			if(!p->Equals(*previousCell)){

				if(button_state & MK_LBUTTON){
					if(undepress(previousCell))
						gc->redrawMinefieldCell(previousCell);
					if(depress(p))
						gc->redrawMinefieldCell(p);

				}

				if(button_state & MK_MBUTTON){
					deUnpressSet(previousCell, false);
					deUnpressSet(p, true);
				}
			}
			break;
		}
	}
	previousCell->X = p->X;
	previousCell->Y = p->Y;
	return r;
}

void Minefield::deUnpressSet(Point* p, bool dep){
	int left, right, top, bottom, px, py;
	px = p->X;
	py = p->Y;

	left = MAX(p->X-1,0);
	right = MIN(p->X+1,size->X-1);
	top = MAX(p->Y-1,0);
	bottom = MIN(p->Y+1,size->Y-1);

	for(int i=left;i<=right;i++){
		p->X = i;
		for(int j=top;j<=bottom;j++){
			p->Y = j;
			if(dep){
				if(depress(p)){
					gc->redrawMinefieldCell(p);
				}
			}
			else{
				if(undepress(p)){
					gc->redrawMinefieldCell(p);
				}
			}
		}
	}
	p->X = px;
	p->Y = py;
}

void Minefield::revealSurroundings(Point* cell, int player, Score::scoreSheet* score){
	int x=cell->X;
	int y=cell->Y;
	bool firstRevealer = false;
	if(!revealingCells){
		revealedCells = new SLList();
		revealingCells = true;
		firstRevealer = true;
	}
	
	for(int i=MAX(0,x-1);i<=MIN(size->X-1,x+1);i++){
		cell->X = i;
		for(int j=MAX(0,y-1);j<=MIN(size->Y-1,y+1);j++){
			cell->Y = j;
			if(reveal(cell, player, true, score, firstRevealer)){
				Point* temp = new Point(cell->X, cell->Y);
				revealedCells->AddANode();
				revealedCells->Tail->Data = (long)temp;
			}
		}
	}
	if(firstRevealer){
		gc->revealCells(revealedCells);
		revealingCells = false;
		
		List* temp = revealedCells->Head;
		revealedCells->CurrentPtr = revealedCells->Head;
		
		while(revealedCells->CurrentPtr != NULL){
			revealedCells->CurrentPtr = revealedCells->CurrentPtr->Next;
			delete (Point*)temp->Data;
			temp=revealedCells->CurrentPtr;
		}
		delete revealedCells;
	}
	cell->X = x;
	cell->Y = y;
}

int Minefield::getHash(){
	return hash;
}