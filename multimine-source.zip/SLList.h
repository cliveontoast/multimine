#ifndef _HAVE_SLLIST_H
#define _HAVE_SLLIST_H 1

#include "multimine.h"

typedef struct List
{ 
	long Data;
  List* Next;
  List()
  {Next=NULL;
   Data=NULL;
  }
} List;
typedef List* ListPtr;


class SLList
{ public:
  SLList();
  ~SLList();
  int count;
  ListPtr Previous(ListPtr);
  ListPtr Previous(long);
  bool Advance();
  void Rewind();
  void AddANode();
  void PrintList();
  void DeleteANode(ListPtr);

  ListPtr Head,Tail,CurrentPtr;
};

#endif /* _HAVE_SLLIST_H */