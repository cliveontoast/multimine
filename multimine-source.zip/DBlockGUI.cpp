#include "multimine.h"
#include "DBlockGUI.h"

DBlockGUI::DBlockGUI(GUI* gui, Point* topLeft, Point* size, Color* cTop, Color* cBottom, int border, int _dBorder, DBlock* _dblock):
BlockGUI(gui, topLeft, size, cTop, cBottom, border){
	dBorder = _dBorder;
	dblock = _dblock;
}

DBlockGUI::~DBlockGUI(){

}


int DBlockGUI::drawBorder(){
	if(!dblock->depressed)
		BlockGUI::drawBorder();
	else {
		*bottomRight = *topLeft+*size-one_one;
		gui->pen->SetColor(*cBottom);
		for(int i=0;i<dBorder;i++){
			gui->g->DrawLine(gui->pen, topLeft->X+i, topLeft->Y+i, topLeft->X+i, bottomRight->Y);
			gui->g->DrawLine(gui->pen, topLeft->X+i, topLeft->Y+i, bottomRight->X, topLeft->Y);
		}
	}
	return 0;
}

int DBlockGUI::wipeShadow(){
	bool d = dblock->depressed;
	dblock->depressed = true;
	Color cBottom_real = *cBottom;
	//may need to initalise this, unsure about pointers.
	*cBottom = *(gui->cBg);
	drawBorder();
	*cBottom = cBottom_real;
	dblock->depressed = d;
	return 0;
}
