#include "multimine.h"
#include "DigitalDisplayGUI.h"

DigitalDisplayGUI::DigitalDisplayGUI(GUI* _gui, Point* topLeft, Color* cTop, Color* cBottom, 
					int border, Color* _digitsColour, Digits* _digits, DigitalDisplay* d):
BlockGUI(_gui, topLeft, block_size = new Point(d->digits_displayed*Digits.digitSize.X+border*2, 
									Digits.digitSize.Y+border*2), cTop, cBottom, border){
	digitsColour = _digitsColour;
	digits =  _digits;
	displayPosition = new Point();
	displayPosition->Y = topLeft->Y+border;
	dd = d;
}

DigitalDisplayGUI::~DigitalDisplayGUI(){
	delete displayPosition;
	delete block_size;
}

int DigitalDisplayGUI::drawDigitalDisplayGUI(){
	drawBorder();
	//if digitaldispalyguy was given a topleft set method, this would be unnecessary.
	displayPosition->X = topLeft->X+border+dd->digits_displayed*Digits.digitSize.X;
	displayPosition->Y = topLeft->Y+border;

	if(dd->getInt() < 0)
		tInteger =-dd->getInt();
	else
		tInteger=dd->getInt();

	for(int i=0;i<dd->digits_displayed-1;i++){
		tDisplayInteger = tInteger % 10;
		displayPosition->X -= Digits.digitSize.X;
		digits->drawDigit(&tDisplayInteger, digitsColour, displayPosition);
		tInteger /= 10;
	}
	
	tDisplayInteger = tInteger % 10;
	displayPosition->X -= Digits.digitSize.X;
	
	if(dd->getInt() < 0)
		digits->drawDigit(&Digits.dash, digitsColour, displayPosition);
	else
		digits->drawDigit(&tDisplayInteger, digitsColour, displayPosition);

	return 0;
}



