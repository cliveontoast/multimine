#ifndef _HAVE_TOPBAR_H
#define _HAVE_TOPBAR_H 1

#include "multimine.h"
/*
#include "GUI.h"
#include "BlockGUI.h"
#include "DigitalDisplayGUI.h"
#include "SmilieGUI.h"
#include "SLList.h"
*/

class Topbar : BlockGUI {
public:

	DigitalDisplayGUI* timer;	/**< The timer for the top bar. */

	DigitalDisplayGUI* bombCounter;	/**< The total count of the bombs left in the minefield */

	SmilieGUI* smilie;	/**< The smilie for this top bar. */

	SLList* players;	/**< The players to be drawn */

	Point* size;	/**< What the BlockGUI's size is set to, this can change depending on player numbers. */

	Point* spacing;	/**< The space horizontally between stuff, and vertically. */

	/** Creates a top bar given the inputs.
	*	@param gui sets the gui to this value.
	*	@param timer sets the timer to this value.
	*/
	Topbar(GUI* gui, DigitalDisplayGUI* timer, DigitalDisplayGUI* bomb_counter, SmilieGUI* smilie,
		Point* topLeft, Color* cTop, Color* cBottom, int border);

	~Topbar();

	/** Adds a player to the top bar, finds where to put it, and changes its size if required.
	*	@param player The player number of the new player. 
	*/
	addPlayer(Player* player);


	/** Deletes a player from the top bar.
	*	@param player The player number of the player to delete.
	*	@return True if it finds and deletes the player, false otherwise.
	*/
	bool delPlayer(Player* player);

	/** finds the minimum width that this top bar requires
	*	@return the minimum width required to display the bar.
	*/
	int getMinWidth();

	/** finds the minimum height that is required for this bar
	*	@param width The width the bar wants to be.
	*	@return the minimum height required to display the bar.
	*/
	int getMinHeight(int width);

	/** Once the size has been agreed apon, this is called to set the locations
	*	of all the top bar's children, the timer, smilie etc...
	*/
	setDisplayCoordinates();

	drawBorder();

	deleteAllPlayers();

	requestRedraw();

private:

};

#endif /* _HAVE_TOPBAR_H */