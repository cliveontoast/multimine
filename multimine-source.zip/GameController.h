#ifndef _HAVE_GAMECONTROLLER_H
#define _HAVE_GAMECONTROLLER_H 1

#include "multimine.h"
/*
#include "Player.h"
#include "DigitalDisplay.h"
#include "GUI.h"
#include "SLList.h"
#include "Minefield.h"
*/

/** The GameControllermmm is a class that holds all the objects required to play Multi-mine.
*	Built apon the GameController are it's two children, the GameControllerClient and
*	the GameControllerServer. The both have all the same methods but have different guts
*	within them. While the Client will draw it's information to the screen when the minefield
*	gets updated. The Server sends its "screen" to all the clients, via its IO class. They still
*	however are very similar but do slightly different things.
*
*/
class GameController {
public:

	HWND hWnd;
	HWND hWndChat;

	int gameType;

	static int gameTypes_count;
	static char* gameTypes[];

	static int minefieldSize_count;
	static char* minefieldSize[];

	char serverTitle[NAME_MAX];

	Player* players;	/**< The list of players. */

	DigitalDisplay* ddgt;	/**<	The digital Display Game Timer.
							*
	*************************
	*
	*	Both the client and sever require a Digital display timer, this is used to record
	*	the time since the beginning of the game.
	*
	*/

	DigitalDisplay* ddbc;	/**<	The digital display bomb counter. */

	int server_hash;

	Minefield* mf;	/**<	The minefield for the game
					*
	*****************
	*
	*	Both the client and server require a minefield class. This holds the information
	*	that is really the brains of the game. The most messages a GameController receives
	*	inevitably gets sent to the mf and the server.
	*
	*	Perhaps the client could wait on the answer of it's minefield class.. and if that's true
	*	then (and only then) send a message to the server. this minimises the number of messages
	*	passed between the two, and that's a good tihng.
	*
	*/
	bool endGame;	/**<	Has the game ended yet?
					*
	*****************
	*
	*	If it has, things like no more clicks accepted, and timer stops, etc happen.
	*
	*/

	int* currentPlayer; /**< The current player, set to 0 for client, realPlayer for server
						*
	*********************
	*
	*	This is used by the minefield's flag method. the game controller server and client
	*	differ in the number that this is set to... for reason of how the Cell class has been
	*	created. It could have been created another way which would mean this may not be necessary
	*	but that isnt important right now.
	*
	*/
	int realPlayer; /**< The number of the player
					*
	*****************
	*
	*	This is the same for both the client and server. the server should set its currentPlayer
	*	to the real player when it receives messages... Like the server changes the current/real player
	*	willy nilly depending on the messages it receives. For each message, it will set the player
	*	to some value.. and then the minefield will read this number if it's required
	*
	*/

	short maxPlayers;	/**< The maximum number of players for this game. */

	Network* net;	/**< The network for this game controller. */

	
	/** Creates a new game Controller object.
	*
	*	This creates a Digital Display, a new minefield, populates it...
	*	this may change later on during the project as the controller gets messages from
	*	dialog boxes to create objects and crap.. you never know.
	*	it also sets the endGame to false.
	*	@param maxPlayers the maximum number of players.
	*/
	GameController(HWND hWnd);

	createMinefield(int x, int y);

	virtual bool beginNewGame(int x, int y, int bombs, int seed, int gameType);

	virtual void GameOn();

	virtual void CARGameOff();

	virtual void setMaxPlayers(int _maxPlayers);

	/** Erases all used memory. Well that was the plan.
	*/
	~GameController();

	/** This method get's called when from the input (either from the GUI, or the IOclass) has
	*	been received, and now needs to do stuff!
	*	The game controller at the server only deals with minefield events and changing
	*	game controller variables. The Client cares about a lot more, such as creating a GUI,
	*	smilies.
	*	@param cell The cell in the minefield that has been affected by a mouse event.
	*	@param mouse_action The action that has happened this can be
	*
	*/
	virtual void mouseEventMinefield(int player, Point* cell, GUI::Mouse_Action mouse_action, int button_state);

	/** Should this only be in the game controller client?
	*/
	virtual void mouseEventSmilie(bool inSmilie, GUI::Mouse_Action mouse_action, int button_state);

	/** Should this only be in the game controller client?
	*/
	virtual void redrawSmilie();

	/** Redraw for the client
	*/
	virtual void redrawMinefieldCell(Point *cell);

	/** Reveals all these cells in this list
	*	game client needs to draw them, game server does nothing.
	*	quite a pointless exercise, perhaps i should create two minefield types.
	*	or just have a bool set to server/client.. and the minefield does checks on that.
	*/
	virtual void revealCells(SLList* list);

	/** Called by the inputoutput class to add a new player to the game.
	*	@param colour The colour of the player.
	*	@param name The 32 character name of this player.
	*	@param playerNo the number of the player.
	*	@param flags The flags variable for the player.
	*	@param score The score variable for the player.
	*/
	virtual void addPlayer(COLORREF colour, char* name, short playerNo); 

	/** Called to find out if a game controller is a client or server.
	*	@return true if it's client, false otherwise.
	*/
	virtual bool isClient();
	
	virtual void processErrorMessage(Exception e);
	getGameSizeInformation(int gameSize, int* height, int* width, int* bombs);

	comboSizeChange(int selected);

	static initChatDialog(HWND hWndChat);
	networkEvent(LPARAM lParam, SOCKET sock, UINT msg);
	static populateComboBoxes(HWND hWndChat);
	virtual void variableChange(int variable, int value);

	virtual void changePlayerName(int player, char* name);
	virtual void changePlayerColour(int player, COLORREF colour);
	virtual void PlayerHasLeft(int player);
	virtual void oneSecondHasPassed();
	virtual void incommingChatMessage(int player, int length, char* text);
	int getGameType();

	nameRandomizer(char* name);

	colourRandomizer(COLORREF* rgb);

private:
	/**	Sets the players, this wipes all the players and shouldnt run unless the game 
	*	controller was just started.
	*	@param mayPlayers the maximum number of players in this game controller
	*/

};


#endif /* _HAVE_GAMECONTROLLER_H */