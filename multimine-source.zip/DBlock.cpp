#include "multimine.h"
#include "DBlock.h"

DBlock::DBlock(bool _depressed){
	depressed = _depressed;
}

DBlock::DBlock(){
	depressed = false;
}

DBlock::~DBlock(){

}
