#include "GameControllerClient.h"

char* GameControllerClient::recent_servers_file = "Servers.nfo";
char* GameControllerClient::last_player_file = "Player.nfo";



GameControllerClient::GameControllerClient(HWND _hWnd, BOOL bMenu, DWORD dwStyle, DWORD dwExStyle):
GameController(_hWnd){

	hWnd = _hWnd;
	hWndClient = NULL;

	s = new Smilie(this);
	gui = new GUI(hWnd, this, bMenu, dwStyle, dwExStyle);

	gui->addTimer(ddgt);
	gui->addSmilie(s);
	gui->addBombCounter(ddbc);
	gui->addTopbar();

	gui->addMinefield(mf);
	beginNewGame(10, 10, 20, GetTickCount(), DEATHMATCH);
	
	
	setMaxPlayers(1);
	
	*currentPlayer = 0;
	realPlayer = 0;
	playerNum = 0;

	FILE* file;
	char name[NAME_MAX];
	char colHex[9];
	memset(name, 0, sizeof(name));
	COLORREF colour;

	if( (file = fopen(last_player_file, "r" )) == NULL ){
		nameRandomizer(name);
		colourRandomizer(&colour);
	}
	else {
		if(fgets(name, NAME_MAX, file) == NULL){
			nameRandomizer(name);
			colourRandomizer(&colour);
		}
		else {
			for(int i=0;i<NAME_MAX;i++)
				if(name[i] == '\n')
					break;
			name[i] = '\0';
			if(name[0] == '\0')
				nameRandomizer(name);
			if(fgets(colHex, 9, file) == NULL){
				colourRandomizer(&colour);
			}
			else {
				int c = strtol(colHex, NULL, 0x10);
				if(c == 0)
					colourRandomizer(&colour);
				else
					colour = (COLORREF)c;
			}
		}
		fclose(file);
	}
	

	addPlayer(colour, name, 0);

	endGame = false;

}

GameControllerClient::writePlayerSettings(){
	FILE* file;
	if( (file = fopen(last_player_file, "w" )) == NULL ){
		MessageBox(hWnd, "Could not write player settings to the storage device.\n\nThis just your player settings will not be remembered next time you load Multimine.", "Average Error", MB_OK | MB_ICONEXCLAMATION);
	}
	else {
		if(fprintf(file, "%s\n%X", players[0].name, players[0].colour->ToCOLORREF()) < 0){
			MessageBox(hWnd, "Could not write player settings to the file.\n\nThis just your player settings will not be remembered next time you load Multimine.", "Average Error", MB_OK | MB_ICONEXCLAMATION);
		}
	}
	fclose(file);
}


GameControllerClient::changeMyColour(COLORREF colour){
	if(colour != players[0].colour->ToCOLORREF()){
		if(net != NULL && endGame || net == NULL){
			GameController::changePlayerColour(0, colour);
			writePlayerSettings();
			if(net != NULL){
				Network::mmpMSG_client_change_colour msg;
				msg.colour = colour;
				net->sendMessage(Network::mmp_client_change_colour, &msg);
			}
			else{
				gui->redrawDigitalDisplayGUI(players[0].ddgui);	
			}
		}
	}
}

GameControllerClient::changeMyName(char* name){
	if(strcmp(name, players[0].name) != 0){
		GameController::changePlayerName(0, name);
		
		if(net != NULL){
			Network::mmpMSG_client_change_name msg;
			memcpy(msg.name, name, NAME_MAX);
			net->sendMessage(Network::mmp_client_change_name, &msg);
		}
		writePlayerSettings();
	}
}

void GameControllerClient::changePlayerName(int player, char* name){
	//deletePlayerFromList(player);
	GameController::changePlayerName(player, name);
	//addPlayerToList(player);
	InvalidateRect(GetDlgItem(hWndChat, IDC_LIST_PLAYERS), NULL, TRUE);
}

void GameControllerClient::changePlayerColour(int player, COLORREF colour){
	GameController::changePlayerColour(player, colour);
	if(player != 0 && players[player].playerNo != players[0].playerNo){
		gui->redrawDigitalDisplayGUI(players[player].ddgui);
	}
	else {
		gui->redrawDigitalDisplayGUI(players[0].ddgui);
	}
	
	InvalidateRect(GetDlgItem(hWndChat, IDC_LIST_PLAYERS), NULL, FALSE);

}

void GameControllerClient::addPlayerToList(int player){
	SendDlgItemMessage(hWndChat, IDC_LIST_PLAYERS, LB_ADDSTRING , 0, (LPARAM)player);
}

void GameControllerClient::deletePlayerFromList(int player){
	int playerInt = SendDlgItemMessage(hWndChat, IDC_LIST_PLAYERS, LB_FINDSTRINGEXACT, -1, (LPARAM)players[player].name);
	//int playerInt1 = SendDlgItemMessage(hWndChat, IDC_LIST_PLAYERS, LB_FINDSTRINGEXACT, -1, (LPARAM)player);
	int i = SendDlgItemMessage(hWndChat, IDC_LIST_PLAYERS, LB_DELETESTRING, playerInt, 0);
}



GameControllerClient::changeMaxPlayers(int _maxPlayers){

	Player temp;
	temp.colour->SetFromCOLORREF(players[0].colour->ToCOLORREF());
	memcpy(temp.name, players[0].name, NAME_MAX);
	
	setMaxPlayers(_maxPlayers);
	addPlayer(temp.colour->ToCOLORREF(), temp.name, 0);

}

void GameControllerClient::setMaxPlayers(int _maxPlayers){
	gui->tb->deleteAllPlayers();
	GameController::setMaxPlayers(_maxPlayers);
}

/*
GameControllerClient::setMaxPlayers(int _maxPlayers){
	for(int i=0;i<maxPlayers+1;i++){
		gui->tb->delPlayer(&players[i]);
	}
	GameController::setMaxPlayers(_maxPlayers);
	//gui->tb->addPlayer(&players[i]);
}
*/

GameControllerClient::initChatDialog(HWND _hWndChat){
	hWndChat = _hWndChat;
	GameController::initChatDialog(hWndChat);
	
	SendDlgItemMessage(hWndChat, IDB_START_STOP_GAME, WM_SETTEXT, 0, (LPARAM)"Ready\0");
	EnableWindow(GetDlgItem(hWndChat, IDB_START_STOP_GAME), TRUE);
	
	SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT, EM_SETREADONLY, (WPARAM)FALSE, 0);
	
	SendDlgItemMessage(hWndChat, IDC_COMBO_SIZE, EM_SETREADONLY, (WPARAM)TRUE, 0);
	SendDlgItemMessage(hWndChat, IDC_COMBO_GAME_TYPE, EM_SETREADONLY, (WPARAM)TRUE, 0);
}

GameControllerClient::connectToServer(char* ip, int port){
	if(net == NULL){
		try {
			net = new Network(this, isClient(), ip, port);
			return true;
		}
		catch (MMPSocket::SocketException e){
			delete net;
			net = NULL;
			processErrorMessage(e);
		}
	}
	return false;
}

GameControllerClient::ServerAcceptedConnection(int _server_hash, int maxPlayers){
	server_hash = _server_hash;
	
	changeMaxPlayers(maxPlayers);

	Network::mmpMSG_client_reply_client_data msg;
	msg.colour = players[0].colour->ToCOLORREF();
	memcpy(msg.name, players[0].name, NAME_MAX);
	msg.server_hash = server_hash;
	msg.version = MULTI_MINE_VERSION;
	
	net->sendMessage(Network::mmp_client_reply_client_data, &msg);

}

GameControllerClient::ServerAcceptedClient(COLORREF colour, char* name, int playerNo){
	if(colour != players[0].colour->ToCOLORREF() || strcmp(name, players[0].name) != 0){
		// resend player details
	}
	else {
		if(hWndClient == NULL)
			requestServerInformation();
		else
			SendNotifyMessage (hWndClient, SERVER_ACCEPTED_CLIENT_CONNECTION, NULL, NULL);

		players[0].playerNo = playerNo;
	//	players[0].dd->pinteger = &(players[playerNo].score);
		addPlayer(colour, name, playerNo);

	}
	
}

GameControllerClient::requestServerInformation(){
	net->sendMessage(Network::mmp_client_request_server_details, NULL);

	char* serverMessage = new char[500];
	strcpy(serverMessage, "5 pts for flagging a square\r\n-40 at the end of the game for an incorrect flag\r\n-30 if someone clicks on your flag at it turns out the cell does not contain a mine\r\n-20 for clicking on a mine\r\n+x if you reveal a cell with x neighbouring mines.\r\n0 pts for revealing a nothing square and any squares it reveals.\0");
	int i = SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT_HISTORY, EM_REPLACESEL, FALSE, (LPARAM)serverMessage);
}

GameControllerClient::ServerSendingDetails(char* _serverTitle, int port, int combo_size,
								int combo_game_type, int height, int width, int mines, bool _endGame){
		
	memcpy(serverTitle, _serverTitle, NAME_MAX);
	char svrtxt[NAME_MAX+20];
	strcpy(svrtxt, "Connected to -= ");
	strcat(svrtxt, serverTitle);
	strcat(svrtxt, " =-");
	SetWindowText(hWndChat, svrtxt);
	variableChange(IDC_EDIT_NAME, (int)serverTitle);
	variableChange(IDC_EDIT_PORT, port);
	
	variableChange(IDC_COMBO_SIZE, combo_size);
	variableChange(IDC_COMBO_GAME_TYPE, combo_game_type);

	// must be after combo change
	variableChange(IDC_EDIT_HEIGHT, height);
	variableChange(IDC_EDIT_WIDTH, width);
	variableChange(IDC_EDIT_MINES, mines);
	variableChange(IDC_EDIT_MAX_PLAYERS, maxPlayers);
	endGame = _endGame;
	if(!endGame){
		MessageBox(hWndChat, "Wait a bit.. maybe the game will end.", "Game in progress", MB_OK | MB_ICONINFORMATION);
		SendDlgItemMessage(hWndChat, IDC_STATIC_GAME_ON, WM_SETTEXT, 0, (LPARAM)"Game On!");
	}
		
	
}

GameControllerClient::~GameControllerClient(){
	delete gui;
	delete s;
}

void GameControllerClient::processErrorMessage(Exception e){
	MessageBox(NULL, e.msg , "Network Error", MB_OK | MB_ICONERROR);
	delete e.msg;//
}

void GameControllerClient::mouseEventMinefield(int player, Point* p,  GUI::Mouse_Action mouse_action, int button_state){
	if(!endGame && 0 <= p->X && p->X < mf->getSizeX() && 0 <= p->Y && p->Y < mf->getSizeY()){
		Score::scoreSheet score;
		Minefield::mfReturnMessage ret = mf->mouseEvent(player, p, mouse_action, button_state, &score);

		if(player == 0){
			if(ret != Minefield::mfrm_nothing){
				if(net != NULL){
					Network::mmpMSG_client_minefield_click msg;
					msg.ma = mouse_action;
					msg.p.X = p->X;
					msg.p.Y = p->Y;
					net->sendMessage(Network::mmp_client_minefield_click, &msg);
				}
			}
		
			if(ret == Minefield::mfrm_flag_point){
				if(mf->cells(p)->cState == Cell::flagged){
					ddbc->plusplus();
				}
				else{
					ddbc->minusminus();
				}
				gui->redrawDigitalDisplayGUI(gui->bgui);
			}
		}
	}
	else if(mouse_action == GUI::ma_mouse_move){
		if(mf->previousCell->X != -3 && mf->previousCell->Y != -3){
			if(button_state & MK_LBUTTON){
				if(mf->undepress(mf->previousCell))
					redrawMinefieldCell(mf->previousCell);
			}

			if(button_state & MK_MBUTTON){
				mf->deUnpressSet(mf->previousCell, false);			
			}
			mf->previousCell->X = -3;
			mf->previousCell->Y = -3;
		}
	}
}

GameControllerClient::updatePlayerScore(Score::scoreSheet score){

	int temp_player;
	if(score.current_player == players[0].playerNo)
		temp_player = 0;
	else
		temp_player = score.current_player;
	players[temp_player].score = score.cp_score;
	gui->redrawDigitalDisplayGUI(players[temp_player].ddgui);


	if(score.previous_player == players[0].playerNo)
		temp_player = 0;
	else
		temp_player = score.previous_player;
	if(players[temp_player].score != score.pp_score && score.previous_player != 0){
		players[temp_player].score = score.pp_score;
		gui->redrawDigitalDisplayGUI(players[temp_player].ddgui);
	}
}

void GameControllerClient::mouseEventSmilie(bool mouseInSmilie, GUI::Mouse_Action mouse_action, int button_state){
	s->mouseEvent(mouseInSmilie, mouse_action, button_state);
}

void GameControllerClient::redrawSmilie(){
	gui->redrawSmilie();
}

void GameControllerClient::redrawMinefieldCell(Point *cell){
	gui->redrawMinefieldCell(cell);
}

void GameControllerClient::revealCells(SLList* cells){
	gui->drawCells(cells);
}

bool GameControllerClient::getEndGame(){
	return GameController::endGame;
}

int GameControllerClient::getmaxplayers(){
	return maxPlayers;
}

Player* GameControllerClient::getplayer(int i){
	return &(players[i]);
}

bool GameControllerClient::isClient(){
	return true;
}

void GameControllerClient::addPlayer(COLORREF colour, char* name, short playerNo){
	GameController::addPlayer(colour, name, playerNo);
	if(playerNo == 0 || players[playerNo].playerNo != players[0].playerNo){
		gui->tb->addPlayer(&players[playerNo]);
	}		
	if(playerNo != 0){
		addPlayerToList(playerNo);
	}
	
}

void GameControllerClient::variableChange(int variable, int value){
	switch(variable){
		case IDC_COMBO_SIZE:
			comboSizeChange(value);
			// not break
		case IDC_COMBO_GAME_TYPE:
			SendDlgItemMessage(hWndChat, variable, CB_SETCURSEL, value, 0);
		break;
		
		case IDC_EDIT_HEIGHT:
		case IDC_EDIT_WIDTH:
		case IDC_EDIT_MINES:
		case IDC_EDIT_PORT:
		case IDC_EDIT_MAX_PLAYERS:
			SetDlgItemInt(hWndChat, variable, value, FALSE);
			break;
		case IDC_EDIT_NAME:
			SetDlgItemText(hWndChat, variable, (char*)value);
			break;
	}
}

void GameControllerClient::PlayerHasLeft(int player){
	deletePlayerFromList(player);
	gui->tb->delPlayer(&players[player]);
	GameController::PlayerHasLeft(player);
	if(endGame)
		SetForegroundWindow(hWndChat);
}

GameControllerClient::leaveServer(){
	delete net;
	net = NULL;
	changeMaxPlayers(1);
	beginNewGame(mf->getSizeX(), mf->getSizeY(), mf->bombs, GetTickCount(), DEATHMATCH);


	if(hWndChat != NULL){
		SendDlgItemMessage(hWndChat, IDC_LIST_PLAYERS, LB_RESETCONTENT, 0, 0); 
		incommingChatMessage(0, 12, "Left server");
	}
	if(!endGame)
		CARGameOff();

	hWndChat = NULL;
	hWndClient = NULL;
}

bool GameControllerClient::beginNewGame(int x, int y, int bombs, int seed, int gameType){
	if(GameController::beginNewGame(x, y, bombs, seed, gameType) == false){
		return false;
		// do bad stuff...?	
	}

	gui->mfgui->mfChange();
	
	if(net != NULL){
		Network::mmpMSG_client_returns_minefield_hash msg;
		msg.hash = mf->getHash();
		net->sendMessage(Network::mmp_client_returns_minefield_hash, &msg);
	}
	return true;
}

void GameControllerClient::oneSecondHasPassed(){
	GameController::oneSecondHasPassed();
	gui->redrawDigitalDisplayGUI(gui->tgui);
}

GameControllerClient::ServerHashTest(bool accepted){
	if(accepted){
		gui->adjusted = false;
		if(gui->paint() == 0)//passed the painting test
			PostMessage(hWnd, CREATE_GAME_BEGINNING_DIALOG, 0, 0);
	}
	else {
		MessageBox(NULL, "Hash not accepted, expect to leave soon", "boob tube", MB_OK | MB_ICONERROR);
	}
}

void GameControllerClient::GameOn(){
	GameController::GameOn();
	gui->mfgui->drawCells();
	players[0].score = 0;
	gui->redrawDigitalDisplayGUI(players[0].ddgui);
	for(int i=1;i<maxPlayers;i++){
		if(players[i].playerNo == i){
			players[i].score = 0;
			if(players[i].ddgui != NULL)
				gui->redrawDigitalDisplayGUI(players[i].ddgui);
		}
	}
	s->state = Smilie::Smile;
	gui->redrawSmilie();
	EndDialog(hWndGameBeginning, 0);
	SendDlgItemMessage(hWndChat, IDC_STATIC_GAME_ON, WM_SETTEXT, 0, (LPARAM)"Game On!");
	SetForegroundWindow(hWnd);
}	

void GameControllerClient::CARGameOff(){
	GameController::CARGameOff();
	SendDlgItemMessage(hWndChat, IDC_STATIC_GAME_ON, WM_SETTEXT, 0, (LPARAM)"");
	s->state = Smilie::Shades;
	gui->redrawSmilie();
}

GameControllerClient::sendChatMessage(){
	int msgSize = SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT, EM_LINELENGTH, 0, 0);
	if(msgSize > 0){
		Network::mmpMSG_chat_message msg;
		msg.length_of_text = msgSize+1;
		msg.player = players[0].playerNo;
		msg.text[0] = 'a';
		strcpy(msg.text, "Danno, you're computer is so annoying");
/*		FILE* file;
		if( (file = fopen("chat-log.txt", "a" )) == NULL ){
			MessageBox(hWnd, "The server could not be written to its storage location. Do not worry too much, it just means more typing for you.", "Mini Error", MB_OK | MB_ICONEXCLAMATION);
		}
		else {
			fprintf(file, "length %d\tplayer %d\nmessage*pre* '%s'\n", msg.length_of_text, msg.player, msg.text); 
		
			for(int i=0;i<CHAT_MAX;i++){
				fputc(msg.text[i], file);
			}
			fputc('\n', file);
			fclose(file);	
		}
		
*/
		int ret = SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT, EM_GETLINE, 0, (LPARAM)msg.text);
		msg.text[msgSize] = '\0';
		
/*		if( (file = fopen("chat-log.txt", "a" )) == NULL ){
			MessageBox(hWnd, "The server could not be written to its storage location. Do not worry too much, it just means more typing for you.", "Mini Error", MB_OK | MB_ICONEXCLAMATION);
		}
		else {
			fprintf(file, "return of text get: %d\nmessage*post* '%s'\n\n", ret, msg.text); 

			for(int i=0;i<CHAT_MAX;i++){
				fputc(msg.text[i], file);
			}
			fputc('\n', file);
			fclose(file);	
		}
*/		

		net->sendMessage(Network::mmp_client_chat_message, &msg);
		SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT, WM_SETTEXT, 0, (LPARAM)"");
	}
}

GameControllerClient::drawPlayerListBox(DRAWITEMSTRUCT* bling){
	
	if(bling->CtlID == IDC_LIST_PLAYERS){

		HDC hdc;
		RECT rc;
		
		int cplayer;

		hdc = bling->hDC;
		rc = bling->rcItem;
		if (bling->itemData == -1) return 0;

		Graphics graphics(hdc);

		// Use a generic sans serif FontFamily object to create a Font object.
		Font genericSansSerifFont(FontFamily::GenericSansSerif(), 8);
		const StringFormat* pStringFormat = StringFormat::GenericDefault();

		// Draw text using the new font.
		//	graphics.DrawString(L"This is a generic sans serif font", 33,
		//				   &genericSansSerifFont, PointF(0, 0), &solidbrush);


		switch (bling->itemAction)
		{
			case ODA_DRAWENTIRE:
			{
				rc = bling->rcItem;
				cplayer = (int) bling->itemData;
				//FillRect(hdc, &rc, hbrBackground);
				//InflateRect(&rc, -1, -1);
				PointF origin(rc.left, rc.top);
				SolidBrush solidbrush(*players[cplayer].colour);
				WCHAR stwing[NAME_MAX];
				for(int i=0;i<NAME_MAX;i++){
					if(players[cplayer].name[i] != 0)
						stwing[i] = players[cplayer].name[i];
					else {
						stwing[i] = L' ';
						
					}
				}
				graphics.DrawString(stwing, NAME_MAX, &genericSansSerifFont,
									origin, &solidbrush); 
				break;
					
				// *** FALL THROUGH ***
			}
			case ODA_SELECT:
			{
			/*	HBRUSH hbrush;
				HBRUSH hbrHighlight = CreateSolidBrush(0xFFFFFF - gui->cBg->GetValue());
				HBRUSH hbrBackground = CreateSolidBrush(gui->cBg->GetValue());
				
				rc = bling->rcItem;
				if (bling->itemState & ODS_SELECTED)
					hbrush = hbrHighlight;
				else 
					hbrush = hbrBackground;
				FrameRect(hdc, &rc, hbrush);
				break;
			*/
			}

			case ODA_FOCUS:
				break;
		}
	
	}
	return 0;
}

GameControllerClient::unableToDisplayMinefield(){
	MessageBox(hWndChat, "The minefield was too large to display on your screen.\nPlease increase your resolution or protest to the\nserver's owners about your small maximum screen size.", "Could not begin game", MB_OK | MB_ICONEXCLAMATION);
	mf->resize(0,0);
	gui->mfgui->mfChange();
	gui->adjusted = false;
	gui->paint();
}