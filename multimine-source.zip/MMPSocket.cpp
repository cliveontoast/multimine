#include "multimine.h"
//#include "MMPSocket.h"

MMPSocket::MMPSocket(Network* _n, char* ip, int port){
	sock = socket(PF_INET, SOCK_STREAM, 0);
	if( sock == INVALID_SOCKET){
		constructErrorMessage(se_socket_not_created, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
	}
	
	Construct(_n, 0);
	registerSocket();
	Connect(ip, port);
	outQueue = new SLList();
	
}

MMPSocket::MMPSocket(){
//	socket_event = WSA_INVALID_EVENT;
	n = NULL;
	outQueue = new SLList();
	
}

MMPSocket::Attach(SOCKET s, sockaddr_in ad, int length){
	memcpy(&sock, &s, sizeof(SOCKET));
	memcpy(&address, &ad, sizeof(sockaddr_in));
	memcpy(&socklen, &length, sizeof(int));
}

MMPSocket::Transfer(MMPSocket* new_socket){
	new_socket->Attach(sock, address, socklen);

}

MMPSocket::Detach(int SD_SEND__SD_RECEIVE__SD_BOTH){
	shutdown(sock, SD_SEND__SD_RECEIVE__SD_BOTH);
	if (n != NULL)
		if(	WSAAsyncSelect(sock, n->gc->hWnd, 0, 0) == SOCKET_ERROR){
			constructErrorMessage(se_asyncselect, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
		}
}

MMPSocket::registerSocket(){
	int windowsMessage;
	if(n->isClient){
		windowsMessage = CLIENT_MMPSOCKET_EVENT;
	}
	else {
		windowsMessage = SERVER_MMPSOCKET_EVENT;
	}
	registerSocket(windowsMessage, NULL);
}

MMPSocket::registerSocket(UINT _windowsMessage, long _eventFlags){
	if(_windowsMessage != NULL)
		windowsMessage = _windowsMessage;
	if(_eventFlags == NULL)
		eventFlags = FD_READ | FD_WRITE | FD_CONNECT | FD_CLOSE;
	else
		eventFlags = _eventFlags;
	
	// in the case where the newConnection turned into a myConnection... the net becomes null
	// this needs to be tested, because after it moves itself.. the MMPSocket tries to turn its reading back on...
	// but i dont want to do that anymore!

	if(n != NULL){
//		if(n->isClient){
		
			if(	WSAAsyncSelect(sock, n->gc->hWnd, 
				windowsMessage, eventFlags) == SOCKET_ERROR){
				constructErrorMessage(se_asyncselect, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
			}
/*		}
		else {
			socket_event = WSACreateEvent();
			if(WSAEventSelect(sock, socket_event, eventFlags) == SOCKET_ERROR){
				constructErrorMessage(se_eventselect, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
			}
		}
*/	}
}

MMPSocket::~MMPSocket(){
	//if(n != NULL){
		Detach(SD_BOTH);
		//delete all outQueue objects?
	//}
	//closesocket(sock);
	delete outQueue;

		//	Call WSAAsyncSelect to register for FD_CLOSE notification. 
		//  Call shutdown with how=SD_SEND. 
		//  When FD_CLOSE received, call recv until zero returned, or SOCKET_ERROR. 
		//  Call closesocket. 
	
}

MMPSocket::Construct(Network* _n, int _player){
	n = _n;
	playerNo = _player;
	memset(&currentMSG, 0, sizeof(currentMSG));
}

MMPSocket::Destruct(){
	n = NULL;
	playerNo = -1;

	while(outQueue->Head->Next != NULL){
		Network::mmpMSG* msg = (Network::mmpMSG*)outQueue->Head->Next->Data;
		delete[] msg->data;
		delete msg;
		// check that the whole message data is cleared.. not just the very first one!
		outQueue->DeleteANode(outQueue->Head->Next);
	}
	memset(&currentMSG, 0, sizeof(currentMSG));
	//delete outQueue;

}

MMPSocket::Connect(char* ip, char* port){
	Connect(ip, atoi(port));
}
	
MMPSocket::Connect(char* ip, short port){

	address.sin_family = AF_INET;
	address.sin_port = htons(port);
	
	HOSTENT* pHostEnt;
	if(pHostEnt = gethostbyname(ip)){
		socklen = pHostEnt->h_length;
		memcpy(&address.sin_addr, pHostEnt->h_addr_list[0], pHostEnt->h_length);
	}
	else {
		constructErrorMessage(se_host_not_found, WSAGetLastError(), __FILE__, __LINE__, ip, 0);
	}
	

	if(connect(sock, (sockaddr*)&address, sizeof(address) ) == SOCKET_ERROR){
		if(WSAGetLastError() == WSAEWOULDBLOCK){
			// normal
		}
		else {	// not normal
			constructErrorMessage(se_cannot_connect_to_server, WSAGetLastError(), __FILE__, __LINE__, ip, port);
		}
	}

}

void MMPSocket::queueMessage(Network::MMP head, void* data){
	outQueue->AddANode();
	Network::mmpMSG* temp = new Network::mmpMSG;
	temp->mmpHead = head;
	temp->length = Network::messageSizes(head)+sizeof(head);

/*	if(head == Network::mmp_client_chat_message || head == Network::mmp_server_broadcast_chat_message){
		Network::mmpMSG_chat_message* msg = (Network::mmpMSG_chat_message*)data;
		temp->length += msg->length_of_text;
	}
*/
	temp->bytesTransfered = 0;
	temp->data = new char[temp->length];
	memcpy(temp->data, &head, sizeof(head) );
	
	if(temp->length > sizeof(head))
		memcpy(&temp->data[sizeof(head)], data, Network::messageSizes(head) );
	
/*	if(head == Network::mmp_client_chat_message || head == Network::mmp_server_broadcast_chat_message){
		Network::mmpMSG_chat_message* msg = (Network::mmpMSG_chat_message*)data;
		memcpy(&temp->data[sizeof(head)+Network::messageSizes(head)], msg->text, msg->length_of_text);
	}
*/
	outQueue->Tail->Data = (long)temp;
	
	if(outQueue->Tail == outQueue->Head->Next){ //only data in queue
		SendData();
	}
}

void MMPSocket::OnReceive(){
	
	if(n != NULL){
		Network* net = n;
		//disable read messages
		registerSocket(NULL, eventFlags & ~FD_READ);
		
		char t; // check if one byte exists on the socket
		while(recv(sock, &t, sizeof(char), MSG_PEEK) == sizeof(char)){
		
			// header not read...
			if(currentMSG.bytesTransfered < sizeof(currentMSG.mmpHead)){
				int bytes = recv(sock, 
				&((char*)&currentMSG.mmpHead)[currentMSG.bytesTransfered], 
				sizeof(currentMSG.mmpHead) - currentMSG.bytesTransfered, 0);
				if(bytes == SOCKET_ERROR){
					constructErrorMessage(se_receive_failure, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL);	
				}
				currentMSG.bytesTransfered += bytes;
			}
			
			// header received
			if(currentMSG.bytesTransfered == sizeof(currentMSG.mmpHead)){
				if(Network::messageSizes(currentMSG.mmpHead) > 0){
					int size = Network::messageSizes(currentMSG.mmpHead);
					currentMSG.data = new char[size];
					memset(currentMSG.data, 0, size);
				}
			}

			// data not all read yet.
			if(currentMSG.bytesTransfered < (Network::messageSizes(currentMSG.mmpHead) + sizeof(currentMSG.mmpHead)) ){
				int bytes = recv(sock, 
					&currentMSG.data[currentMSG.bytesTransfered - sizeof(currentMSG.mmpHead)],
					sizeof(currentMSG.mmpHead) + Network::messageSizes(currentMSG.mmpHead) - currentMSG.bytesTransfered, 0);
				if(bytes == SOCKET_ERROR){
					constructErrorMessage(se_receive_failure, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL);	
				}
				currentMSG.bytesTransfered += bytes;
			}

			// complete message received.
			if(currentMSG.bytesTransfered >= sizeof(currentMSG.mmpHead) + Network::messageSizes(currentMSG.mmpHead) ){

				if(currentMSG.mmpHead == Network::mmp_client_chat_message /*|| currentMSG.mmpHead == Network::mmp_server_broadcast_chat_message*/){

//					Network::mmpMSG_chat_message* chat = (Network::mmpMSG_chat_message*)(currentMSG.data/*+sizeof(currentMSG.mmpHead)*/);
//					n->gc->incommingChatMessage(0, chat->length_of_text, chat->text);

/*					Network::mmpMSG_chat_message* msg = (Network::mmpMSG_chat_message*)currentMSG.data;
					
					if(currentMSG.bytesTransfered == sizeof(currentMSG.mmpHead) + Network::messageSizes(currentMSG.mmpHead)){
						msg->text = new char[msg->length_of_text];
					}

					int bytes_T = currentMSG.bytesTransfered;
					int bytes_S = sizeof(currentMSG.mmpHead);
					int bytes_N = Network::messageSizes(currentMSG.mmpHead);
					int bytes = recv(sock,
						&msg->text[currentMSG.bytesTransfered - (sizeof(currentMSG.mmpHead) + Network::messageSizes(currentMSG.mmpHead)) ],
						sizeof(currentMSG.mmpHead) + Network::messageSizes(currentMSG.mmpHead) + msg->length_of_text - currentMSG.bytesTransfered, 0);
					if(bytes == SOCKET_ERROR){
						constructErrorMessage(se_receive_failure, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL);
					}
					currentMSG.bytesTransfered += bytes;

*/					if(currentMSG.bytesTransfered == sizeof(currentMSG.mmpHead) + Network::messageSizes(currentMSG.mmpHead)/* + msg->length_of_text*/){
						n->processPendingMessage(currentMSG, playerNo);
//						delete msg->text;
						delete[] currentMSG.data;
						memset(&currentMSG, 0, sizeof(currentMSG));
					}
				
				}
				else {
					n->processPendingMessage(currentMSG, playerNo);
					delete[] currentMSG.data;
					memset(&currentMSG, 0, sizeof(currentMSG));
				}
			}
			//int* p = &playerNo;
		}
		// enable read messages again
		registerSocket(NULL, eventFlags | FD_READ);
	}

}

void MMPSocket::OnSend(){
	SendData();
}

void MMPSocket::OnAccept(){
	
}

void MMPSocket::OnConnect(){
	int f = 5;
	// connected! respond to the client to say congratulations!
}
void MMPSocket::OnClose(){
	if(closesocket(sock) == SOCKET_ERROR){
		MMPSocket::constructErrorMessage(MMPSocket::se_close_socket, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL );
	}
	Destruct();
}

void MMPSocket::OnOutOfBandData(){

}

void MMPSocket::SendData(){

	if(outQueue->Head->Next != NULL){
		if(outQueue->Head->Next->Data != NULL){
			Network::mmpMSG* msg = (Network::mmpMSG*)outQueue->Head->Next->Data;
			int bytesSent = send(sock, &msg->data[msg->bytesTransfered], msg->length - msg->bytesTransfered, 0);

			if(bytesSent > 0){ // something sent
				msg->bytesTransfered += bytesSent;
				if(msg->bytesTransfered == msg->length){//finished sending packet
					if(msg->mmpHead == Network::mmp_client_chat_message){
						//int x = sizeof(msg->mmpHead);
/*						Network::mmpMSG_chat_message* chat = (Network::mmpMSG_chat_message*)(msg->data+sizeof(msg->mmpHead));
						n->gc->incommingChatMessage(0, chat->length_of_text, chat->text);
*/					}
					delete[] msg->data;
					delete msg;
	// check that the whole message data is cleared.. not just the very first one!
					outQueue->DeleteANode(outQueue->Head->Next);
				}
			}
			else if(bytesSent == SOCKET_ERROR){
				if(WSAGetLastError() == WSAEWOULDBLOCK){
					// temperory error, wait and things will be fine
				}
				else {
					constructErrorMessage(se_sending_data_error, WSAGetLastError(), __FILE__, __LINE__, NULL, NULL);
				/*	error has occured in sending data
					this should never occur. as SendData is only ever called
					from the OnSend method (indicading that it is not blocked)
					or from the queue message where it's the only message on the queue!
					which means that there are no other things being sent.

					it could happen that queue messages receivesa a new message to send
					before the previous one has finished and tries to send the message.
					in that case, it would reach this area, and it shouldnt do anything.
					because it will just wait for the OnSend message before it can send
					stuff.
				*/
				}
			}
		}
	}
	else {
		// no data to send. i can only see this happening when the socket is initally created.
	}
}

void MMPSocket::constructErrorMessage(int SocketError, int WSAErrorNo, char* file, int line, char* ip, short port, ...){

	
	va_list arguments;
	va_start(arguments, port);

	string error;

	stringstream ss, ssline, ssport;
	ssport << port;

	error = "Socket Error: ";
	
	switch(SocketError){

	case se_host_not_found:
		error.append("Host not found");
		break;
	case se_asyncselect:
		error.append("WSAAsyncSelect failed");
		break;
	case se_socket_not_created:
		error.append("Socket could not be created");
		break;

	case se_cannot_connect_to_server:
		error.append("Could not connect to server");
		break;

	case se_connection_refused:
		error.append("Connection refused");
		break;

	case se_reached_unallowed_default_case:
		error.append("A case occured where it reached a unallowed default case, built to catch this exact error!");
		break;

	case se_bind_failure:
		error.append("Failed to bind the socket to port. Try another");
		break;

	case se_new_client_socket_creation:
		error.append("Could not create new socket from incomming connection request");
		break;
	
	case se_socket_not_found:
		error.append("The socket ");
		error.append(ssport.str());
		error.append(" cannot be found");
		break;

	case se_close_socket:
		error.append("Could not close the socket");
		break;

	case se_receive_failure:
		error.append("Could not receive from the socket");
		break;

	case se_eventselect:
		error.append("Server could not WSASelectEvent properly");
		break;

	case se_listening_socket_error:
		error.append("Listening socket error");
		break;

	default:
		error.append("Unknown error");
	}
	
	error.append(".\n\nThe error occured in file '");
	error.append(file);
	error.append("' at line ");
	ssline << line;
	error.append(ssline.str());
	error.append("'.");
	
	error.append("\n\nThe WSA error for this problem is as follows:\nError ");
	ss << WSAErrorNo;
	error.append(ss.str());
	error.append(" ");

	switch(WSAErrorNo){
	
		// assumes that only one other parameter has been given.
		// that parameter is the 
		case WSAHOST_NOT_FOUND:
			error.append("The host address '");
			error.append(ip);
			error.append("' could not be found.\nPlease check if this host exists and try again");
		break;
		case WSAEPFNOSUPPORT:
			error.append("Protocol family not supported.");
			break;
		case WSAEAFNOSUPPORT:
			error.append("Address family not supported by protocol family.");
			break;
		// assumes that the ip and port have been given as extras
		case WSAECONNREFUSED:
			error.append("Connection refused.\nThe server ");
			error.append(ip);
			error.append(" has refused the connection on port ");
			error.append(ssport.str());
			error.append(" because the target computer actively refused it. This usually results from trying to connect to a service that is inactive on the foreign host, that is, one with no multimine server running.");
		break;

		case WSAETIMEDOUT:
			error.append("Connection timed out to the server ");
			error.append(ip);
			error.append(".\nThe connection attempt failed because the other computer did not properly respond after a period of time, or the established connection failed because the connected host has failed to respond.");
			break;	
	

	case WSAEHOSTDOWN:
	case WSAEINTR:
	case WSAEACCES:
	case WSAEFAULT:
	case WSAEINVAL:
	case WSAEMFILE:
	case WSAEWOULDBLOCK:
	case WSAEINPROGRESS:
	case WSAEALREADY:
	case WSAENOTSOCK:
	case WSAEDESTADDRREQ:
	case WSAEMSGSIZE:
	case WSAEPROTOTYPE:
	case WSAENOPROTOOPT:
	case WSAEPROTONOSUPPORT:
	case WSAESOCKTNOSUPPORT:
	case WSAEOPNOTSUPP:
	case WSAEADDRINUSE:
	case WSAEADDRNOTAVAIL:
	case WSAENETDOWN:
	case WSAENETUNREACH:
	case WSAENETRESET:
	case WSAECONNABORTED:
	case WSAECONNRESET:
	case WSAENOBUFS:
	case WSAEISCONN:
	case WSAENOTCONN:
	case WSAESHUTDOWN:
	case WSAEHOSTUNREACH:
	case WSAEPROCLIM:
	case WSASYSNOTREADY:
	case WSAVERNOTSUPPORTED:
	case WSANOTINITIALISED:
	case WSAEDISCON:
	case WSATYPE_NOT_FOUND:
	case WSATRY_AGAIN:
	case WSANO_RECOVERY:
	case WSANO_DATA:
	case WSA_INVALID_HANDLE:
	case WSA_INVALID_PARAMETER:
	case WSA_IO_INCOMPLETE:
	case WSA_IO_PENDING:
	case WSA_NOT_ENOUGH_MEMORY:
	case WSA_OPERATION_ABORTED:
//	case WSAINVALIDPROCTABLE:
//	case WSAINVALIDPROVIDER:
//	case WSAPROVIDERFAILEDINIT:
	case WSASYSCALLFAILURE:
	default:
		error.append("This error has yet to be documented.");
	}

	char* e = new char[error.length()+1];
	strcpy(e, error.c_str());
	e[error.length()] = '\0';
	throw SocketException(e, SocketError, WSAErrorNo);	
	
}