#ifndef _HAVE_NETWORK_H
#define _HAVE_NETWORK_H 1

class Network {
public: 

	enum MMP;

	class mmpMSG {
	public:
		MMP mmpHead;
		int length;
		int bytesTransfered;
		char* data; // data is message head + actual data
	};

//	WSAEVENT* myEvents

	MMPSocket** myConnections;
	MMPSocket** newConnections;
	
	vector<MMPSocket*> shuffle;

	bool isClient;
	int client_count;
	
	ListeningSocket* listener;
	
	GameController* gc;
	GameControllerClient* gcc;
	GameControllerServer* gcs;

	Network(GameController* gc, bool client, char* ip, int port);

	~Network();

//	reRegisterSockets();

	addMMPSocket(SOCKET s, sockaddr_in sockAddr, int adLen);

	closeSocket(int player);

	processPendingMessage(mmpMSG, int player);

	// if its zero, send to all connections
	queueMessage(MMP* head, char* data, short who);

	incomingEvent(short event, SOCKET s, UINT msg);
	
	incomingError(short error, short event, SOCKET wParam, UINT NETWORK_MSG);

	MMPSocket* checkSocket(SOCKET s, UINT NETWORK_MSG);

	void broadcastMessageBarSelfClient(MMP head, void* data);

	void broadcastMessage(MMP head, void* data);

	void sendMessage(int player, MMP head, void* data);

	void sendMessage(MMP head, void* data);

	void sendMessage(MMPSocket* mmps, MMP head, void* data);
	
	denyClient(SOCKET s, sockaddr_in sockAddr, int adLen);

	static int messageSizes(MMP head);

	SendAndRemove(MMPSocket* mmps, void* data);

	enum denyReason {
		dr_server_full,
		dr_version_mismatch,
		dr_invalid_hash,
		dr_game_in_progress,
	};

	typedef struct mmpMSG_server_request_client_data {
		int server_hash;
		int maxPlayers;
	};

	typedef struct mmpMSG_server_details {
		char serverTitle[NAME_MAX];
		int port;
		int combo_size;
		int combo_game_type;
		int height;
		int width;
		int mines;
		bool endGame;
	};

	typedef struct mmpMSG_client_reply_client_data {
		COLORREF colour;
		char name[NAME_MAX];
		int server_hash;
		int version;
	};

	typedef struct mmpMSG_server_deny_new_client {
		denyReason deny_reason;
		int extra_information;
	};

	typedef struct mmpMSG_client_details {
		COLORREF colour;
		char name[NAME_MAX];
		short playerNo;
	};

	typedef struct mmpMSG_server_variable_change {
		int variable;
		int value;
	};

	typedef struct mmpMSG_client_change_name {
		char name[NAME_MAX];
	};

	typedef struct mmpMSG_client_change_colour {
		COLORREF colour;
	};

	typedef struct mmpMSG_server_broadcast_client_name {
		int player;
		char name[NAME_MAX];
	};

	typedef struct mmpMSG_server_broadcast_client_colour {
		int player;
		COLORREF colour;
	};

	typedef struct mmpMSG_server_broadcast_client_leaving {
		int player;
	};
	
	typedef struct mmpMSG_server_broadcast_begin_game {
		int seed;
		int height;
		int width;
		int mines;
		int game_type;
	};

	typedef struct mmpMSG_client_returns_minefield_hash {
		int hash;
	};

	typedef struct mmpMSG_server_hash_reply {
		bool accepted;
	};

	typedef struct mmpMSG_client_minefield_click {
		GUI::Mouse_Action ma;
		Point p;
	};

	typedef struct mmpMSG_server_broadcast_minefield_click {
		mmpMSG_client_minefield_click click;
		Score::scoreSheet score;
	};

	typedef struct mmpMSG_server_broadcast_player_change_score {
		Score::scoreSheet score;
	};

	typedef struct mmpMSG_chat_message {
		int length_of_text;
		int player;
		char text[CHAT_MAX];
	};

	enum MMP {
		// multimine protocol _ server/client sends message _ message type
		
		// denys the client into the game
		mmp_server_deny_new_client,
		// server requests client information to add player
		mmp_server_request_client_data,
		
		// client sends player information
		mmp_client_reply_client_data,
		// server response: 
		// server is full
		mmp_server_full,
		// accepts the new client to the game.
		mmp_server_accept_new_client,
		// server broadcasts a new player to the game
		mmp_server_broadcast_new_client,
		// server sends new player all other player details
		mmp_server_send_another_client,


		// client changes their settings
		mmp_client_change_name,
		mmp_client_change_colour,

		// server broadcasts the changes to the player
		mmp_server_broadcast_client_name,
		mmp_server_broadcast_client_colour,


		// client sending click
		mmp_client_minefield_click,
		// server broadcasts client left click on the board
		mmp_server_broadcast_minefield_click,

		
		// server broadcasts the game has started
		mmp_server_broadcast_begin_game,
		
		// server boardcasts the game has finally begun
		mmp_server_broadcast_accepting_clicks,

		// server ends game
		mmp_server_broadcast_end_game,

		// server changes a players score cause it feels like it
		mmp_server_broadcast_player_change_score,

		// client leaves the game
		mmp_client_leave_server,
		// server broadcasts tha player has left
		mmp_server_broadcast_client_leaving,

		// client returns the hash of the minefield it created
		mmp_client_returns_minefield_hash,
		// server accepts or rejects the hash
		mmp_server_hash_reply,
		

		// client send chat to server
		mmp_client_chat_message,
		// server broadcasts received chat
		mmp_server_broadcast_chat_message,

		// sent if the server receives a bad packet. reason follows presumably.
		mmp_server_received_bad_packet,

		// a variable in the pre game settings has been changed
		mmp_server_variable_change,

		mmp_client_request_server_details,

		mmp_server_details,

		/*****************************************************
		this stays at the end at all times
		*****************************************************/
		mmp_counter,
	};
		

};

#endif /* _HAVE_NETWORK_H */