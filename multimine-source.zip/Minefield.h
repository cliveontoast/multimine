#ifndef _HAVE_MINEFIELD_H
#define _HAVE_MINEFIELD_H 1

#include "multimine.h"
/*
#include "Cell.h"
#include "GameController.h"

#include "GUI.h"

*/

/** The Minefield class. This creates a minefield with a buffer of cells around the edges.
*	IE an extra layer of cells around the edges. Sometimes you should be careful to see if 
*	the cell you are accessing is out of the bounds...
*
*	Perhaps i should return a NULL cell if it's below 0.. but then it would mean constant checking
*	and i dont like constant checking! it's up to the caller to make sure they dont call
*	a cell that's outside the boundaries. this isnt too mard MAX(0,your_cell_#) and MIN(other_bound,your_cell_#).
*
*/

class Minefield {
public:


	/** The returning message from a Minefield protocol.
	*	Depending on what this is, the gameController will do different things.
	*	for example if the GC is a GCC, and it gets the reveal_surroundings_of_point message
	*	then it will send that message to the IO class, which will convert that into the MMSP
	*	and send it along to the server to do with what it chooses.
	*
	*	reveal_point is sent when a player has revealed a point
	*	reveal_surroundings_of_point is returned when a player has revealed all surrounding points
	*	flag_point is sent when a player has sent the 'flag_point' message, this could be either
	*	flag or unflag, depending on the state of the flag.
	*
	*	problems here would be perhaps if the flag or unflag messages get lost.
	*	but those sorts of transmission errors hopefully wont ever happen. if they do.. well too bad.
	*/
	enum mfReturnMessage {
		mfrm_nothing,
		mfrm_reveal_point,
		mfrm_reveal_surroundings_of_point,
		mfrm_flag_point,
	};

	Cell* field;			/**< The cells of the minefield */
	int bombs;				/**< The number of bombs in the minefield */
	GameController* gc;		/**< The game controller that this minefield belongs to */
	Point* previousCell;	/**< The previous cell the mouse was over */

	/** Creates a new minefield.
	*	@param size The size of the minefield.
	*	@param gc Sets the Minefield's gc to this.
	*/
	Minefield(Point* size, GameController* gc);

	Minefield::Minefield(int x, int y, GameController* _gc);
	/** destroys the minefield
	*/
	~Minefield();

	/** Populates the minefield with bombs.
	*	@param rand The random seed used to generate the minefield.
	*	@param bombs The number of bombs to put into the minefield.
	*/
	int populate(int srand, int bombs);

	/**	Depresses a cell.
	*	@param cell Point of the cell, not pointer to the cell.
	*	@return True if it sucessfully depressed the cell, false otherwise.
	*/
	bool depress(Point* cell);

	/** Undepress a cell.
	*	@param cell Point of the cell, not pointer to the cell
	*	@return True if it sucessfully undepressed the cell, false otherwise.
	*/
	bool undepress(Point* cell);

	/**	Reveal a cell.
	*	@param cell Point of the cell, not pointer to the cell
	*	@param player the player's number. This should be set to the game controllers current_player
	*	@return True if it sucessfully revealed the cell, false otherwise.
	*/
	bool reveal(Point* cell, int player, bool revealing_surroundings, Score::scoreSheet* score, bool first_revealer);

	/**	Flag or unflags a cell.
	*	@param cell point of the cell, not pointer to the cell
	*	@param player the player's number. This should be set to the game controllers current_player.
	*	@param real_player the real player's number. This should be set to the game controllers real_player.
	*	@return True if it sucessfully flags/unflags the cell, false otherwise.
	*/
	bool flag(Point* cell, int player, Score::scoreSheet* score);

	/**	Gets the size of the minefield. (in cells, not pixels)
	*	@param size, the point location where the size is written to.
	*/
	void getSize(Point* size);

	/**	Does what cells(unsigned int x, unsigned int y) says.
	*	@param position of the cell
	*	@return A pointer to the requested cell.
	*/
	Cell* cells(Point* position);

	/**	Converts the double array x y into its real value in the real array.
	*	Because the array of cells is not actually a double array (too annoying to implement),
	*	this function converts the x,y value into the real values.
	*	@param x horizontal position of the cell
	*	@param y vertical position of the cell
	*	@return A pointer to the requested cell.
	*/
	Cell* cells(int x, int y);

	/**	@return The number of horizontal cells in the minefield.
	*/
	int getSizeX();

	/**	@return The number of vertical cells in the minefield.
	*/
	int getSizeY();

	/** Takes the mouse input, and redirects it to the appropriate Cell class. They deal with it.
	*	@returns If the state of the minefield changes that the server needs to know about it,
	*	this returns the appropriate message required
	*/
	mfReturnMessage mouseEvent(int player, Point* p, GUI::Mouse_Action mouse_action, int button_state, Score::scoreSheet* score);

	/** Resize the minefield's array to this new size
	*	@param size The new size of the minefield's array
	*	@return True if it was resized, false otherwise
	*/
	bool resize(Point* size);

	bool resize(int x, int y);

	int getRandSeed();
	int getHash();
	bool isEndOfGame();
	void getEndScoreForPlayer(Score::scoreSheet* score);

	removePlayer(int player);

	/** depresses or undepresses a set of points sourounding point p
	*/
	void deUnpressSet(Point* p, bool dep);

private:

	/** Randomly selects a position in the field
	*	@param b The point chosen
	*/
	void randomizeBomb(Point* b);



	/** Reveals the surroundings of the current cell.
	*	@param cell the cell to reveal its neighbours
	*	@param player, the player's number that is doing the revealing.
	*/
	void revealSurroundings(Point* cell, int player, Score::scoreSheet* score);

	int randSeed;
	/**< The random number used to produce the minefield */
	int hash;	/**< The hash of the current minefield */
	Point* size; /**<	The size of the minefield */

	bool minefield_created; /**< True if a minefield has been created, false otherwise
							*
	*************************
	*
	* minefield_created is used by the resize method to decide whether or not to delete the
	* minefield array. In the begining it is set to false, after that it's set to true
	*
	*************************/

};

#endif /* _HAVE_MINEFIELD_H */