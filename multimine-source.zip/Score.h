#ifndef _SCORE_H
#define _SCORE_H

class Score {
public:

	typedef struct scoreSheet {
		int current_player;
		int cp_score;
		int previous_player;
		int pp_score;
	};

	static void getPointsFromRevealing(Minefield* mf, int howToScore, Point* point, 
		bool reveal_surroundings, bool first_revealer, scoreSheet* score);

	static void getPointsFromFlaging(Minefield* mf, int howToScore, Point* point,
		bool flagged, scoreSheet* score);

	static void getPointsFromBadFlagging(int howToScore, scoreSheet* score);
};

#endif // _SCORE_H