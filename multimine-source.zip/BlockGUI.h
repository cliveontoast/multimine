#ifndef _HAVE_BLOCKGUI_H
#define _HAVE_BLOCKGUI_H 1

#include "multimine.h"
//#include "GUI.h"


/**
 * The BlockGUI class is a small rectangle object drawn onto the screen (or other Device Context).
 * 
 * The BlockGUI class is the building BlockGUIs (har-har) for many other classes. Such as the
 * DigitalDisplay and and the minefield's cell. Everything drawn on the screen is actually a
 * BlockGUI because on closer inspection, everything has shaded borders.
 *
 * The BlockGUI holds pointers to the colours it needs to draw for that block. If the colour 
 * changes then the colour the block draws also changes.
 *
 * The same goes for it's position. if the Point that is passed to the BlockGUI when it's created
 * changes, then it will change too. This makes it quite easy to move blocks around.
 * 
 */
class BlockGUI {

public:

	GUI*	gui;		/**<	Pointer to the GUI object that BlockGUI uses to draw itself.
						*
	*********************
	*
	*	The gui is the steping stone to all other graphical objects that the BlockGUI uses to
	*	draw. Such as the graphics object, and the pen object.
	*
	*****************************************************/

	Point*	topLeft;	/**<	This describes the position of the
						*		BlockGUI's top left point relative to the DC's 0,0
	*********************	
	*
	*	If the Point this points to changes, then the next time this BlockGUI is drawn to 
	*	the gui's DC, it will draw to the new position.
	*																						
	****************************************************************************************/
	
	Point*	size;	/**<	The size in pixels of the BlockGUI.
					*
	*****************
	*	
	*	The size in pixels of the BlockGUI. That's all it is, I'm not sure
	*	how else to describe it.
	*
	*************************************************************************/			
	
	Color*	cTop;	/**<	A pointer to the Colour used to draw the top and left sides 
					*		of the BlockGUI.
	*****************
	*	
	*	If the pointer changes colour, this will be reflected on this BlockGUI when it is
	*	drawn to the gui's DC.
	*	
	*************************************************************************/
	
	Color*	cBottom;	/**<	A pointer to the Colour used to draw the bottom and right 
						*		sides of the BlockGUI.
	*********************
	*	
	*	If the pointer changes colour, this will be reflected on this BlockGUI when it is
	*	drawn to the gui's DC.
	*	
	*************************************************************************/
	
	char	border;	/**<	The width of the border the BlockGUI draws in pixels. It should
					*		have a value from 0 to 255
	*****************
	*
	*	Changing this variable could have unwanted consequences from objects that are
	*	derived from this class. This has not ever been tested because I've never wanted
	*	to change the border. Writing a getBorder is a waste of an extra line of code.
	*
	*	The border has a maximum size of 255, if it goes over that, it goes back to zero
	*
	*************************************************************************/
	
	static Point one_one;	/**< a point of size 1,1 Used in the BlockGUI somewhere.
							*
	*************************
	*
	*	Clive figures it's better to have a static Point instead of going Point(1,1) each time
	*	the BlockGUI is drawn. If there isn't any memory or speed advantage, tell him about it.
	*
	************************/
		
	/**	Creates a BlockGUI object from the set of inputs.
	*	
	*	@param topLeft	The pointer for BlockGUI to set it's topLeft variable to.
	*	@param size		The pointer for BlockGUI to set it's size variable to.
	*	@param cTop		The pointer for BlockGUI to set it's cTop variable to.
	*	@param cBottom	The pointer for BlockGUI to set it's cTop variable to.
	*	@param border	The border size for the BlockGUI.
	*/
	BlockGUI(GUI* gui, Point* topLeft, Point* size, Color* cTop, Color* cBottom, char border);
	
	/** Destroys the BlockGUI object.
	*
	*	Deletes the bottomRight variable.
	*/
	~BlockGUI();

	/** Draws the border to the gui's graphics object.
	*
	*/
	int drawBorder();

	/** Colour's in the BlockGUI's border to the background colour of the gui.
	*
	*/
	int wipeBorder();

protected:
	Point*	bottomRight;	/**<	The bottom right position (pixel) of the BlockGUI from the 
							*		Device Context's 0,0.
	*************************		
	*
	*	bottomRight is set when the BlockGUI object is about be drawn, from the topLeft and size.
	*	bottomRight can be useful to know where it is safe to place a new class 
	*	on the DC without overwriting this one. bottomRight 
	*
	*************************************************************************/

};

#endif /* _HAVE_BLOCKGUI_H */

