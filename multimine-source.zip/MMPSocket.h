#ifndef _HAVE_MMPCSOCKET_H
#define _HAVE_MMPCSOCKET_H 1

//#include "multimine.h"
#include <winsock2.h>
class Network;
class SLList;

class MMPSocket  {
public:
	
	enum sockErrors {
		se_socket_not_created,
		se_host_not_found,
		se_asyncselect,
		se_eventselect,
		se_cannot_connect_to_server,
		se_connection_refused,
		se_reached_unallowed_default_case,
		se_bind_failure,
		se_listen,
		se_new_client_socket_creation,
		se_sending_data_error,
		se_socket_not_found,
		se_unknown_error,
		se_close_socket,
		se_receive_failure,
		se_listening_socket_error,
	};


	class SocketException:public Exception{
	public:
		int WSAError;
		int sockError;
		SocketException(char* msg, int _sockError, int _WSAError):Exception(msg){
			WSAError = _WSAError;
			sockError = _sockError;
		}
	};


	Network* n;
	bool hasNetwork;

	SOCKET sock;
	struct sockaddr_in address;
	size_t socklen;

//	WSAEVENT socket_event;

	Network::mmpMSG currentMSG;

	UINT windowsMessage;
	long eventFlags;


	SLList* outQueue;

	// 0 if its a client...
	// 1 to infinity if it's the server's assigned player number.
	int playerNo;

	MMPSocket(Network* n, char* ip, int port);

	MMPSocket();

	registerSocket();

	registerSocket(UINT windowsMessage, long eventFlags);

	Detach(int SD_SEND__SD_RECEIVE__SD_BOTH);

	Attach(SOCKET s, sockaddr_in sockAddr, int adLen);

	~MMPSocket();

	Connect(char* ip, char* port);
	
	Connect(char* ip, short port);

	Construct(Network* n, int player);

	Destruct();

	Transfer(MMPSocket* new_socket);

	void OnReceive();

	void OnSend();

	void OnConnect();

	void OnAccept();

	void OnOutOfBandData();

	void OnClose();

	void queueMessage(Network::MMP head, void* data);

	void SendData();

	// last variable should be NULL.
	static void constructErrorMessage(int SocketError, int WSAErrorNo, char* file, int line, char* ip, short port, ...);

};

#endif /* _HAVE_LISTENINGCSOCKET_H */