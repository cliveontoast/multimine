#include "multimine.h"
#include "GUI.h"



GUI::GUI(HWND _hWnd, GameControllerClient* _gcc, BOOL _bMenu, DWORD _dwStyle, DWORD _dwExStyle){
	hWnd = _hWnd;
	gcc = _gcc;
	adjusted = false;
	tgui = 0;
	bgui = 0;

	bMenu = _bMenu;
	dwStyle = _dwStyle;
	dwExStyle = _dwExStyle;

	int temp = GetSysColor(COLOR_3DHILIGHT);
	cLight = new Color(GetRValue(temp), GetGValue(temp), GetBValue(temp));
	
	temp = GetSysColor(COLOR_3DFACE);
	cBg = new Color(GetRValue(temp), GetGValue(temp), GetBValue(temp));

	temp = GetSysColor(COLOR_3DSHADOW);
	cDark = new Color(GetRValue(temp), GetGValue(temp), GetBValue(temp));
	


	pSmilie = new Point();
	pBombCounter = new Point();
	pTimer = new Point();
	

	clientArea = new Point();


	thickShadow = 3;
	thinShadow = 1;
	normShadow = 2;

	pTopbar = new Point(9,9);
	
	spacing = new Point(5, 7);
	brick = new Point(16,16);
	bricks = new Point(30, 16);
	board = new Point(thickShadow*2+bricks->X*brick->X, thickShadow*2+bricks->Y*brick->Y);

	SolidBrush* solidBrush = new SolidBrush(*cBg);
	brush = solidBrush->Clone();
	pen = new Pen(*cLight);
	delete solidBrush;

	d = new Digits(this);
	cellgui = new CellGUI(this);

//	These three variables really should be set using the setWindowStyle after the programs
//	window has been created. who knows maybe later on in production the gui will be created
//	before the window has actually been created. who knows :)


	dwStyle = WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX & ~WS_THICKFRAME;
	dwExStyle = WS_EX_WINDOWEDGE;
	bMenu = TRUE;
	
	cPlayer = new Color(Color.LightGreen);

	hdc = GetDC(hWnd);
	hdcMem = NULL;

	g_memory = NULL;
	g = NULL;

	ReleaseDC(hWnd, hdc);

}


GUI::~GUI(){
	delete cBg;
	delete cDark;
	delete cLight;
	delete brick;
	delete bricks;
	delete board;

	delete pSmilie;
	delete pBombCounter;
	delete pTimer;
	delete pTopbar;

	delete mf_tl;
	delete sgui;
	delete blockSize;
	delete mfgui;
	delete tgui;
	delete bgui;
	delete tb;

	//delete solidBrush;
	delete brush;
	delete pen;
	delete d;
	delete cellgui;
	delete clientArea;
	delete cPlayer;

	//Delete previous DC and HBITMAP
	delete g_memory;
    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmMem);
    DeleteDC(hdcMem);
	
}

int GUI::paint(){

//http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dngdi/html/msdn_flicker.asp
//
//flicker free display tutorial
  
	hdc = BeginPaint(hWnd, &ps);
	
	if(!adjusted){
		if(!adjustClientArea()){
			gcc->unableToDisplayMinefield();
			adjusted = true;
			return 1;
		}
		tb->setDisplayCoordinates();
		//g = new Graphics(hdc);
		
		g = g_memory;
		g->FillRectangle(brush, 0, 0, clientArea->X, clientArea->Y);
		
		pen->SetWidth(1);
		tgui->drawDigitalDisplayGUI();
		bgui->drawDigitalDisplayGUI();

		for(int i=0;i<(gcc->getmaxplayers()+1);i++){
			if(gcc->getplayer(i)->ddgui != NULL){
				gcc->getplayer(i)->ddgui->drawDigitalDisplayGUI();
			}
		}

		sgui->drawSmilie();
		mfgui->drawCells();
		adjusted = true;
		tb->drawBorder();

		pen->SetWidth(3);
		pen->SetColor(*cLight);
		g->DrawLine(pen, 1, 0, 1, clientArea->Y);
		g->DrawLine(pen, 0, 1, clientArea->X, 1);
		pen->SetWidth(1);
	}

	draw();
	//BitBlt(hdc, 0, 0, clientArea->X, clientArea->Y, hdcMem, 0, 0, SRCCOPY);
	
	EndPaint(hWnd, &ps);

	return 0;
}

int GUI::draw(){
	
	hdc = GetDC(hWnd);
	BitBlt(hdc, 0, 0, clientArea->X, clientArea->Y, hdcMem, 0, 0, SRCCOPY);
	ReleaseDC(hWnd, hdc);
	return 0;
}

void GUI::drawCells(SLList* list){
	int drawThreshhold = 10;
	g = g_memory;
	mfgui->drawCells(list);
	if(list->count > drawThreshhold){
		draw();
	}
	else{
		hdc = GetDC(hWnd);
		g = new Graphics(hdc);
		mfgui->drawCells(list);
		delete g;
		ReleaseDC(hWnd, hdc);
	}
	
}

void GUI::redrawMinefieldCell(Point *cell){
	
	hdc = GetDC(hWnd);

	g = g_memory;
	mfgui->redrawCell(cell);
	
	g = new Graphics(hdc);
	mfgui->redrawCell(cell);
	delete g;
//	BitBlt(hdc, 0, 0, clientArea->X, clientArea->Y, hdcMem, 0, 0, SRCCOPY);
	
	ReleaseDC(hWnd, hdc);
}

void GUI::redrawSmilie(){

	hdc = GetDC(hWnd);
	
	g = g_memory;
	sgui->drawSmilie();

	g = new Graphics(hdc);
	sgui->drawSmilie();
	delete g;
	
	ReleaseDC(hWnd, hdc);

}

void GUI::redrawDigitalDisplayGUI(DigitalDisplayGUI* ddgui){
	
	hdc = GetDC(hWnd);

	g = g_memory;
	ddgui->drawDigitalDisplayGUI();
	
	g = new Graphics(hdc);
	ddgui->drawDigitalDisplayGUI();
	delete g;

	ReleaseDC(hWnd, hdc);

}

bool GUI::mouseEvent(POINTS p, GUI::Mouse_Action mouse_action, int button_state){
	Point* q = new Point(p.x, p.y);
	gcc->mouseEventSmilie(sgui->pointInSmilie(&p), mouse_action, button_state);
	gcc->mouseEventMinefield(0, mfgui->getCellFromPoint(q), mouse_action, button_state);
	delete q;
	return true;
}

bool GUI::addSmilie(Smilie* s){
	
	sgui = new SmilieGUI(this, pSmilie, cLight, cDark, cBg, s);
	return true;
}

bool GUI::addMinefield(Minefield* mf){
	mf_tl = new Point(50,50);
	blockSize = new Point(16,16);
	mfgui = new MinefieldGUI(this, mf, mf_tl, cDark, cLight, thickShadow,
			blockSize, cLight, cDark, normShadow, thinShadow);
	return true;
}

bool GUI::addTimer(DigitalDisplay* t){
	if(tgui)
		delete tgui;
	tgui = new DigitalDisplayGUI(this, pTimer, cDark, cLight, thinShadow, cPlayer, d, t);
	return true;
}

bool GUI::addBombCounter(DigitalDisplay* t){
	if(bgui)
		delete bgui;
	bgui = new DigitalDisplayGUI(this, pBombCounter, cDark, cLight, thinShadow, cPlayer, d, t);
	return true;
}

bool GUI::addTopbar(){
	tb = new Topbar(this, tgui, bgui, sgui, pTopbar, cDark, cLight, 2);
	return true;
}


bool GUI::adjustClientArea(){
	//get the right size of the client area	
	int tbmin = tb->getMinWidth();
	int mfmin = mfgui->fieldSize_plusBorder->X;
	int minwidth = MAX(tbmin,mfmin);
	tb->size->X = minwidth;
	tb->size->Y = tb->getMinHeight(tb->size->X);
	
	mf_tl->X = pTopbar->X;
	mf_tl->Y = pTopbar->Y + tb->size->Y + spacing->Y;
	
	clientArea->X = pTopbar->X + tb->size->X + spacing->X;
	clientArea->Y = pTopbar->Y + tb->size->Y + spacing->Y + mfgui->fieldSize_plusBorder->Y + spacing->X; //please note that this last spacing->X is in fact correct.. and it SHOULD NOT be a Y
	
	if(!adjustWindowSize())
		return false;

	LPRECT lpRect = new RECT;
	GetClientRect(hWnd, lpRect);

	
	//Delete previous DC and HBITMAP
    SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmMem);
    DeleteDC(hdcMem);
	
	//Create a compatible DC.
	hdcMem = CreateCompatibleDC(hdc);

	SelectObject(hdcMem, hbmOld);
    DeleteObject(hbmMem);
	// Create a bitmap big enough for our client rectangle.
	hbmMem = CreateCompatibleBitmap(hdc, clientArea->X, clientArea->Y);
	
	// Select the bitmap into the off-screen DC.
	hbmOld = (HBITMAP)SelectObject(hdcMem, hbmMem);
 
	LPSIZE lpSize = new SIZE;
	GetBitmapDimensionEx(hbmMem, lpSize);

    // Erase the background.
    hbrBkGnd = CreateSolidBrush(GetSysColor(COLOR_3DFACE));
	FillRect(hdcMem, lpRect, hbrBkGnd);
    DeleteObject(hbrBkGnd);
	
	delete lpRect;
	delete g_memory;
	g_memory = new Graphics(hdcMem);
	
	return true;
}

bool GUI::adjustWindowSize(){
	RECT lpRect;
	
	GetWindowRect(hWnd, &lpRect);
	
	POINT topleft;
	topleft.x = lpRect.left;
	topleft.y = lpRect.top;

	lpRect.left += GetSystemMetrics(SM_CXFIXEDFRAME);

	lpRect.top +=	GetSystemMetrics(SM_CXFIXEDFRAME) +	// border
					GetSystemMetrics(SM_CYSIZE) +		// title bar
					GetSystemMetrics(SM_CYBORDER) +		// space between title and menu
					GetSystemMetrics(SM_CYMENU);		// menu
					
	lpRect.bottom = lpRect.top+clientArea->Y;
	lpRect.right = lpRect.left+clientArea->X;
	
	RECT workArea;
	SystemParametersInfo(SPI_GETWORKAREA, 0, &workArea, 0); 

	BOOL blingblong = AdjustWindowRectEx(&lpRect, dwStyle, bMenu, dwExStyle);	
	//ShowWindow(hWnd, SW_RESTORE);

	topleft.x = MAX(workArea.left,MIN(topleft.x,workArea.right-(lpRect.right-lpRect.left)));
	topleft.y = MAX(workArea.top,MIN(topleft.y,workArea.bottom-(lpRect.bottom-lpRect.top)));
	
	if(		topleft.x < workArea.left 
		||	topleft.y < workArea.top
		||	lpRect.right - lpRect.left > workArea.right
		||	lpRect.bottom - lpRect.top > workArea.bottom)
		return FALSE;

	ShowWindow(hWnd, SW_RESTORE);

	SetWindowPos(hWnd, HWND_TOP, 
		topleft.x,
		topleft.y,
		lpRect.right - lpRect.left, 
		lpRect.bottom - lpRect.top, 
		SWP_SHOWWINDOW);
	

	return TRUE;
}

void GUI::changeMyColour(COLORREF colour){
	gcc->players[0].colour->SetFromCOLORREF(colour);
	//communicate this to the network instead of tihs
	redrawDigitalDisplayGUI(gcc->players[0].ddgui);
}