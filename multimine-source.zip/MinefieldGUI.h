#ifndef _HAVE_MINEFIELDGUI_H
#define _HAVE_MINEFIELDGUI_H 1

#include "multimine.h"
/*
#include "BlockGUI.h"
#include "DBlockGUI.h"

#include "Cell.h"
#include "CellGUI.h"
#include "GUI.h"
#include "SLList.h"
*/

/** Draws the minefield to the GUI
*
*/
class MinefieldGUI : BlockGUI {
public:

	Minefield* mf;	/**< The minefield to draw to the screen */
	DBlockGUI* cellsBorderGUI;	/**<	the GUI object to draw all the cell's borders*/
	Point* fieldSize_plusBorder;	/**< The total size of the MinefieldGUI object. */
	Point*	cbg_pTop;	/**< The pointer to the ctop of the dborder of the cell */
	Cell*	temp_cell;	/**< The pointer to the cell that is being drawn currently */
	CellGUI*	cgui;	/**< the cell GUI for this minefield to draw all the bitmaps from */

	/** Creates a minefield gui object, things that are independent of the minefield.
	*	i.e. the cellsBorderGUI and this GUI
	*/
	MinefieldGUI(GUI* gui, Minefield* mf, Point* topLeft, Color* cTop, Color* cBottom, int border,
			Point* cbg_size, Color* cbg_cTop, Color* cbg_cBottom, int cbg_border, int _dBorder);

	/** Destroyes the minefield gui object
	*
	*/
	~MinefieldGUI();

	mfChange(); 

	/** Draws all the cells from scratch to the gui. 
	*	It assumes that the cellspace has been cleared previously.
	*/
	drawCells();

	/**	Draws all the cells listed
	*	@param cells Draws the cells held by this Linked List
	*/
	drawCells(SLList* cells);

	/** Draws a cell from scratch to the gui. 
	*	It assumes that the cell has been cleared previously.
	*	@param cell The cell to draw.
	*/
	drawCell(Point* cell);

	/** Draws a cell's changes after it's state has changed.
	*	@param cell	The cell to draw.
	*/
	redrawCell(Point* cell);

	/** This draws the revealed bit of a cell, in all states of the game...
	*	Well that's the plan, it's not quite there just yet.
	*	@param cellgui The cell's GUI pointer... it's border.
	*	@param c The actuall cell in the minefield.
	*/
	int drawRevealed(DBlockGUI* cellgui, Cell* c);

	/**	Converts the mouse location within the GUI to the mouse position on the minefield
	*	@param	mouseLocation The location of the mouse in the GUI.
	*	@return the location of the mouse in to the minefield cells.
	*/
	Point* getCellFromPoint(Point* mouseLocation);
};

#endif /* _HAVE_MINEFIELDGUI_H */