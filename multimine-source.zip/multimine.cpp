#include "multimine.h"

//Block firsttime(start, board);

HINSTANCE g_hInstance;

HWND hWndServer = NULL;
HWND hWndClient = NULL;
HWND hWndClientChat = NULL;
HWND hWndMain = NULL;

HWND hWndBling = NULL;

bool editHasFocus = false;
char lastButtonPress = NULL;

const char g_szClassName[] = "myWindowClass";
#define IDC_MAIN_EDIT	101
HBITMAP g_hbmBall = NULL;
char *poo = "pooooooooo";
Bitmap* mini_me; 


HBRUSH g_hbrBackground = CreateSolidBrush((COLORREF)GetSysColor(COLOR_WINDOW));

DWORD dwStyle = WS_OVERLAPPEDWINDOW & ~WS_MAXIMIZEBOX & ~WS_THICKFRAME;
DWORD dwExStyle = WS_EX_WINDOWEDGE;
BOOL bMenu = TRUE;

GUI* gui;
GameControllerClient* gcc = NULL;
GameControllerServer* gcs = NULL;
GameController* gc;

Point* mousePosition;

int maxPlayers = 6;

DWORD g_crItems[] = {
	RGB(  0,   0,   0),	RGB( 64,   0,   0),	RGB(128,   0,   0),	RGB(128,  64,  64),	RGB(255,   0,   0),	RGB(255, 128, 128),
	RGB(255, 255, 128),	RGB(255, 255,   0),	RGB(255, 128,  64),	RGB(255, 128,   0),	RGB(128,  64,   0),	RGB(128, 128,   0),
	RGB(128, 128,  64),	RGB(  0,  64,   0),	RGB(  0, 128,   0),	RGB(  0, 255,   0),	RGB(128, 255,   0),	RGB(128, 255, 128),
	RGB(  0, 255, 128),	RGB(  0, 255,  64),	RGB(  0, 128, 128),	RGB(  0, 128,  64),	RGB(  0,  64,  64),	RGB(128, 128, 128),
	RGB( 64, 128, 128),	RGB(  0,   0, 128),	RGB(  0,   0, 255),	RGB(  0,  64, 128),	RGB(  0, 255, 255), RGB(128, 255, 255),
	RGB(  0, 128, 255),	RGB(  0, 128, 192),	RGB(128, 128, 255),	RGB(  0,   0, 160),	RGB(  0,   0,  64),	RGB(192, 192, 192),
	RGB( 64,   0,  64),	RGB( 64,   0,  64),	RGB(128,   0, 128),	RGB(128,   0,  64),	RGB(128, 128, 192),	RGB(255, 128, 192),
	RGB(255, 128, 255),	RGB(255,   0, 255), RGB(255,   0, 128),	RGB(128,   0, 255), RGB( 64,   0, 128),	RGB(255, 255, 255),
};



DWORD g_fgColor = 0xff0000;
DWORD g_bgColor = 0x00ff00;

BOOL CALLBACK ConnectedClientProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

/**
 * Callback function of "player settings" dialog box.
 */
LRESULT CALLBACK playerSettings(HWND hdlg, UINT message, WPARAM wParam, LPARAM lparam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		int nColor;
		SendDlgItemMessage(hdlg, IDC_NAME, WM_SETTEXT, 0, (LPARAM)gcc->players[0].name);

		g_crItems[0] = gcc->players[0].colour->ToCOLORREF();
		
		for (nColor = 0; nColor < sizeof(g_crItems)/sizeof(DWORD); nColor++){
			SendDlgItemMessage(hdlg, IDC_COLOUR, CB_ADDSTRING, 0, (LPARAM) g_crItems[nColor]);
		}
		SendDlgItemMessage(hdlg, IDC_COLOUR, CB_SETCURSEL, 0, 0);
		SendDlgItemMessage(hdlg, IDC_NAME, EM_SETLIMITTEXT, (WPARAM)NAME_MAX, 0);
		return TRUE;

	case WM_MEASUREITEM:
		LPMEASUREITEMSTRUCT lpmis; 
		lpmis = (LPMEASUREITEMSTRUCT) lparam; 
		lpmis->itemWidth = 10;
		lpmis->itemHeight = 22; 
		break;

	case WM_DRAWITEM:
		HDC hdc;
		RECT rc;
		COLORREF cr;
		HBRUSH hbrush, hbrHighlight, hbrBackground;

		DRAWITEMSTRUCT * pdis;

		pdis = (DRAWITEMSTRUCT *)lparam;
		hdc = pdis->hDC;
		rc = pdis->rcItem;

		// NULL object ?
		if (pdis->itemData == -1) return 0;
		// Brushes.
		hbrHighlight = CreateSolidBrush(0xFFFFFF - g_bgColor);
		hbrBackground = CreateSolidBrush(g_bgColor);

		switch (pdis->itemAction)
		{
		case ODA_DRAWENTIRE:
			switch (pdis->CtlID)
			{
			case IDC_COLOUR:
				rc = pdis->rcItem;
				cr = (COLORREF) pdis->itemData;
				FillRect(hdc, &rc, hbrBackground);
				InflateRect(&rc, -1, -1);
				hbrush = CreateSolidBrush((COLORREF)cr);
				FillRect(hdc, &rc, hbrush);
				DeleteObject(hbrush);
				FrameRect(hdc, &rc, (HBRUSH) GetStockObject(WHITE_BRUSH));
				break;
			}
			// *** FALL THROUGH ***
		case ODA_SELECT:
			rc = pdis->rcItem;
			if (pdis->itemState & ODS_SELECTED)
				hbrush = hbrHighlight;
			else 
				hbrush = hbrBackground;
			FrameRect(hdc, &rc, hbrush);
		case ODA_FOCUS:
			break;
		}
		DeleteObject(hbrHighlight);
		DeleteObject(hbrBackground);
		return 0;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK) 
		{
			int i;
			i = SendDlgItemMessage(hdlg, IDC_COLOUR, CB_GETCURSEL, 0, 0L);
			g_fgColor = SendDlgItemMessage(hdlg, IDC_COLOUR, CB_GETITEMDATA, i, 0L);
			char* newName = new char[NAME_MAX];
			memset(newName, 0, NAME_MAX);
			GetDlgItemText(hdlg, IDC_NAME, newName, NAME_MAX);
			
			if(newName[0] == '\0'){
				MessageBox(hdlg, "Your chosen name... is so small!", "Small name no?", MB_OK | MB_ICONEXCLAMATION);
				delete[] newName;
			}
			else {
				gcc->changeMyColour((COLORREF)g_fgColor);
				gcc->changeMyName(newName);
				
				delete[] newName;
				EndDialog(hdlg, LOWORD(wParam));
				InvalidateRect(GetParent(hdlg), NULL, true);
			}
			
			return TRUE;
		}
		else if (LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hdlg, LOWORD(wParam));
			return TRUE;
		}
		break;
	}
    return FALSE;
}



BOOL CALLBACK ClientProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch(msg)
	{
		case WM_INITDIALOG:
		{
			// This is where we set up the dialog box, and initialise any default values
			
			gcc->hWndClient = hWnd;
			FILE* file;
			if( (file = fopen(gcc->recent_servers_file, "r" )) != NULL ){
				char server[CHAT_MAX];
			
				while(fgets(server, CHAT_MAX, file) != NULL){
					for(int i=0;i<CHAT_MAX;i++){
						if(server[i] == '\n' || server[i] == '\0')
							break;
					}
					server[i] = '\0';
				
					if(CB_ERR == SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_FINDSTRINGEXACT, 0, (LPARAM)server) ){
						SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_ADDSTRING, 0, (LPARAM)server);
					}
				}
			}
			SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_LIMITTEXT , 0, CHAT_MAX);
			if(CB_ERR == SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_FINDSTRINGEXACT, 0, (LPARAM)"toast.hopto.org") ){
				SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_ADDSTRING, 0, (LPARAM)"toast.hopto.org");
			}
			SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_SETCURSEL, 0, 0);
		
			break;
		}
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case ID_JOIN:
				{

					int curServerLocation = SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_GETCURSEL, 0, 0);
					char* server;
					int curServerSize;
					
					if(curServerLocation == CB_ERR){
						curServerSize = CHAT_MAX;
						server = new char[curServerSize+1];
						SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, WM_GETTEXT, curServerLocation, (LPARAM)server); 
					}
					else {
						curServerSize = SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_GETLBTEXTLEN, curServerLocation, 0);
						server = new char[curServerSize+1];//for the null terminating character
						SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_GETLBTEXT, curServerLocation, (LPARAM)server);
					}				
			
					int i;
					for(i=0;i<curServerSize;i++){
						if(server[i] == ':'){
							break;
						}
					}
					int port=DEFAULT_PORT;
					if(server[i] == ':'){
						server[i] = '\0';
						
						i++;
						char portString[6];
						int j;
						for(j=i;i<j+5;i++){
							portString[i-j] = server[i];
							if(server[i] == '\0')
								break;
						}
						portString[i-j] = '\0';
						port = atoi(portString);
					}
					EnableWindow(GetDlgItem(hWnd, ID_JOIN), FALSE);
					gcc->connectToServer(server, port);
					EnableWindow(GetDlgItem(hWnd, ID_JOIN), TRUE);
					break;
				}		
			}
		break;

		case SERVER_ACCEPTED_CLIENT_CONNECTION:
		{

			FILE* file;
			if( (file = fopen(gcc->recent_servers_file, "w" )) == NULL ){
				MessageBox(hWnd, "The server could not be written to its storage location. Do not worry too much, it just means more typing for you.", "Mini Error", MB_OK | MB_ICONEXCLAMATION);
			}
			else {
				int curServerLocation = SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_GETCURSEL, 0, 0);
				int selectedServerLocation = curServerLocation;
			
				bool first=true;
				int totalServerCount = SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_GETCOUNT, 0, 0);

				do {
					char* curServerString;
					int curServerSize;
					
					if(curServerLocation == CB_ERR){
						curServerSize = CHAT_MAX;
						curServerString = new char[curServerSize+1];
						SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, WM_GETTEXT, curServerLocation, (LPARAM)curServerString); 
					}
					else {
						curServerSize = SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_GETLBTEXTLEN, curServerLocation, 0);
						curServerString = new char[curServerSize+1];//for the null terminating character
						SendDlgItemMessage(hWnd, IDC_COMBO_SERVER_LOCATION, CB_GETLBTEXT, curServerLocation, (LPARAM)curServerString);
					}
					if(!first)
						fprintf(file, "\n");
					fprintf(file, "%s", curServerString);
					delete[] curServerString;
					curServerLocation++;

					if(curServerLocation == selectedServerLocation)
						curServerLocation++;
		
					if(first){
						first = false;
						curServerLocation = 0;
					}
				}
				while(curServerLocation < totalServerCount);
				fclose(file);	
			}

			gcc->hWndChat = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_SERVER),
				NULL, ConnectedClientProc);

			hWndClientChat = gcc->hWndChat;

			if(gcc->hWndChat != NULL){
				ShowWindow(gcc->hWndChat, SW_SHOW);
				PostMessage(hWnd, WM_CLOSE, NULL, NULL);
				gcc->requestServerInformation();
			}
			else{
				MessageBox(hWnd, "CreateDialog returned NULL", "Warning!",	
					MB_OK | MB_ICONINFORMATION);
			}
			break;
		}


		case WM_CLOSE:
			DestroyWindow(hWnd);
		break;
/*		case WM_DESTROY:
			
			hWndClient = NULL;
			PostQuitMessage(0);
*/		break;
		default:
			return FALSE;//DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return TRUE;
}

BOOL CALLBACK LuigiProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam){

	switch(msg)
	{
		case WM_CLOSE:
			//DestroyWindow(hWnd);
			EndDialog(hWnd, LOWORD(wParam));
		break;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDC_YES_LUIGI_CREATED_MULTIMINE) 
			{
				//connect to toast.hopto.org
				PostMessage(hWnd, WM_CLOSE, NULL, NULL);
			}
			if (LOWORD(wParam) == IDC_NO_OUTRAGOUS_CLAIMS)  
			{
				//connect to toast.hopto.org
				PostMessage(hWnd, WM_CLOSE, NULL, NULL);
			}
			break;
		default:
			return FALSE;
	}
	return TRUE;
	
}

BOOL CALLBACK ClientWaitingProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam){
switch(msg)
	{
		case WM_INITDIALOG:
			gcc->hWndGameBeginning = hWnd;
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_CANCEL:
					gcc->leaveServer();
					PostMessage(hWnd, WM_CLOSE, 0, 0);
				break;
			}
		break;

		case WM_CLOSE:
			gcc->hWndGameBeginning = NULL;
			EndDialog(hWnd, LOWORD(wParam));
		break;
		default:
			return FALSE;//DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return TRUE;
}

BOOL CALLBACK AboutProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam){



	switch(msg)
	{
		case WM_INITDIALOG:
		{
			char version[13];
			strcpy(version, "Version ");
			sprintf(&version[8], "%d", MULTI_MINE_VERSION);
			SendDlgItemMessage(hWnd, IDC_STATIC_VERSION, WM_SETTEXT, 0, (LPARAM)version);
			break;
		}
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDOK:
					EndDialog(hWnd, LOWORD(wParam));
				break;
			}
		break;

		case WM_PAINT:
		{

			PAINTSTRUCT  ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			Graphics g(hdc);
			
			g.DrawImage(mini_me, 25, 50);
			
			EndPaint(hWnd, &ps);
			break;
		}
		case WM_CLOSE:
			EndDialog(hWnd, LOWORD(wParam));
		break;
		default:
			return FALSE;//DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return TRUE;
}

BOOL CALLBACK ConnectedClientProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam){
	switch(msg)
	{
	/*	case WM_CTLCOLOREDIT:
			if(lParam == SendDlgItemMessage(hWnd, IDC_EDIT_CHAT_HISTORY, EM_GETHANDLE, 0, 0))
				return (LONG)g_hbrBackground;

	*/	case WM_INITDIALOG:
			EnableMenuItem(GetMenu(hWndMain), IDM_CLIENT_JOINSERVER, MF_GRAYED);
			EnableMenuItem(GetMenu(hWndMain), IDM_SERVER_CREATE, MF_GRAYED);
		
			SendMessage(hWnd, WM_SETICON, ICON_SMALL, 
				(LPARAM)LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_MINESWEEPER), IMAGE_ICON, 16, 16, 0) );
			SendMessage(hWnd, WM_SETICON, ICON_BIG, 
				(LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_MINESWEEPER)) );

			gcc->initChatDialog(hWnd);
		break;

/*		case WM_KEYDOWN:
		{
			if(wParam == VK_RETURN){
				if(editHasFocus){
					gcc->sendChatMessage();
				}
			}
			break;
		}
*/
		case WM_COMMAND:
		{
			switch(HIWORD(wParam))
			{
				case EN_SETFOCUS:
				{
					switch(LOWORD(wParam)){
						case IDC_EDIT_CHAT:
						{
							editHasFocus = true;
							break;
						}
					}
					break;
				}
				case EN_KILLFOCUS:
				{
					switch(LOWORD(wParam)){
						case IDC_EDIT_CHAT:
						{
							editHasFocus = false;
							break;
						}
					}
					break;
				}
			}
			char buffer[24];
			sprintf(buffer, "loword wparam %d\n", LOWORD(wParam));
			OutputDebugString(buffer);
			switch(LOWORD(wParam))
			{
				case 1:
				//case IDC_SEND_MESSAGE:
					gcc->sendChatMessage();
					break;
			}
		}
		break;

		case WM_CLOSE:

			EnableMenuItem(GetMenu(hWndMain), IDM_CLIENT_JOINSERVER, MF_ENABLED);
			EnableMenuItem(GetMenu(hWndMain), IDM_SERVER_CREATE, MF_ENABLED);

			gcc->leaveServer();
			DestroyWindow(hWnd);
		break;

		case WM_DRAWITEM:
		if(true)
			gcc->drawPlayerListBox((DRAWITEMSTRUCT*)lParam);
			break;


	/*	case WM_DESTROY:
			
			PostQuitMessage(0);
			break;
	*/	
		
		default:
			return FALSE;
	}
	return TRUE;
}




BOOL CALLBACK ServerProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

	switch(msg)
	{
	/*	case WM_CTLCOLOREDIT:
			if(lParam == SendDlgItemMessage(hWnd, IDC_EDIT_CHAT_HISTORY, EM_GETHANDLE, 0, 0))
				return (LONG)g_hbrBackground;
			break;

	*/	case WM_INITDIALOG:
		{
			EnableMenuItem(GetMenu(hWndMain), IDM_CLIENT_JOINSERVER, MF_GRAYED);
			EnableMenuItem(GetMenu(hWndMain), IDM_SERVER_CREATE, MF_GRAYED);

			GameControllerServer::initChatDialog(hWnd);

			break;
		}
/*		case WM_KEYDOWN:
		{
			if(wParam == VK_RETURN){
				if(editHasFocus){
					gcc->sendChatMessage();
				}
			}
			break;
		}
*/		case WM_COMMAND:
		{
			switch(HIWORD(wParam)){
				case CBN_SELCHANGE:
				{
					int selected = SendDlgItemMessage(hWnd, LOWORD(wParam), CB_GETCURSEL, 0, 0);
					switch(LOWORD(wParam)){
						case IDC_COMBO_SIZE:
							gcs->comboSizeChange(selected);
							break;
					}

					gcs->variableChange(LOWORD(wParam), selected);
					break;
				}
				case EN_UPDATE:
				{
					switch(LOWORD(wParam)){
						case IDC_EDIT_HEIGHT:
						case IDC_EDIT_WIDTH:
						case IDC_EDIT_MINES:
							BOOL b;
							int value = GetDlgItemInt(hWnd, LOWORD(wParam), &b, FALSE);
							if(b == TRUE && gcs != NULL){
								gcs->variableChange(LOWORD(wParam), value);
							}
						break;
					}
					break;
				}
				case EN_SETFOCUS:
				{
					switch(LOWORD(wParam)){
						case IDC_EDIT_CHAT:
						{
							editHasFocus = true;
							break;
						}
					}
					break;
				}
				case EN_KILLFOCUS:
				{
					switch(LOWORD(wParam)){
						case IDC_EDIT_CHAT:
						{
							editHasFocus = false;
							break;
						}
					}
					break;
				}
			}

			switch(LOWORD(wParam)){
				case 1:
//				case IDC_SEND_MESSAGE:
				
					gcc->sendChatMessage();
					break;

				case IDB_START_STOP_SERVER:
				{
					if(gcs == NULL){
						int port, maxPlayers;
						if(GameControllerServer::preloadChecks(hWnd, &port, &maxPlayers)){
							try {
								gcs = new GameControllerServer(hWnd, maxPlayers, port);
								gcs->hWndChat = hWnd;	
								gcs->postloadSettings(hWndMain);
								gcc->connectToServer("localhost", port);
								gcc->hWndChat = hWnd;
								gcc->requestServerInformation();
							}
							catch (Exception){
								delete gcs;
								gcs = NULL;
								MessageBox(hWnd, "Failed to Start Server", "Could not start server", MB_OK | MB_ICONEXCLAMATION);
							}
							
								
						}
						else {
							MessageBox(hWnd, "Failed pre-system checks.", "Could not start server", MB_OK | MB_ICONEXCLAMATION);
						}
						//MessageBox(hWnd, "Hi!", "Server started", MB_OK | MB_ICONEXCLAMATION);
						
					}
					else {
						gcs->closeServer();
					
						EnableMenuItem(GetMenu(hWnd), IDM_CLIENT_JOINSERVER, MF_GRAYED);
						EnableMenuItem(GetMenu(hWnd), IDM_SERVER_CREATE, MF_GRAYED);

						delete gcs;
						gcs = NULL;
					}
					break;
				}
				case IDB_START_STOP_GAME:
					if(gcs->endGame){
						// game not on
						gcs->beginNewGame();
					}
					else {
						gcs->CARGameOff();
					}
			}
			break;
		}

		case SERVER_MMPSOCKET_EVENT: // fall through
		case SERVER_TEMPSOCK_EVENT:
		case SERVER_LISTENING_SOCKET_EVENT:
			gcs->networkEvent(lParam, (SOCKET)wParam, msg);
			break;

		case WM_TIMER:
			switch(wParam){
				case ID_GAME_START_TIMER:
					gcs->GameOn();
				break;

				case ID_GAME_SECONDS_SINCE_START:
					gcs->oneSecondHasPassed();
				break;
			}
			break;
		case WM_CLOSE:
			if(gcs != NULL){
				gcs->closeServer();
				delete gcs;
				gcs = NULL;
			}

			EnableMenuItem(GetMenu(hWndMain), IDM_CLIENT_JOINSERVER, MF_ENABLED);
			EnableMenuItem(GetMenu(hWndMain), IDM_SERVER_CREATE, MF_ENABLED);

			DestroyWindow(hWnd);
		break;

		case WM_DRAWITEM:
		if(true)
			gcc->drawPlayerListBox((DRAWITEMSTRUCT*)lParam);
			break;


/*		case WM_DESTROY:
			
			hWndServer = NULL;
			PostQuitMessage(0);
			break;
*/
		default:
			return FALSE;//DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return TRUE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;

	switch(msg)
	{
/*		HFONT hfDefault;
		HWND hEdit;
*/

		case WM_CREATE:
		{
			gcc = new GameControllerClient(hWnd, bMenu, dwStyle, dwExStyle);
			gui = gcc->gui;		
			
			mini_me = Bitmap::FromResource(GetModuleHandle(NULL), (const unsigned short*)MAKEINTRESOURCE(IDB_MINI_ME));
			
			Color* currentColour = new Color();
			Color white(Color::White);

			for(unsigned int i=0;i < mini_me->GetWidth();i++){
				for(unsigned int j=0;j< mini_me->GetHeight();j++){
					mini_me->GetPixel(i,j,currentColour);
					if(currentColour->GetValue() == white.GetValue() ){
						mini_me->SetPixel(i,j, *gui->cBg);
					}
				}
			}
			


		
			break;
		}
		case WM_COMMAND:
			wmId    = LOWORD(wParam); 
			wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
			case IDM_CLIENT_PLAYERSETTINGS:
				DialogBox(g_hInstance, (LPCTSTR)IDD_PLAYERSETTINGS, hWnd, (DLGPROC) playerSettings);
				break;

			case IDM_GAME_EXIT:
			   SendMessage(hWnd, WM_CLOSE, wParam, lParam);
			   break;

			case IDM_CLIENT_JOINSERVER:
				hWndClient = CreateDialog(GetModuleHandle(NULL),MAKEINTRESOURCE(IDD_CLIENT), 
					NULL, ClientProc);
				
				if(hWndClient != NULL){
					ShowWindow(hWndClient, SW_SHOW);
				}
				else {
					MessageBox(hWnd, "CreateDialog returned NULL", "Warning!",	
						MB_OK | MB_ICONINFORMATION);
				}
				break;

			case IDM_SERVER_CREATE:
				hWndServer = CreateDialog(GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_SERVER),
					NULL, ServerProc);
				if(hWndServer != NULL){
					ShowWindow(hWndServer, SW_SHOW);
				}
				else{
					MessageBox(hWnd, "CreateDialog returned NULL", "Warning!",	
						MB_OK | MB_ICONINFORMATION);
				}
				//gcs = new GameControllerServer(hWnd, maxPlayers);
				SetDlgItemInt(hWndServer, IDC_EDIT_SERVER_PORT, DEFAULT_PORT, FALSE);
				break;

			case IDM_HELP_ABOUT:
				DialogBox(g_hInstance, (LPCTSTR)IDD_ABOUT_DIALOG, hWnd, (DLGPROC) AboutProc);
				break;


			default:
			   return DefWindowProc(hWnd, msg, wParam, lParam);
			}
			break;
		
		case WM_CLOSE:
			delete gui;
			DestroyWindow(hWnd);
		break;
		case WM_PAINT:
		{
			// Just a note, never use a MessageBox from inside WM_PAINT
			// The box will cause more WM_PAINT messages and you'll probably end up
			// stuck in a loop

			gui->paint();


		}
		break;
		case WM_ERASEBKGND:
			return (LRESULT)1; // Say we handled it.
		
		case WM_DESTROY:
			
			hWndMain = NULL;
			PostQuitMessage(0);

		break;
		case WM_LBUTTONDOWN:

			//if no other mouse buttons are down
			if( !(wParam & (MK_MBUTTON | MK_RBUTTON)) ){
				SetCapture(hWnd);
			}
			//if right mouse button is already down, simulate middle
			if(wParam & MK_RBUTTON){
				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_middle_down, wParam & (MK_LBUTTON | MK_MBUTTON));
			}
			else{ //otherwise send a left mouse down
				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_left_down, wParam & (MK_LBUTTON | MK_MBUTTON));
			}

		break;
		case WM_LBUTTONUP:

			//if other other mouse buttons are not down
			if( !(wParam & (MK_MBUTTON | MK_RBUTTON)) ){
				ReleaseCapture();
			}
			// if the right button is already down send middle up
			if( wParam & MK_RBUTTON){
				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_middle_up, wParam & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON));
				/*
				int a = wParam;
				a = MK_LBUTTON;
				a = MK_RBUTTON;
				*/
			}
			else { // otherwise send a left mouse up
				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_left_up, wParam & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON));
			}

		break;
		case WM_MBUTTONDOWN:
			//IF NO OTHER mouse buttons are down
			if( !(wParam & (MK_LBUTTON | MK_RBUTTON)) ){
				SetCapture(hWnd);
			}
			//no matter what, send a left mouse down.
			gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_middle_down, wParam & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON));
		break;
		case WM_MBUTTONUP:
			//no matter what, send a middle mouse up
			gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_middle_up, wParam & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON));
			//if no other buttons are down
			if( !(wParam & (MK_LBUTTON | MK_RBUTTON)) ){
				ReleaseCapture();
			}
		break;
		case WM_RBUTTONDOWN:
			//if no other buttons are down
			if( !(wParam & (MK_LBUTTON | MK_MBUTTON)) ){
				SetCapture(hWnd);
			}
			//if left is already down, send middle down.
			if( wParam & MK_LBUTTON){
				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_middle_down, wParam & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON));
			}
			else{ //otherwise send a right mouse down
				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_right_down, wParam & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON));
			}

			break;
		case WM_RBUTTONUP:
			//if no other buttons are down
			if( !(wParam & (MK_LBUTTON | MK_MBUTTON)) ){
				ReleaseCapture();
			}
			//if left button is already down, send middle up
			if( wParam & MK_LBUTTON){
				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_middle_up, wParam & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON));
			}
			else{ //otherwise send a right mouse up
				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_right_up, wParam & (MK_LBUTTON | MK_MBUTTON | MK_RBUTTON));
			}
			break;

		case WM_MOUSEMOVE:

			if(wParam == MK_LBUTTON){
				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_mouse_move, /*wParam & (*/MK_LBUTTON /*| MK_MBUTTON)*/);
			}
			if(wParam & MK_MBUTTON || wParam == (MK_LBUTTON | MK_RBUTTON)){

				gui->mouseEvent(MAKEPOINTS(lParam), GUI::ma_mouse_move, /*wParam & (MK_LBUTTON |*/ MK_MBUTTON/*)*/);
			}

			break;

		case WM_TIMER:
			switch(wParam){
				case ID_GAME_SECONDS_SINCE_START:
					gcc->oneSecondHasPassed();
				break;
			}
			break;

		case CLIENT_MMPSOCKET_EVENT:
			gcc->networkEvent(lParam, (SOCKET)wParam, msg);	
			break;

		case CREATE_GAME_BEGINNING_DIALOG:
			DialogBox(g_hInstance, (LPCTSTR)IDD_CLIENT_WAITING, gcc->hWnd, ClientWaitingProc);
			ShowWindow(gcc->hWndGameBeginning, SW_SHOW);
			break;

		case WM_KEYDOWN:
			//	int ret = ToAscii((int), 
			//	int nVirtKey = ;
			if(wParam == VkKeyScan('l'))
				lastButtonPress = 'l';
			else if(wParam == VkKeyScan('u') && lastButtonPress == 'l')
				lastButtonPress = 'u';
			else if(wParam == VkKeyScan('i') && lastButtonPress == 'u')
				lastButtonPress = 'i';
			else if(wParam == VkKeyScan('g') && lastButtonPress == 'i')
				lastButtonPress = 'g';
			else if(wParam == VkKeyScan('i') && lastButtonPress == 'g'){
				DialogBox(g_hInstance, (LPCTSTR)IDD_LUIGI, hWnd, LuigiProc);
			}



			break;

		default:
			return DefWindowProc(hWnd, msg, wParam, lParam);
	}

	return 0; 
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASSEX wc;
	//HWND hWnd;
	MSG Msg;
	GdiplusStartupInput gdiplusStartupInput;
	ULONG_PTR           gdiplusToken;

	// Initialize GDI+.
	GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
	g_hInstance = hInstance;

	wc.cbSize		 = sizeof(WNDCLASSEX);
	wc.style		 = 0;
	wc.lpfnWndProc	 = WndProc;
	wc.cbClsExtra	 = 0;
	wc.cbWndExtra	 = 0;
	wc.hInstance	 = hInstance;
	wc.hIcon		 = LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_MINESWEEPER));
	wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_3DFACE+1);
	wc.lpszMenuName  = MAKEINTRESOURCE(IDR_MENU1);;
	wc.lpszClassName = g_szClassName;
	wc.hIconSm		 = (HICON)LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_MINESWEEPER), IMAGE_ICON, 16, 16, 0);;


	if(!RegisterClassEx(&wc))
	{
		MessageBox(NULL, "Window Registration Failed!", "Error!",
			MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	hWndMain = CreateWindowEx(
		dwExStyle,
		g_szClassName,
		"Multi-Mine",
		dwStyle,
		CW_USEDEFAULT, CW_USEDEFAULT, 300 , 300 ,
		NULL, NULL, hInstance, NULL);

	if(hWndMain == NULL)
	{
		MessageBox(NULL, "Window Creation Failed!", "Error!",
			MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	ShowWindow(hWndMain, nCmdShow);
	UpdateWindow(hWndMain);

	while(GetMessage(&Msg, NULL, 0, 0) > 0)
	{
		if(!IsDialogMessage(hWndServer, &Msg))
        {
			if(!IsDialogMessage(hWndClientChat, &Msg)){

				TranslateMessage(&Msg);
				DispatchMessage(&Msg);
			}
        }
	}

	GdiplusShutdown(gdiplusToken);

	return Msg.wParam;
}
