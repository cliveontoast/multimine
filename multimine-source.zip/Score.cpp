#include "multimine.h"

void Score::getPointsFromRevealing(Minefield* mf, int howToScore, Point* point, 
								  bool reveal_surroundings, bool first_revealer, Score::scoreSheet* score){

	switch(howToScore){
		case DEATHMATCH:
		{
			if(mf->cells(point)->pState == Cell::flagged && !mf->cells(point)->isBomb){
				score->pp_score += -30;
			}

			if(mf->cells(point)->isBomb){
				score->cp_score += -20;
				return;
			}
			
			else if(reveal_surroundings){
				if(first_revealer){
					score->cp_score += mf->cells(point)->neighbourBombs;
					return;
				}
			}
			else {
				score->cp_score += mf->cells(point)->neighbourBombs;
				return;
			}
		}
	}
};

void Score::getPointsFromFlaging(Minefield* mf, int howToScore, Point* point,
								bool flagged, scoreSheet* score){
	switch(howToScore){
		case DEATHMATCH:
		{
			if(flagged){
				score->cp_score += 5;
				return;
			}
			else {
				score->cp_score += -5;
				return;
			}
		}
	}
}

void Score::getPointsFromBadFlagging(int howToScore, scoreSheet* score){
	switch(howToScore){
		case DEATHMATCH:
		{
			score->cp_score += -40;
			return;
		}
	}
}