#ifndef _HAVE_DIGITS_H
#define _HAVE_DIGITS_H 1

#include "multimine.h"
//#include "GUI.h"

/**
Holds the information required to draw digits to the screen
*/

class Digits {

public:

	GUI*	gui;		/**<	Pointer to the GUI object that BlockGUI uses to draw itself.*/

	static Point digitSize;		/**< The size of a digit bitmap. */
	static Color digitBright;	/**< Colour of the digits in the bitmap files.
								*
	*****************************
	*
	*	This is used for testing what colour to change it to
	*
	*************************************************************************/

	static Color digitDark;	/**< Colour of the shaded colour in the bitmap files.
							*
	*************************
	*
	*	This is used for testing what colour to change it to, ie.. the darker one.
	*
	*************************************************************************/
	static int dash; /**<	The location of the dash digit in the numbers array. **/
	static int nothing;	/**<	The location of the nothing digit in the numbers array. **/

	/**	Loads the set of bitmaps that resemble 0 1 2 3 4 5 6 7 8 9 - --> <-- (nothing).
	*	@param gui The pointer that the Digits sets its gui to.
	*/
	Digits(GUI* gui);

	/** Unloads the set of bitmaps that resemble 0 1 2 3 4 5 6 7 8 9 - --> <-- (nothing).
	*/
	~Digits();

	/**	Draws a digit to the screen.
	*	@param digit The digit to draw to the graphics object
	*	@param c The colour to draw the digit.
	*	@param p The location of the point where the digit is to be drawn in the gui
	*/
	int drawDigit(int* digit, Color* c, Point* p);
	
private:
	
	Bitmap *numbers[12];	/**< The array where the number bitmaps are stored. 
								*
	*****************************
	*
	*	position 0 to 9 holds the bitmaps for their respective number.
	*	Position Digits::dash holds... you guessed it, the dash. Position Digits::nothing holds...
	*	yup, the nothing bitmap.
	*
	**/
};

#endif /* _HAVE_DIGITS_H */