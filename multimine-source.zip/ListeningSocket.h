#ifndef _HAVE_LISTENINGCSOCKET_H
#define _HAVE_LISTENINGCSOCKET_H 1

#include "multimine.h"

class ListeningSocket {
public:

	Network* n;
	SOCKET sock;
	struct sockaddr_in address;
	size_t socklen;

//	WSAEVENT socket_event;

	static int normalFlags;

	ListeningSocket(Network* n, int port);

//	~ListeningSocket();

	Destruct_ListeningSocket();

	void OnAccept();

	void OnClose();

	Bind(short port);

	Listen();

	incomingError(short error,short event);

	incomingEvent(short event);

	registerSocket(int wMsg, int flags);
};

#endif /* _HAVE_LISTENINGCSOCKET_H */