#include "multimine.h"
#include "CellGUI.h"

Point CellGUI::pNumber = Point(3,3);
Point CellGUI::pBomb = Point(2,2);
Point CellGUI::pFlag = Point(4,3);

int CellGUI::flag = 0;
int CellGUI::bomb = 9;
int CellGUI::falseBomb = 10;

Color CellGUI::cBg = Color(0xff00ff00);
Color CellGUI::cPlayer = Color(Color.Red);

CellGUI::CellGUI(GUI* _gui){

	gui = _gui;
	
	HBITMAP temp;

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_FLAG));
	pictures[flag] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_ONE));
	pictures[1] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_TWO));
	pictures[2] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_THREE));
	pictures[3] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_FOUR));
	pictures[4] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_FIVE));
	pictures[5] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_SIX));
	pictures[6] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_SEVEN));
	pictures[7] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_EIGHT));
	pictures[8] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_BOMB));
	pictures[bomb] = new Bitmap(temp, NULL);
	DeleteObject(temp);

	temp = LoadBitmap(GetModuleHandle(NULL), MAKEINTRESOURCE(IDB_CELL_FALSE_BOMB));
	pictures[falseBomb] = new Bitmap(temp, NULL);
	DeleteObject(temp);
}

CellGUI::~CellGUI(){
	for(int i=0; i<11; i++){
		delete pictures[i];	
	}
}

int CellGUI::drawPicture(int digit, Color* player, Point* p){


	Bitmap* b = pictures[digit]->Clone(0,0, pictures[digit]->GetWidth(), pictures[digit]->GetHeight(), PixelFormat32bppARGB);
	
	Color* currentColour = new Color();
	
	for(unsigned int i=0;i < (b->GetWidth());i++){
		for(unsigned int j=0;j<b->GetHeight();j++){
			b->GetPixel(i,j,currentColour);
			ARGB bbb = currentColour->GetValue();
			if(currentColour->GetValue() == cBg.GetValue()){
				b->SetPixel(i,j, Color(0,0,0,0));
			}
			if(flag == digit || digit == falseBomb ){
				if(currentColour->GetValue() == cPlayer.GetValue()){
					b->SetPixel(i,j, *player);
				}
			}
		}
	}

	Point addExtra;
	if(digit == flag)
		addExtra=pFlag;
	else if(digit == bomb || digit == falseBomb)
		addExtra=pBomb;
	else
		addExtra=pNumber;
	
	gui->g->DrawImage(b, *p+addExtra);

	delete b;
	delete currentColour;
	
	return 1;
}

int CellGUI::wipePicture(int digit, Point* p){
	Point addExtra;
	Point size = Point(pictures[digit]->GetWidth(), pictures[digit]->GetHeight());

	if(digit == flag)
		addExtra=pFlag;
	else if(digit == bomb || digit == falseBomb)
		addExtra=pBomb;
	else
		addExtra=pNumber;

	gui->g->FillRectangle(gui->brush, p->X + addExtra.X,
									p->Y + addExtra.Y,
									size.X,
									size.Y);
	return 0;
}