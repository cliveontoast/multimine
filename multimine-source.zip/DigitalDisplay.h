#ifndef _HAVE_DIGITALDISPLAY_H
#define _HAVE_DIGITALDISPLAY_H 1

#include "multimine.h"

/** Displays a integer on the screen
*
*/
class DigitalDisplay {

public:
	bool pint_created;
	int *pinteger;	/**<	The integer displayed by this object. 
					*
	*****************
	*
	*	Feel free to change this integer as you want.. you wanted it displayed didnt you!
	*	Just make sure that if you do change it, you draw it. it doesn't draw itself!
	*
	**/
	
	int digits_displayed;	/**< How many digits of the integer to displayed
							*
	*************************
	*
	*	This value should not be changed once the object has been created.
	*
	*************************************************************************/

	/** Creates the Digital display object from the set of inputs
	*	@param digits_displayed Sets the number of digits to display, DigitalDisplay::digits_displayed
	*	@param integer	Sets the integer to be displayed
	**/
	DigitalDisplay(int digits_displayed, int integer);
	
	/** Creates the Digital display object from the set of inputs
	*	@param digits_displayed Sets the number of digits to display, DigitalDisplay::digits_displayed
	*	@param integer	Sets the pointer to the integer to be displayed.
	**/
	DigitalDisplay(int digits_displayed, int* integer);

	/** Destroys the digital display object.
	*
	*	Deletes the displayPosition pointer
	*/
	~DigitalDisplay();
	
	int getInt();

	int* getPInt();

	void setInt(int i);

	void plusplus();

	void minusminus();

private:

	
};

#endif /* _HAVE_DIGITALDISPLAY_H */