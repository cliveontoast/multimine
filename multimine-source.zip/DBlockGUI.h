#ifndef _HAVE_DBLOCKGUI_H
#define _HAVE_DBLOCKGUI_H 1

#include "multimine.h"
/*
#include "BlockGUI.h"
#include "GUI.h"
#include "DBlock.h"
*/

/** Depressable BlockGUI, just like BlockGUI, but can be drawn as if depressed.
*	When a BlockGUI is drawn depressed, only its top and left sides are drawn in 
*	the BlockGUI's cBottom colour.
*/ 

class DBlockGUI : public BlockGUI {

public:

	int	dBorder;	/**<	The size of the depressed top border.
					*
	*****************
	*
	*	This integer holds the number of pixels in bredth of the BlockGUI's depressed border.
	*
	*************************************************************************/

	DBlock* dblock;		/**<	The depressable Block that this GUI is to draw.*/
	
	/**	Creates a BlockGUI object, with depressable abilities
	*	@param dBorder The border of the depressed BlockGUI.
	*	@param dblock The DBlock that this block is drawing.
	*	@see BlockGUI::BlockGUI() for variable definitions
	*/
	DBlockGUI(GUI* gui, Point* topLeft, Point* size, Color* cTop, Color* cBottom, int border, int dBorder, DBlock* dblock);
	
	/** Destroys the BlockGUI object.
	*
	*/
	~DBlockGUI();

	
	/** Draws the border to the gui
	*	
	*	The same as GUI_BlockGUI::drawBorder() unless depressed is true, 
	*	then it will draw a depressed BlockGUI
	**/	
	int drawBorder();

	/** Erases the border back to the gui's background colour
	*	
	**/	
	int wipeShadow();


};

#endif /* _HAVE_DBLOCKGUI_H */
