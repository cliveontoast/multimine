#include "multimine.h"
#include "Cell.h"

Cell::Cell():
DBlock(){
	clear();
}

Cell::clear(){
	depressed = false;
	isBomb = false;
	neighbourBombs = 0;
	player = 0;
	cState = untouched;
	pState = untouched;
}

Cell::~Cell(){

}

bool Cell::flag(int _player, int player_zero_No, bool* flagged_now){
	if(cState == untouched && _player == player_zero_No){
		return false;
	}
	else if(cState == untouched){
		pState = cState;
		cState = flagged;
		*flagged_now = true;
		player = _player;
		return true;
	}
	if(cState == flagged && (player == 0 && _player != 0) /*client previously clicked*/ ){
		pState = cState;
		cState = flagged;
		*flagged_now = true;
		player = _player;
		return true;
	}
	if(cState == flagged && (player == _player || player == player_zero_No) ){
		pState = cState;
		cState = untouched;
		*flagged_now = false;
		player = 0;
		return true;
	}
	
	return false;
}

bool Cell::reveal(int _player, int* _neighbourBombs, bool revealing_Surroundings, int player_at_zero, Score::scoreSheet* score){
	if(cState == revealed) 
		return false;

	if(cState == flagged && revealing_Surroundings)
		return false;

	if(cState == flagged && (_player == player || _player == player_at_zero || (_player == 0 && player == player_at_zero) ) && !revealing_Surroundings)
		return false;

/*	if(cState == flagged && _player != player && player != player_at_zero && !revealing_Surroundings)
		do 
*/	
	pState = cState;
	cState = revealed;
	DBlock::depressed = true;
	score->previous_player = player;
	player = _player;
	*_neighbourBombs = neighbourBombs;
	return true;
}

bool Cell::depress(){
	if(cState == untouched){
		pState = cState;
		cState = pressed;
		return DBlock::depressed = true;
	}
	return false;
	
}

bool Cell::undepress(){
	if(cState == pressed && pState == untouched){
		cState = pState;
		pState = pressed;
		DBlock::depressed = false;
		return true;
	}
	return false;
}