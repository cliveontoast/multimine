#include "GameControllerServer.h"

GameControllerServer::GameControllerServer(HWND hWnd, int _maxPlayers, int port):
GameController(hWnd){
	hWndChat = hWnd;
	realPlayer = 0;
	clientHashReplies = NULL;
	setMaxPlayers(_maxPlayers);
	*currentPlayer = realPlayer;

	server_hash = GetTickCount();
	
	try {
		net = new Network(this, isClient(), NULL, port);
	}
	catch (MMPSocket::SocketException e){
		delete net;
		net = NULL;
		processErrorMessage(e);
		throw Exception(NULL);
	}
}

void GameControllerServer::setMaxPlayers(int _maxPlayers){
	delete[] clientHashReplies;
	clientHashReplies = new bool[_maxPlayers];
	GameController::setMaxPlayers(_maxPlayers);
}

GameControllerServer::~GameControllerServer(){
	delete[] clientHashReplies;
	delete net;
	net = NULL;
	SendDlgItemMessage(hWndChat, IDC_EDIT_MAX_PLAYERS, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDB_START_STOP_SERVER, WM_SETTEXT, 0, (LPARAM)"Start Server\0");
	SendDlgItemMessage(hWndChat, IDC_EDIT_NAME, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_PORT, EM_SETREADONLY, (WPARAM)FALSE, 0);
	
	SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT, EM_SETREADONLY, (WPARAM)TRUE, 0);
	EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_SIZE), FALSE);
	EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_GAME_TYPE), FALSE);
	EnableWindow(GetDlgItem(hWndChat, IDB_START_STOP_GAME), FALSE);
	
	SendDlgItemMessage(hWndChat, IDC_EDIT_MINES, EM_SETREADONLY, (WPARAM)TRUE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_HEIGHT, EM_SETREADONLY, (WPARAM)TRUE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_WIDTH, EM_SETREADONLY, (WPARAM)TRUE, 0);
}

GameControllerServer::initChatDialog(HWND hWndChat){
	GameController::initChatDialog(hWndChat);
	
	EnableWindow(GetDlgItem(hWndChat, IDB_START_STOP_SERVER), TRUE);
	SetDlgItemInt(hWndChat, IDC_EDIT_MAX_PLAYERS, 4, FALSE);
	SendDlgItemMessage(hWndChat, IDC_EDIT_MAX_PLAYERS, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_NAME, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SetDlgItemInt(hWndChat, IDC_EDIT_PORT, DEFAULT_PORT, FALSE);
	SendDlgItemMessage(hWndChat, IDC_EDIT_PORT, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_NAME, WM_SETTEXT, 0, (LPARAM)"A nameless server");

}

void GameControllerServer::variableChange(int variable, int value){
	Network::mmpMSG_server_variable_change msg;
	msg.variable = variable;
	msg.value = value;
	net->broadcastMessageBarSelfClient(Network::mmp_server_variable_change, &msg);
}

bool GameControllerServer::preloadChecks(HWND hWnd, int* port, int* maxPlayers){
	BOOL b;
	BOOL s=TRUE;
	*port = GetDlgItemInt(hWnd,IDC_EDIT_PORT, &b, s);
	*maxPlayers = GetDlgItemInt(hWnd,IDC_EDIT_MAX_PLAYERS, &b, s);
	if(b != TRUE){
		MessageBox(hWnd, "bad input", "Please enter a valid number", MB_OK | MB_ICONEXCLAMATION);
		return false;
	}
	if(*port >= 65536){
		MessageBox(hWnd, "bad input", "Please enter a valid port (0 - 65535)", MB_OK | MB_ICONEXCLAMATION);
		return false;
	}
	return true;
}

GameControllerServer::postloadSettings(HWND hWndMain){
	GetDlgItemText(hWnd, IDC_EDIT_NAME, serverTitle, NAME_MAX);
						
	SendDlgItemMessage(hWndChat, IDC_EDIT_NAME, EM_SETREADONLY, (WPARAM)TRUE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_MAX_PLAYERS, EM_SETREADONLY, (WPARAM)TRUE, 0);
	SendDlgItemMessage(hWndChat, IDB_START_STOP_SERVER, WM_SETTEXT, 0, (LPARAM)"Stop Server\0");
	SendDlgItemMessage(hWndChat, IDC_EDIT_PORT, EM_SETREADONLY, (WPARAM)TRUE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT, EM_SETREADONLY, (WPARAM)FALSE, 0);

	EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_SIZE), TRUE);
	EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_GAME_TYPE), TRUE);
	EnableWindow(GetDlgItem(hWndChat, IDB_START_STOP_GAME), TRUE);
	SendDlgItemMessage(hWndChat, IDC_EDIT_MINES, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_HEIGHT, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_WIDTH, EM_SETREADONLY, (WPARAM)FALSE, 0);



	GameController::comboSizeChange(BEGINNER);
}
			
		
void GameControllerServer::mouseEventMinefield(int player, Point* p,  GUI::Mouse_Action mouse_action, int button_state){
	
	if(!endGame && 0 <= p->X && p->X < mf->getSizeX() && 0 <= p->Y && p->Y < mf->getSizeY()){
		Score::scoreSheet score;
		memset(&score, 0, sizeof(score));
		score.current_player = player;
		Minefield::mfReturnMessage ret = mf->mouseEvent(player, p, mouse_action, button_state, &score);

		players[score.current_player].score += score.cp_score;
		players[score.previous_player].score += score.pp_score;
		score.cp_score = players[score.current_player].score;
		score.pp_score = players[score.previous_player].score;
		
		// handles when players leave during the game.
		if(score.previous_player == -1)
			score.previous_player = 0;

		if(ret != Minefield::mfrm_nothing){
			Network::mmpMSG_server_broadcast_minefield_click msg;
			msg.click.p.X = p->X;
			msg.click.p.Y = p->Y;
			msg.click.ma = mouse_action;
			msg.score = score;
			net->broadcastMessage(Network::mmp_server_broadcast_minefield_click, &msg);//send the message to the multi-mine server
		}

		//bool finished = false;
		
		if(mf->isEndOfGame()){
			CARGameOff();
						
			Network::mmpMSG_server_broadcast_player_change_score msg;
			memset(&msg.score, 0, sizeof(score));
			for(int i=0;i<maxPlayers;i++){
				if(net->myConnections[i]->n != NULL){
					msg.score.current_player = i+1;
					msg.score.cp_score = 0;
					mf->getEndScoreForPlayer(&msg.score);
					players[msg.score.current_player].score += msg.score.cp_score;
					msg.score.cp_score = players[msg.score.current_player].score;
					net->broadcastMessage(Network::mmp_server_broadcast_player_change_score, &msg);
				}
			}	
		}
	}


}

void GameControllerServer::mouseEventSmilie(bool mouseInSmilie, GUI::Mouse_Action mouse_action, int button_state){

}

void GameControllerServer::redrawSmilie(){

}

void GameControllerServer::redrawMinefieldCell(Point *cell){

}

bool GameControllerServer::getEndGame(){
	return GameController::endGame;
}

void GameControllerServer::processErrorMessage(Exception e){
	MessageBox(hWnd, e.msg , "Server Error", MB_OK | MB_ICONERROR);
	delete e.msg;
}

void GameControllerServer::addPlayer(COLORREF colour, char* name, short playerNo){
	GameController::addPlayer(colour, name, playerNo);
	Network::mmpMSG_client_details msg;
	
	memcpy(&msg.name, players[playerNo].name, NAME_MAX);
	msg.colour = players[playerNo].colour->ToCOLORREF();
	msg.playerNo = players[playerNo].playerNo;

	net->broadcastMessage(Network::mmp_server_broadcast_new_client, &msg);

	Network::mmpMSG_client_details msg1;
	for(int i=1;i<=maxPlayers;i++){
		// player exists
		if(players[i].playerNo == i && i != playerNo){
			msg1.colour = players[i].colour->ToCOLORREF();
			memcpy(msg1.name, players[i].name, NAME_MAX);
			msg1.playerNo = players[i].playerNo;
			net->sendMessage(playerNo, Network::mmp_server_send_another_client, &msg1);
		}
	}
}

void GameControllerServer::sendServerDetails(int playerNo){
	Network::mmpMSG_server_details msg1;
	memcpy(msg1.serverTitle, serverTitle, NAME_MAX);
	msg1.port = ntohs(net->listener->address.sin_port);
	msg1.combo_size = SendDlgItemMessage(hWnd, IDC_COMBO_SIZE, CB_GETCURSEL, 0, 0);
	msg1.combo_game_type = SendDlgItemMessage(hWnd, IDC_COMBO_GAME_TYPE, CB_GETCURSEL, 0, 0);
	msg1.endGame = endGame;
	BOOL b;
	msg1.height = GetDlgItemInt(hWnd, IDC_EDIT_HEIGHT, &b, FALSE); 
	if(b == FALSE)
		msg1.height = 0;
	msg1.width = GetDlgItemInt(hWnd, IDC_EDIT_WIDTH, &b, FALSE); 
	if(b == FALSE)
		msg1.width = 0;
	msg1.mines = GetDlgItemInt(hWnd, IDC_EDIT_MINES, &b, FALSE); 
	if(b == FALSE)
		msg1.mines = 0;

	net->sendMessage(playerNo, Network::mmp_server_details, &msg1);
}

void GameControllerServer::changePlayerName(int player, char* name){
	GameController::changePlayerName(player, name);
	
	Network::mmpMSG_server_broadcast_client_name msg;
	msg.player = player;
	memcpy(msg.name, name, NAME_MAX);
	net->broadcastMessage(Network::mmp_server_broadcast_client_name, &msg);
}

void GameControllerServer::changePlayerColour(int player, COLORREF colour){
	GameController::changePlayerColour(player, colour);

	Network::mmpMSG_server_broadcast_client_colour msg;
	msg.player = player;
	msg.colour = colour;
	net->broadcastMessage(Network::mmp_server_broadcast_client_colour, &msg);

}

void GameControllerServer::PlayerHasLeft(int player){
	GameController::PlayerHasLeft(player);
	
	Network::mmpMSG_server_broadcast_client_leaving msg;
	msg.player = player;
	net->broadcastMessage(Network::mmp_server_broadcast_client_leaving, &msg);
}

GameControllerServer::closeServer(){
	if(!endGame)
		CARGameOff();
	EnableWindow(GetDlgItem(hWndChat, IDB_START_STOP_GAME), FALSE);

	SendDlgItemMessage(hWndChat, IDC_EDIT_NAME, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_MAX_PLAYERS, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDB_START_STOP_SERVER, WM_SETTEXT, 0, (LPARAM)"Start Server\0");
	SendDlgItemMessage(hWndChat, IDC_EDIT_PORT, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT, EM_SETREADONLY, (WPARAM)TRUE, 0);

	EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_SIZE), FALSE);
	EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_GAME_TYPE), FALSE);
	EnableWindow(GetDlgItem(hWndChat, IDB_START_STOP_GAME), FALSE);
	SendDlgItemMessage(hWndChat, IDC_EDIT_MINES, EM_SETREADONLY, (WPARAM)TRUE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_HEIGHT, EM_SETREADONLY, (WPARAM)TRUE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_WIDTH, EM_SETREADONLY, (WPARAM)TRUE, 0);

}

GameControllerServer::beginNewGame(){
	Network::mmpMSG_server_broadcast_begin_game msg;

	BOOL b;
	msg.height = GetDlgItemInt(hWnd, IDC_EDIT_HEIGHT, &b, FALSE); 
	msg.width = GetDlgItemInt(hWnd, IDC_EDIT_WIDTH, &b, FALSE); 
	msg.mines = GetDlgItemInt(hWnd, IDC_EDIT_MINES, &b, FALSE); 
	msg.game_type = SendDlgItemMessage(hWnd, IDC_COMBO_GAME_TYPE, CB_GETCURSEL, 0, 0);
	msg.seed = GetTickCount();

	bool begin = GameController::beginNewGame(msg.width, msg.height, msg.mines, msg.seed, msg.game_type);
	
	if(!begin){
		MessageBox(NULL, "Please choose a larger arena, or fewer mines", "Game creation error", MB_OK);
	}
	else {

		EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_SIZE), FALSE);
		EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_GAME_TYPE), FALSE);
		SendDlgItemMessage(hWndChat, IDB_START_STOP_GAME, WM_SETTEXT, 0, (LPARAM)"Stop game");
		SendDlgItemMessage(hWndChat, IDC_EDIT_MINES, EM_SETREADONLY, (WPARAM)TRUE, 0);
		SendDlgItemMessage(hWndChat, IDC_EDIT_HEIGHT, EM_SETREADONLY, (WPARAM)TRUE, 0);
		SendDlgItemMessage(hWndChat, IDC_EDIT_WIDTH, EM_SETREADONLY, (WPARAM)TRUE, 0);

		memset(clientHashReplies, 0, sizeof(bool)*maxPlayers);
		net->broadcastMessage(Network::mmp_server_broadcast_begin_game, &msg);
		
		int ret = SetTimer(hWndChat, ID_GAME_START_TIMER, CLIENT_TIMEOUT, NULL);
		if(ret == 0){
			MessageBox(hWndChat, "Could not SetTimer()!", "Error", MB_OK | MB_ICONEXCLAMATION);
		}
	}
}

void GameControllerServer::oneSecondHasPassed(){
	GameController::oneSecondHasPassed();
	switch(gameType){
		case DEATHMATCH:
			break;
	}
}

void GameControllerServer::GameOn(){
	KillTimer(hWndChat, ID_GAME_START_TIMER);

	for(int i=0;i<maxPlayers;i++){
		if(!clientHashReplies[i]){
			if(net->myConnections[i]->n != NULL){
				net->myConnections[i]->Destruct();
				net->myConnections[i]->OnClose();
				PlayerHasLeft(i+1);
			}
		}
	}
	GameController::GameOn();
	net->broadcastMessage(Network::mmp_server_broadcast_accepting_clicks, NULL);
}

void GameControllerServer::CARGameOff(){
	GameController::CARGameOff();
	EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_SIZE), TRUE);
	EnableWindow(GetDlgItem(hWndChat, IDC_COMBO_GAME_TYPE), TRUE);
	SendDlgItemMessage(hWndChat, IDB_START_STOP_GAME, WM_SETTEXT, 0, (LPARAM)"Start game");
	SendDlgItemMessage(hWndChat, IDC_EDIT_MINES, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_HEIGHT, EM_SETREADONLY, (WPARAM)FALSE, 0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_WIDTH, EM_SETREADONLY, (WPARAM)FALSE, 0);

	net->broadcastMessage(Network::mmp_server_broadcast_end_game, NULL);

}

GameControllerServer::checkClientHash(int player, int hash){
	Network::mmpMSG_server_hash_reply msg;

	if(hash == mf->getHash()){
		clientHashReplies[player-1] = true;
		msg.accepted = true;
	}
	else {
		msg.accepted = false;
	}

	int h = mf->getHash();
	
	net->sendMessage(player, Network::mmp_server_hash_reply, &msg);

}

void GameControllerServer::incommingChatMessage(int player, Network::mmpMSG_chat_message* msg){
	msg->player	= player;
	net->broadcastMessage(Network::mmp_server_broadcast_chat_message, msg);
}
