#include "multimine.h"
#include "GameController.h"

int GameController::gameTypes_count = 1;

char* GameController::gameTypes[] = {	"Death match" /*, 
										"Capture the flag"
										*/};
										
	
int GameController::minefieldSize_count = 4;
char* GameController::minefieldSize[] = {	"Beginner",
											"Intermediate",
											"Expert",
											"Super Duper"};

GameController::GameController(HWND _hWnd){

	hWnd = _hWnd;
	hWndChat = NULL;
	
	ddgt = new DigitalDisplay(3, 0);
	ddbc = new DigitalDisplay(3, 0);
	
	gameType = 0;
	endGame = true;
	mf = NULL;
	maxPlayers = 0;
	players = NULL;
	net = NULL;
	server_hash = 0;

	currentPlayer = new int;
	*currentPlayer = 1;
	mf = new Minefield(1, 1, this);
}

GameController::networkEvent(LPARAM lParam, SOCKET sock, UINT msg){
	try {
		if(net != NULL){
			if(WSAGETSELECTERROR(lParam) != 0){
				net->incomingError(WSAGETSELECTERROR(lParam), WSAGETSELECTEVENT(lParam), sock, msg);
			}
			else {
				net->incomingEvent(WSAGETSELECTEVENT(lParam), sock, msg);
			}
		}
	}
	catch(MMPSocket::SocketException e){
		delete net;
		net = NULL;
		processErrorMessage(e);
	}
}

GameController::initChatDialog(HWND ahWndChat){
	populateComboBoxes(ahWndChat);
	SendDlgItemMessage(ahWndChat, IDC_EDIT_PORT, EM_SETLIMITTEXT, (WPARAM)5, 0);
	SendDlgItemMessage(ahWndChat, IDC_EDIT_CHAT, EM_SETLIMITTEXT, (WPARAM)CHAT_MAX-1, 0);
	SendDlgItemMessage(ahWndChat, IDC_EDIT_MAX_PLAYERS, EM_SETLIMITTEXT, (WPARAM)2, 0);
	SendDlgItemMessage(ahWndChat, IDC_EDIT_WIDTH, EM_SETLIMITTEXT, (WPARAM)3, 0);
	SendDlgItemMessage(ahWndChat, IDC_EDIT_HEIGHT, EM_SETLIMITTEXT, (WPARAM)3, 0);
	SendDlgItemMessage(ahWndChat, IDC_EDIT_MINES, EM_SETLIMITTEXT, (WPARAM)3, 0);
	SendDlgItemMessage(ahWndChat, IDC_EDIT_NAME, EM_SETLIMITTEXT, (WPARAM)NAME_MAX-1, 0);

	SendMessage(ahWndChat, WM_SETICON, ICON_SMALL, 
		(LPARAM)LoadImage(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_MINESWEEPER), IMAGE_ICON, 16, 16, 0) );
	SendMessage(ahWndChat, WM_SETICON, ICON_BIG, 
		(LPARAM)LoadIcon(GetModuleHandle(NULL), MAKEINTRESOURCE(IDI_MINESWEEPER)) );

}

GameController::populateComboBoxes(HWND ahWndChat){
	int i;
	for(i=0;i<minefieldSize_count;i++){
		int j, k;
		j = SendDlgItemMessage(ahWndChat, IDC_COMBO_SIZE, CB_ADDSTRING, 0, (LPARAM)minefieldSize[i]);
		k = GetLastError();
	}

	for(i=0;i<gameTypes_count;i++){
		SendDlgItemMessage(ahWndChat, IDC_COMBO_GAME_TYPE, CB_ADDSTRING, 0, (LPARAM)gameTypes[i]);
	}
	SendDlgItemMessage(ahWndChat, IDC_COMBO_SIZE, CB_SETCURSEL, 0, 0);
	SendDlgItemMessage(ahWndChat, IDC_COMBO_GAME_TYPE, CB_SETCURSEL, 0, 0);
}

GameController::comboSizeChange(int selected){
	int height, width, bombs;
	getGameSizeInformation(selected, &height, &width, &bombs);
	SetDlgItemInt(hWndChat, IDC_EDIT_HEIGHT, height, FALSE);
	SetDlgItemInt(hWndChat, IDC_EDIT_WIDTH, width, FALSE);
	SetDlgItemInt(hWndChat, IDC_EDIT_MINES, bombs, FALSE);
}

GameController::getGameSizeInformation(int gameSize, int* height, int* width, int* bombs){
	switch(gameSize){
	case BEGINNER:
		*height = 9;
		*width = 9;
		*bombs = 10;
		break;
	case INTERMEDIATE:
		*height = 16;
		*width = 16;
		*bombs = 40;
		break;
	case EXPERT:
		*height = 16;
		*width = 30;
		*bombs = 99;
		break;
	case HUGE:
		*height = 30;
		*width = 30;
		*bombs = 200;
		break;
	}
}


bool GameController::beginNewGame(int x, int y, int bombs, int seed, int _gameType){
	if(x < 1 || y < 1)
		return false;
	
	mf->resize(x, y);
	if(mf->populate(seed, bombs) != ARRAY_POPULATED){
		return false;
	}
	for(int i=0;i<maxPlayers;i++){
		players[i].score = 0;
		players[i].flags = 0;
	}
//	*currentPlayer = 0;

	gameType = _gameType;

	switch(gameType){
	case DEATHMATCH:
		ddgt->setInt(0);
		ddbc->setInt(0);

	break;
	}
	return true;
}

void GameController::oneSecondHasPassed(){
	ddgt->plusplus();
}

void GameController::setMaxPlayers(int _maxPlayers){
	if(maxPlayers == 0){
		Player* p = players;
		delete p;
	}
	else
		delete[] players;

	maxPlayers = _maxPlayers;
	players = new Player[maxPlayers+1];
	players[0].playerNo = 0;
}

GameController::~GameController(){
	CARGameOff();
	delete ddgt;
	delete currentPlayer;
	delete mf;
	delete net;
	net = NULL;
	delete[] players;
}

void GameController::mouseEventMinefield(int player, Point* cell, GUI::Mouse_Action mouse_action, int button_state){}
void GameController::mouseEventSmilie(bool inSmilie, GUI::Mouse_Action mouse_action, int button_state){}
void GameController::redrawSmilie(){}
void GameController::redrawMinefieldCell(Point *cell){}
void GameController::revealCells(SLList* cells){}
bool GameController::isClient(){return false;}
void GameController::variableChange(int variable, int value){}

void GameController::addPlayer(COLORREF colour, char* name, short playerNo){
	players[playerNo].colour->SetFromCOLORREF(colour);
	memcpy(players[playerNo].name, name, NAME_MAX);
	players[playerNo].playerNo = playerNo;
	players[playerNo].flags = 0;
	players[playerNo].score = 0;

	// tell players about it.
}

void GameController::PlayerHasLeft(int player){
	if(!endGame){
		mf->removePlayer(player);
	}
	players[player].playerNo = -1;
}

void GameController::changePlayerName(int player, char* name){
	memcpy(players[player].name, name, NAME_MAX);
}

void GameController::changePlayerColour(int player, COLORREF colour){
	players[player].colour->SetFromCOLORREF(colour);
}

void GameController::processErrorMessage(Exception e){}

/*void GameController::delPlayer(short playerNo){
	delete players[playerNo].colour;
}*/

void GameController::GameOn(){
	endGame = false;
	int ret = SetTimer(hWnd, ID_GAME_SECONDS_SINCE_START, ONE_SECOND_IN_MILLISECONDS, NULL);
	if(ret == 0){
		MessageBox(hWndChat, "Could not SetTimer()! in game", "Error", MB_OK | MB_ICONEXCLAMATION);
	}
}

void GameController::CARGameOff(){
	endGame = true;
	KillTimer(hWnd, ID_GAME_SECONDS_SINCE_START);
}

int GameController::getGameType(){
	return SendDlgItemMessage(hWndChat, IDC_COMBO_GAME_TYPE, CB_GETCURSEL, 0, 0);
}

GameController::nameRandomizer(char* name){
	string s;
	stringstream ss;
	s.append("Player ");
	ss << GetTickCount();
	s.append(ss.str());
	strcpy(name, s.c_str());
	name[s.length()] = '\0';
}

GameController::colourRandomizer(COLORREF* rgb){
	srand(GetTickCount());
	*rgb = RGB(rand() % 256, rand() % 256, rand() % 256);
}

void GameController::incommingChatMessage(int player, int length, char* text){
	char* full_text = new char[NAME_MAX+length+2];
	
	strcpy(full_text, "\r\n");
	if(player != 0)
		strcat(full_text, players[player].name);
	else {
		strcat(full_text, "System");
	}

	strcat(full_text, ": ");
	strcat(full_text, text);
	
	//AppendText(SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT_HISTORY, EM_GETHANDLE, 0,0), 
	int textLen = 0;
	textLen = SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT_HISTORY, WM_GETTEXTLENGTH, 0,0);
	SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT_HISTORY, EM_SETSEL, textLen, textLen);
	SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT_HISTORY, EM_REPLACESEL, FALSE, (LPARAM)full_text);
	SendDlgItemMessage(hWndChat, IDC_EDIT_CHAT_HISTORY, EM_SCROLL, SB_LINEDOWN, 0);
	delete[] full_text;

}
