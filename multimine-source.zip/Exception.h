class Exception{
public:
	char* msg;
	Exception(char* _msg){
		msg = _msg;
	}
};