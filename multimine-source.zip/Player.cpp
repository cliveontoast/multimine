#include "multimine.h"
#include "Player.h"

Player::Player(){
	playerNo = 0;
	tl = new Point(0,0);
	colour = new Color();
	score = 0;
	flags = 0;
	dd = NULL;
	ddgui = NULL;
}

Player::~Player(){
	delete tl;
	delete colour;
	if(dd != NULL)
		delete dd;
	if(ddgui != NULL)
		delete ddgui;
}
