#ifndef _HAVE_CELLGUI_H
#define _HAVE_CELLGUI_H 1

#include "multimine.h"
//#include "GUI.h"



/** Holds all the bitmaps for drawing the middle parts of cells. 
*	Draws them to the screen on request.
*	Removes them from the screen on request.
*	You should create one of these in your minefield game.
*/
class CellGUI {
public:
	GUI* gui; /**<	A pointer to the GUI object that holds all drawing objects */
	Bitmap*	pictures[11];	/**< The array where the pictures.
							*
	*************************
	*
	*	Position 1 to 9 holds the bitmaps for their respective number.
	*	<br>Position CellGUI::bomb holds... you guessed it, the bomb. 
	*	<br>Position CellGUI::flagged holds...yup, the flag bitmap.
	*	<br>Position CellGUI::falseBomb... holds the falseBomb bitmap.
	*
	**/

	static int bomb;	/**< The number of the bomb bitmap in the pictures array */
	static int flag;	/**< The number of the flag bitmap in the pictures array */
	static int falseBomb;	/**< The number of the false bomb bitmap in the pictures array */

	static Point pNumber;	/**<	Where to draw the numbers, relative to the start of the cell. */
	static Point pBomb;	/**<	Where to draw the bomb, relative to the start of the cell. */
	static Point pFlag;	/**<	Where to draw the flag, relative to the start of the cell. */

	static Color cBg;	/**<	The background colour of the bitmap images loaded from the file. 
						*	This is then turned into a colourless Color when drawn.	*/
	static Color cPlayer;	/**<	The player colour of the bitmap images loaded from the file.
							**		This is then turned into the right colour when drawn. */

	/** Reads all the bitmaps required for drawing the cells into memory. 
	*	
	*/
	CellGUI(GUI* gui);

	/** Destroys any memory being used up. Well that's the plan.
	*/
	~CellGUI();

	/**	Draws a picture to the screen.
	*	@param digit The digit to draw to the graphics object (or bomb, flagged, falseBomb).
	*	@param c The player's colour.
	*	@param p The cell's topLeft point (where you want to draw the picture).
	*/
	int drawPicture(int digit, Color* c, Point* p);

	/**	Paints over a picture on the screen.
	*	@param digit The digit to paint over on the graphics object (or bomb, flagged, falseBomb).
	*	@param p The cell's topLeft point (where you want to erase the picture.
	*/
	int wipePicture(int digit, Point* p);


};

#endif /* _HAVE_CELLGUI_H */