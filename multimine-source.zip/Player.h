#ifndef _HAVE_PLAYER_H
#define _HAVE_PLAYER_H 1

#include "multimine.h"
/*
#include "GUI.h"
#include "DigitalDisplay.h"
#include "DigitalDisplayGUI.h"
*/

/** BLing bling bling bling blisng
*/


class Player {
public:
	Color* colour;
	char name[NAME_MAX];
	short playerNo;
	int flags; /**< How many flags they have revealed */
	int score; /**< The score of the player */
	short row;	/**<	The row on the top bar that this player is found. */
	Point* tl; /**< Top left spot */
	DigitalDisplay* dd;
	DigitalDisplayGUI* ddgui;
	Player();
	~Player();
};

#endif /* _HAVE_PLAYER_H */