#include "multimine.h"
#include "Smilie.h"

Smilie::Smilie(GameControllerClient* _gcc):
DBlock(false){
	state = Smile;
	gcc = _gcc;
	depressed = false;
}

Smilie::~Smilie(){

}

bool Smilie::mouseEvent(bool mouseInSmilie, GUI::Mouse_Action mouse_action, int button_state){
	bool change=false;

	//check state
		// check depression
			// check mouse action
				//check mouse position
					//action to take

	if(state == Smile){
		if(depressed){
			if(mouse_action == GUI::ma_left_up){
				//mouse is within smilie
					//reset the game in single player
					depressed = false;
					change=true;
			}
			if(mouse_action == GUI::ma_mouse_move){
				if(!mouseInSmilie){
					depressed = false;
					change=true;
				}
			}
		}
		else{
			if(mouse_action == GUI::ma_left_down){
				if(mouseInSmilie){
					depressed = true;
					change=true;
				}
				else {
					state = Scared;
					change=true;
				}
			}
			if(mouse_action == GUI::ma_mouse_move && (button_state & MK_LBUTTON)){
				if(mouseInSmilie){
					depressed = true;
					change=true;
				}
			}
			if(mouse_action == GUI::ma_middle_down){
				//mouse position has no effect
					state = Scared;
					change = true;
			}
		}
	}
	else if(state == Scared){
		if(depressed){
			if(mouse_action == GUI::ma_left_up){
				//point is within smilie
					//reset the game in single player
					state = Smile;
					depressed = false;
					change = true;
			}
			if(mouse_action == GUI::ma_middle_up){
				//point is within smilie
					depressed = false;
					change=true;
			}
			if(mouse_action == GUI::ma_mouse_move){
				if(!mouseInSmilie){
					depressed = false;
					state = Scared_left;
					change=true;
				}
			}
		}
		else {
			if(mouse_action == GUI::ma_left_up){
				//mouse position has no effect
					state = Smile;
					change=true;
			}
			if(mouse_action == GUI::ma_middle_up){
				//mouse position has no effect
					state = Smile;
					change = true;
			}
			if(mouse_action == GUI::ma_left_down){
				if(mouseInSmilie){
					depressed = true;
					change = true;
				}
			}
			if(mouse_action == GUI::ma_middle_down){
				//point doesnt matter
					state = Scared_double;
					change = true;
			}
		}
	}
	else if(state == Scared_left){
		//NEVER EVER DEPRESSED
			if(mouse_action == GUI::ma_middle_up){
				//never ever inside smilie
					state = Scared;
					change = true;
			}
			if(mouse_action == GUI::ma_left_up){
				//NEVER EVER inside smilie
				if(button_state & MK_MBUTTON){
					state = Scared;
				}
				else{
					state = Smile;
				}
				change = true;
			}
			if(mouse_action == GUI::ma_mouse_move){
				if(mouseInSmilie){
					state = Scared;
					depressed = true;
					change = true;
				}
			}

	}
	else if(state == Scared_double){
		//never ever depressed
			if(mouse_action == GUI::ma_middle_up && !(button_state & MK_RBUTTON)){
				//location doesnt matter
					state = Scared;
					change = true;
			}
			if(mouse_action == GUI::ma_middle_up && !(button_state & MK_LBUTTON)){
				//location doesnt matter
					state = Smile;
					change = true;
			}
	}
	else if(state == Dead){

	}
	else if(state == Shades){

	}
	if(change)
		gcc->redrawSmilie();
	return change;
}


