#ifndef _HAVE_GAMECONTROLLERCLIENT_H
#define _HAVE_GAMECONTROLLERCLIENT_H 1

#include "multimine.h"
/*
#include "GameController.h"
#include "Smilie.h"
#include "GUI.h"
#include "SLList.h"
*/

/** Game Controller for a client. Adds extra bits that the Client requires, such as a gui!
*
*/
class GameControllerClient : public GameController {
public:

	static char* last_player_file;
	static char* recent_servers_file;

	Smilie*	s;	/**<	The smilie for the game.	*/

	HWND hWndClient;
	HWND hWndGameBeginning;
	//HWND hWnd;	//im not to sure if this is actually necessary
	GUI* gui;	/**<	The GUI of this game controller */
	int playerNum;	/**<	The client's player number. */
	
	/** Adds extra information required by client guis
	*	@param dwStyle Sets the GUI's dwStyle to this value.
	*	@param bMenu Sets the GUI's bMenu to this value.
	*	@param dwExStyle Sets the GUI's dwExStyle to this value.
	*	@param maxPlayres sets the clients maxPlayers to this value.
	*/
	GameControllerClient(HWND hWnd, BOOL bMenu, DWORD dwStyle, DWORD dwExStyle);
	~GameControllerClient();

	/**	Takes the inputs and sends them to the minefield, if the minefield returns
	*	a message, if this is important, it sends it along to the GCS.
	*/
	void mouseEventMinefield(int player, Point* cell, GUI::Mouse_Action mouse_action, int button_state);

	/**	Takes the inputs and sends them to the smilie, if the smilie returns
	*	a message, if this is important, it sends it along to the GCS.
	*/
	void mouseEventSmilie(bool inSmilie, GUI::Mouse_Action mouse_action, int button_state);

	/**	Tells the GUI that it's SmilieGUI needs to be updated.
	*/
	void redrawSmilie();

	/**	Tells the GUI that it's minefield's cell needs to be redrawn.
	*/
	void redrawMinefieldCell(Point *cell);

	void revealCells(SLList* cells);

	/**	i dont know why the fuck i need this, i should be able to have direct
	*	access to the end game attribute, because i inherited it!!!
	*	endGame' : cannot access public member declared in class 'GameController
	*/
	bool getEndGame();

	bool isClient();

	void processErrorMessage(Exception e);
	
	changeMaxPlayers(int _maxPlayers);
	void setMaxPlayers(int _maxPlayers);
	leaveServer();

	bool beginNewGame(int x, int y, int bombs, int seed, int gameType);

	void GameOn();

	void CARGameOff();

updatePlayerScore(int player, int score);

int GameControllerClient::getmaxplayers();

Player* GameControllerClient::getplayer(int i);

ServerAcceptedClient(COLORREF colour, char* name, int playerNo);
ServerAcceptedConnection(int _server_hash, int maxPlayers);
ServerSendingDetails(char* _serverTitle, int port, int combo_size,
					int combo_game_type, int height, int width, int mines, bool endGame);
connectToServer(char* ip, int port);
void addPlayer(COLORREF colour, char* name, short playerNo);
initChatDialog(HWND hWndChat);
void variableChange(int variable, int value);
requestServerInformation();

changeMyColour(COLORREF colour);
changeMyName(char* newName);

void changePlayerName(int player, char* name);
void changePlayerColour(int player, COLORREF colour);
void PlayerHasLeft(int player);

void addPlayerToList(int player);

void deletePlayerFromList(int player);

ServerHashTest(bool accepted);

void oneSecondHasPassed();

updatePlayerScore(Score::scoreSheet score);

unableToDisplayMinefield();

writePlayerSettings();
sendChatMessage();

drawPlayerListBox(DRAWITEMSTRUCT* bling);

};

#endif /* _HAVE_GAMECONTROLLERCLIENT_H */